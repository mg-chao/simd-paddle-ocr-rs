using System.Buffers.Binary;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Sdcb.SimdPaddleOCR.OnnxSharp;

namespace Sdcb.SimdPaddleOCR.Backends.Metal;

/// <summary>
/// Metal counterpart of the Vulkan GpuGraphModel: shared per (device,
/// compiled model); owns the fp16 weight uploads and the graph compiler that
/// emits a <see cref="MetalSchedule"/>
/// — pure managed metadata (pipeline, arena-relative binding offsets, push
/// constants, grid), no Metal object per shape. Sessions
/// (<see cref="MetalDetGraph"/>) own the grow-only arena/IO buffers and
/// re-record a command buffer each run.
/// </summary>
internal sealed class MetalGraphModel
{
    // Binding sentinels: schedules reference session-owned buffers by role;
    // the session substitutes its live handle when recording.
    internal static readonly MtlBuffer RoleArena = new(0, 0), RoleIn = new(0, 0),
        RoleOut = new(0, 0), RolePart = new(0, 0);

    private static readonly ConditionalWeakTable<CompiledModel, MetalGraphModel> s_models = new();
    private int _refs;

    /// <summary>Ref-counted shared model for (device, compiled); released by
    /// <see cref="Release"/> when the last session goes away.</summary>
    internal static MetalGraphModel Acquire(MtlDevice dev, CompiledModel compiled)
    {
        lock (s_models)
        {
            if (!s_models.TryGetValue(compiled, out MetalGraphModel? m) || m._refs == 0 || m._dev != dev)
            {
                m = new MetalGraphModel(dev, compiled);
                s_models.AddOrUpdate(compiled, m);
            }
            m._refs++;
            return m;
        }
    }

    internal void Release()
    {
        lock (s_models)
        {
            if (--_refs > 0) return;
            if (s_models.TryGetValue(_compiled, out MetalGraphModel? cur) && cur == this)
                s_models.Remove(_compiled);
            lock (this)
            {
                foreach (MtlBuffer b in _allBufs) b.Dispose();
                _allBufs.Clear();
                _schedules.Clear();
            }
        }
    }

    private readonly MtlDevice _dev;
    private readonly Model _model;
    private readonly CompiledModel _compiled;
    internal MtlDevice Device => _dev;
    internal MtlPipeline OutPipe => _pOut;

    private readonly MtlPipeline _pSoftmax;
    private readonly MtlPipeline _pDot,
        _pDw, _pDw4, _pDw4T, _pDense, _pConvT, _pConvT4, _pElem, _pElem4,
        _pReduce, _pReduce4, _pReduce4b, _pPool, _pPool4,
        _pResize, _pResize4, _pResize4Add, _pConcat, _pConcat4, _pNchw, _pOut, _pIm2col,
        _pAddPs, _pSePart, _pSeJoin, _pConvD, _pConvDF32, _pCatRes,
        _pAvg4, _pAffine, _pLn, _pAttn, _pDotSk;
    // Flat (unstaged) depthwise — opt-in only: measured slower than
    // conv_dw4t on this GPU (staging still pays off), SIMD_OCR_DWA enables it
    // for A/B.
    private readonly MtlPipeline? _pDw4A;

    // fp16 copies of constant tensors (weights, biases, scalars), lazy
    private readonly Dictionary<(int, int, int, int), MtlBuffer> _constF16 = new();
    private readonly Dictionary<int, MtlBuffer> _constF32 = new();
    private readonly Dictionary<int, MtlBuffer> _constTap = new();

    // conv weight repack to tap-major [Cout, (dy*kW+dx)*Cin+ci], rows padded to Kp
    private MtlBuffer ConstTapMajor(int tensorIndex, int cout, int cin,
        int kH, int kW, int kp, int cinPad = 0)
    {
        if (cinPad == 0) cinPad = cin;
        if (_constTap.TryGetValue(tensorIndex, out MtlBuffer? cached)) return cached;
        ReadOnlySpan<float> f32 =
            MemoryMarshal.Cast<byte, float>(_compiled.GetTensor(tensorIndex).Constant);
        int kSpan = kH * kW;
        int rowsPad = (cout + 127) / 128 * 128;
        Half[] h = new Half[rowsPad * kp];
        for (int co = 0; co < cout; co++)
            for (int ci = 0; ci < cinPad; ci++)
                for (int tap = 0; tap < kSpan; tap++)
                    if (ci < cin)
                        h[co * kp + tap * cinPad + ci] =
                            (Half)f32[co * cin * kSpan + ci * kSpan + tap];
        MtlBuffer buf = Up16(h);
        _constTap[tensorIndex] = buf;
        _allBufs.Add(buf);
        return buf;
    }

    // depthwise weight repack to tap-major [tap*C + c] fp16 (vec4-readable)
    private readonly Dictionary<int, MtlBuffer> _constDw = new();
    private MtlBuffer ConstDwTap(int tensorIndex, int c, int kSpan)
    {
        if (_constDw.TryGetValue(tensorIndex, out MtlBuffer? cached)) return cached;
        ReadOnlySpan<float> f32 =
            MemoryMarshal.Cast<byte, float>(_compiled.GetTensor(tensorIndex).Constant);
        Half[] h = new Half[c * kSpan];
        for (int cc = 0; cc < c; cc++)
            for (int tap = 0; tap < kSpan; tap++)
                h[tap * c + cc] = (Half)f32[cc * kSpan + tap];
        MtlBuffer buf = Up16(h);
        _constDw[tensorIndex] = buf;
        _allBufs.Add(buf);
        return buf;
    }

    // k-major weight repack for conv1x1_dot: [k*Cout + n], k = tap*cinPad + ci
    private readonly Dictionary<int, MtlBuffer> _constKm = new();
    internal unsafe float[]? DbgConstKm(int tensorIndex, int n)
    {
        if (!_constKm.TryGetValue(tensorIndex, out MtlBuffer? b)) return null;
        var sp = new ReadOnlySpan<ushort>((void*)b.Contents, n);
        var f = new float[n];
        for (int i = 0; i < n; i++) f[i] = (float)BitConverter.UInt16BitsToHalf(sp[i]);
        return f;
    }
    private MtlBuffer ConstKMajor(int tensorIndex, int cout, int cin,
        int kSpan, int kp, int cinPad)
    {
        if (_constKm.TryGetValue(tensorIndex, out MtlBuffer? cached)) return cached;
        ReadOnlySpan<float> f32 =
            MemoryMarshal.Cast<byte, float>(_compiled.GetTensor(tensorIndex).Constant);
        Half[] h = new Half[kp * cout];
        for (int co = 0; co < cout; co++)
            for (int ci = 0; ci < cinPad; ci++)
                for (int tap = 0; tap < kSpan; tap++)
                    if (ci < cin)
                        h[(tap * cinPad + ci) * cout + co] =
                            (Half)f32[co * cin * kSpan + ci * kSpan + tap];
        MtlBuffer buf = Up16(h);
        _constKm[tensorIndex] = buf;
        _allBufs.Add(buf);
        return buf;
    }

    // ConvTranspose weight repack [tap*Cin + ci, co] (tap=dy*2+dx) fp16
    private readonly Dictionary<int, MtlBuffer> _constCt = new();
    private MtlBuffer ConstConvT(int tensorIndex, int cin, int cout)
    {
        if (_constCt.TryGetValue(tensorIndex, out MtlBuffer? cached)) return cached;
        ReadOnlySpan<float> f32 =
            MemoryMarshal.Cast<byte, float>(_compiled.GetTensor(tensorIndex).Constant);
        Half[] h = new Half[4 * cin * cout];
        for (int tap = 0; tap < 4; tap++)
            for (int ci = 0; ci < cin; ci++)
                for (int co = 0; co < cout; co++)
                    h[(tap * cin + ci) * cout + co] =
                        (Half)f32[(ci * cout + co) * 4 + tap];
        MtlBuffer buf = Up16(h);
        _constCt[tensorIndex] = buf;
        _allBufs.Add(buf);
        return buf;
    }

    // reduce_hw4 / se_part phase-1 partials (fp32): a fixed
    // session-owned scratch (S partitions × C channels × batch)
    // partials: fp32 [0, PartCtrElem)
    internal const int PartCtrElem = 1 << 18;
    internal const int PartBytes = PartCtrElem * 4;
    private static MtlBuffer PartBuf(int floats) => RolePart;
    private readonly List<MtlBuffer> _allBufs = new();

    private MetalGraphModel(MtlDevice dev, CompiledModel compiled)
    {
        _dev = dev;
        _compiled = compiled;
        _model = compiled.Model;

        // one probe per capability tier: the simdgroup-matrix kernels get a
        // PSO + smoke dispatch; failure downgrades the cm paths to the
        // portable dot kernels (correct, just slower).
        _sgm = ProbeSimdMatrix();
        _pMm = _dev.OcrPipe("mm_sg");
        _pMmPs = _dev.OcrPipe("mm_ps_sg");
        _pMmDot = _dev.OcrPipe("mm_dot");           // portable cm-path fallback
        _pMmDd = _dev.OcrPipe("mm_sg_dd");           // direct fragment loads, no staging
        _pMmIc = _dev.OcrPipe("mm_ic_sg");           // implicit-GEMM kxk conv (tap gather in A stage)
        _pMmIc32 = Environment.GetEnvironmentVariable("SIMD_OCR_IC32") != null
            ? _dev.OcrPipe("mm_ic_sg32") : _pMmIc; // measured: BK=32 loses except det-medium
        if (!_sgm) { _pMm = _pMmDot; _pMmPs = _pMmDot; _pMmDd = _pMmDot; _pMmIc = _pMmDot; _pMmIc32 = _pMmDot; }

        _pDot = _dev.OcrPipe("conv1x1_dot");
        _pDw = _dev.OcrPipe("conv_dw");
        _pDw4 = _dev.OcrPipe("conv_dw4");
        _pDw4T = _dev.OcrPipe("conv_dw4t");
        // flat variant wins on small feature maps (rec's dw convs); tiled
        // still pays off on large det maps — DwFlatA splits them by input hw.
        _pDw4A = Environment.GetEnvironmentVariable("SIMD_OCR_NODWA") == null
            ? _dev.OcrPipe("conv_dw4a") : null;
        _pDense = _dev.OcrPipe("conv_dense");
        _pIm2col = _dev.OcrPipe("im2col");
        _pConvT = _dev.OcrPipe("convt2s2");
        _pConvT4 = _dev.OcrPipe("convt4");
        _pReduce4 = _dev.OcrPipe("reduce_hw4");
        _pReduce4b = _dev.OcrPipe("reduce_hw4b");
        _pPool4 = _dev.OcrPipe("maxpool4");
        _pResize4 = _dev.OcrPipe("resize4");
        _pResize4Add = _dev.OcrPipe("resize4add");
        _pConcat4 = _dev.OcrPipe("concat4");
        _pCatRes = _dev.OcrPipe("catresize");
        _pElem = _dev.OcrPipe("elem");
        _pElem4 = _dev.OcrPipe("elem4");
        _pAddPs = _dev.OcrPipe("addps");
        _pSePart = _dev.OcrPipe("se_part");
        _pSeJoin = _dev.OcrPipe("se_join");
        _pConvD = _dev.OcrPipe("convk_dot");
        _pConvDF32 = _dev.OcrPipe("convk_f32n");
        _pReduce = _dev.OcrPipe("reduce_hw");
        _pPool = _dev.OcrPipe("maxpool2e");
        _pResize = _dev.OcrPipe("resize_nn");
        _pConcat = _dev.OcrPipe("concat_c");
        _pNchw = _dev.OcrPipe("nchw2nhwc");
        _pOut = _dev.OcrPipe("sigmoid_out");
        _pAvg4 = _dev.OcrPipe("avgpool4");
        _pAffine = _dev.OcrPipe("affine4");
        _pSoftmax = _dev.OcrPipe("softmax");
        _pLn = _dev.OcrPipe("layernorm");
        _pAttn = _dev.OcrPipe("attn");
        _pDotSk = _dev.OcrPipe("mmdot_sk");
    }

    private readonly bool _sgm;   // simdgroup_matrix 8x8 fp16 MMA verified live
    // sg32-family fields kept for emit parity with the Vulkan schedule
    // (DwTiled uses the sg32 kernel cap; PackSlabs runs unconditionally here)
    private readonly bool _sg32 = true;
    private readonly bool _lite = false;
    private readonly MtlPipeline _pMm, _pMmPs, _pMmDot, _pMmDd, _pMmIc, _pMmIc32;

    /// <summary>PSO + live correctness smoke for simdgroup_matrix kernels:
    /// a PSO that links is not proof the driver executes it — the probe runs
    /// a 64x64 tile GEMM against a canned input and compares the whole tile.
    /// The kernel assumes 8 32-lane simdgroups (256 threads), so the PSO
    /// geometry is gated too.
    /// </summary>
    private unsafe bool ProbeSimdMatrix()
    {
        try
        {
            MtlPipeline p = _dev.OcrPipe("mm_sg");
            if (p.ThreadExecutionWidth != 32 || p.MaxTotalThreadsPerThreadgroup < 256)
                return false;
            const int M = 64, N = 64, K = 16;
            var a = new Half[M * K]; var w = new Half[N * K];
            var rnd = new Random(1234);
            for (int i = 0; i < a.Length; i++) a[i] = (Half)((rnd.NextDouble() - 0.5) * 0.25);
            for (int i = 0; i < w.Length; i++) w[i] = (Half)((rnd.NextDouble() - 0.5) * 0.25);
            using MtlBuffer dum = _dev.NewBuffer(256);
            using MtlBuffer ob = _dev.NewBuffer((nuint)(M * N * 2));
            uint[] pc = [(uint)M, (uint)N, (uint)K, (uint)(K / 4), 0u, 0u, 0u];
            fixed (Half* pa = a)
            fixed (Half* pw = w)
            {
                using MtlBuffer xa = _dev.NewBuffer(pa, (nuint)(a.Length * 2));
                using MtlBuffer wb = _dev.NewBuffer(pw, (nuint)(w.Length * 2));
                using (var pool = AutoReleasePool.Create())
                {
                    MtlEncoder e = _dev.BeginCommands();
                    e.SetPipeline(p);
                    e.SetBuffer(xa, 0, 0); e.SetBuffer(wb, 0, 1); e.SetBuffer(dum, 0, 2);
                    e.SetBuffer(dum, 0, 3); e.SetBuffer(ob, 0, 4); e.SetBuffer(dum, 0, 5);
                    e.SetBuffer(dum, 0, 6);
                    fixed (uint* pp = pc) e.SetPc(pp, (nuint)(pc.Length * 4), 7);
                    e.Dispatch(1, 1, 1, 256, 1, 1);
                    e.End(); e.CommitAndWait();
                }
            }
            // whole-tile compare: o[m,n] = sum_k a[m,k]*w[n,k] (w is n-major)
            Half* got = (Half*)ob.Contents;
            for (int m = 0; m < M; m++)
                for (int n = 0; n < N; n++)
                {
                    float expect = 0;
                    for (int k = 0; k < K; k++) expect += (float)a[m * K + k] * (float)w[n * K + k];
                    if (MathF.Abs((float)got[m * N + n] - expect) > 0.05f * MathF.Max(1, MathF.Abs(expect)))
                        return false;
                }
            return true;
        }
        catch { return false; }
    }

    // constant upload helpers (Shared-mode buffers: contents is a plain
    // pointer on unified memory — the repack writes straight in)
    private unsafe MtlBuffer Up16(Half[] h)
    {
        fixed (Half* p = h) return _dev.NewBuffer(p, (nuint)(h.Length * 2));
    }
    private unsafe MtlBuffer Up32(ReadOnlySpan<float> f)
    {
        fixed (float* p = f) return _dev.NewBuffer(p, (nuint)(f.Length * 4));
    }


    // fp16 device copy of a constant tensor; padded to padRows*rowElemsPad
    // elements. rowPad>rowElems repacks [rows, rowElems] into [rows, rowPad].
    private MtlBuffer ConstF16(int tensorIndex, int padRows = 0, int rowElems = 0,
        int rowPad = 0)
    {
        var key = (tensorIndex, padRows, rowElems, rowPad);
        if (_constF16.TryGetValue(key, out MtlBuffer? cached)) return cached;
        ReadOnlySpan<float> f32 =
            MemoryMarshal.Cast<byte, float>(_compiled.GetTensor(tensorIndex).Constant);
        int n = f32.Length;
        int alloc;
        Half[] h;
        if (rowPad > rowElems && rowElems > 0)
        {
            int rows = Math.Max(n / rowElems, padRows);
            alloc = rows * rowPad;
            h = new Half[alloc];
            for (int r = 0; r * rowElems < n; r++)
                for (int c = 0; c < rowElems && r * rowElems + c < n; c++)
                    h[r * rowPad + c] = (Half)f32[r * rowElems + c];
        }
        else
        {
            alloc = Math.Max(n, padRows * rowElems);
            h = new Half[alloc];
            for (int i = 0; i < n; i++) h[i] = (Half)f32[i];
        }
        MtlBuffer buf = Up16(h);
        _constF16[key] = buf;
        _allBufs.Add(buf);
        return buf;
    }

    // fp32 device copy of a constant tensor (small tensors needing exact math).
    private MtlBuffer ConstF32(int tensorIndex)
    {
        if (_constF32.TryGetValue(tensorIndex, out MtlBuffer? cached)) return cached;
        ReadOnlySpan<float> f32 =
            MemoryMarshal.Cast<byte, float>(_compiled.GetTensor(tensorIndex).Constant);
        MtlBuffer buf = Up32(f32);
        _constF32[tensorIndex] = buf;
        _allBufs.Add(buf);
        return buf;
    }

    private ReadOnlySpan<float> CstF32(int tensorIndex) =>
        MemoryMarshal.Cast<byte, float>(_compiled.GetTensor(tensorIndex).Constant);

    // fp16 device copy of a computed vector (e.g. folded BN affine params)
    // keyed by (node, slot) so re-compiling another shape reuses the upload
    private readonly Dictionary<(int, int), MtlBuffer> _vecF16 = new();
    private MtlBuffer VecF16((int, int) key, float[] v)
    {
        if (_vecF16.TryGetValue(key, out MtlBuffer? cached)) return cached;
        Half[] h = new Half[v.Length];
        for (int i = 0; i < v.Length; i++) h[i] = (Half)v[i];
        MtlBuffer buf = Up16(h);
        _vecF16[key] = buf;
        _allBufs.Add(buf);
        return buf;
    }

    // MatMul weight repack [K,N] row-major -> [N,K] fp16 (coopmat B layout),
    // N padded to a 128-row tile.
    private readonly Dictionary<int, MtlBuffer> _constGw = new();
    private MtlBuffer ConstGemmW(int tensorIndex, int K, int N)
    {
        if (_constGw.TryGetValue(tensorIndex, out MtlBuffer? cached)) return cached;
        ReadOnlySpan<float> f32 =
            MemoryMarshal.Cast<byte, float>(_compiled.GetTensor(tensorIndex).Constant);
        int nPad = (N + 127) / 128 * 128;
        Half[] h = new Half[nPad * K];
        for (int k = 0; k < K; k++)
            for (int n = 0; n < N; n++)
                h[n * K + k] = (Half)f32[k * N + n];
        MtlBuffer buf = Up16(h);
        _constGw[tensorIndex] = buf;
        _allBufs.Add(buf);
        return buf;
    }

    // Managed schedule cache: pure metadata (no Metal objects), shared by
    // every session of this model. The LRU bound only caps managed memory —
    // eviction never touches a GPU resource and nothing is ever invalidated.
    private readonly Dictionary<MetalSchedule.Key, MetalSchedule> _schedules = new();
    private const int MaxSchedules = 512;
    private long _tick;

    internal static MetalSchedule.Key KeyOf(int[] inputShape, int nodeLimit, int outTensor)
        => new(inputShape[0], inputShape[2], inputShape[3], nodeLimit, outTensor);

    // SIMD_OCR_NOCATABS=1 disables sole-consumer concat-slice writes —
    // producers then write their own slot so DebugStats stays accurate.
    private static readonly bool _noCatAbs =
        Environment.GetEnvironmentVariable("SIMD_OCR_NOCATABS") != null;
    private static readonly bool s_dbgTime =
        Environment.GetEnvironmentVariable("SIMD_OCR_GPU_TIME") == "1";
    // SIMD_OCR_NOSK=1: narrow-M MatMuls use the plain dot kernel (bisecting)
    private static readonly bool s_noSplitK =
        Environment.GetEnvironmentVariable("SIMD_OCR_NOSK") != null;
    // SIMD_OCR_NODD=1: keep the staged mm_sg tile even when K%16==0 (A/B)
    private static readonly bool _noDd =
        Environment.GetEnvironmentVariable("SIMD_OCR_NODD") != null;

    // SIMD_OCR_NOIC=1: materialize im2col + plain mm instead of implicit-GEMM (A/B)
    private static readonly bool _noIc =
        Environment.GetEnvironmentVariable("SIMD_OCR_NOIC") != null;
    /// <summary>Schedule for (shape, nodeLimit, outTensor); compiled on first
    /// use. nodeLimit truncates the emit loop and outTensor overrides the
    /// readback tensor (REC stops before the vocab projection).</summary>
    internal MetalSchedule GetSchedule(int[] inputShape, int nodeLimit = int.MaxValue, int outTensor = -1)
    {
        MetalSchedule.Key key = KeyOf(inputShape, nodeLimit, outTensor);
        lock (this)
        {
            if (!_schedules.TryGetValue(key, out MetalSchedule? s))
            {
                if (_schedules.Count >= MaxSchedules)
                {
                    MetalSchedule.Key oldest = default;
                    long min = long.MaxValue;
                    foreach ((MetalSchedule.Key k, MetalSchedule v) in _schedules)
                        if (v.LastTick < min) { min = v.LastTick; oldest = k; }
                    _schedules.Remove(oldest);
                }
                long t0 = System.Diagnostics.Stopwatch.GetTimestamp();
                s = BuildPlan(inputShape, nodeLimit, outTensor);
                _schedules[key] = s;
                if (s_dbgTime)
                    Console.WriteLine($"[t] compile {key} {System.Diagnostics.Stopwatch.GetElapsedTime(t0).TotalMilliseconds:F2} ms");
            }
            s.LastTick = ++_tick;
            return s;
        }
    }

    internal MetalSchedule? TryGetSchedule(MetalSchedule.Key key)
    {
        lock (this) return _schedules.TryGetValue(key, out MetalSchedule? s) ? s : null;
    }

    private unsafe MetalSchedule BuildPlan(int[] inputShape, int nodeLimit, int outTensor)
    {
        int[][] shapes = _compiled.ResolveShapesFor(inputShape);
        NodeRecord[] nodes = _model.Nodes;
        int nT = shapes.Length;
        int outIdx = outTensor >= 0 ? outTensor
            : checked((int)_model.GraphOutputs[0]);
        int inIdx = checked((int)_model.GraphInputs[0]);
        int emitLimit = Math.Min(nodeLimit, nodes.Length);
        int nb = inputShape[0];   // batch — spatial kernels take it via gy

        var alias = new int[nT];          // metadata-only ops alias producer slot
        var isConst = new bool[nT];
        var numel = new long[nT];
        var used = new bool[nT];
        for (int i = 0; i < nT; i++)
        {
            alias[i] = i;
            numel[i] = 1;
            foreach (int d in shapes[i]) numel[i] *= Math.Max(d, 1);
            isConst[i] = _compiled.GetTensor(i).IsConstant;
        }
        int Phys(int t) { while (alias[t] != t) t = alias[t]; return t; }

        // refcount / producer / consumers for emit-time fusion decisions
        var refCount = new int[nT];
        var prodNode = new int[nT];
        Array.Fill(prodNode, -1);
        var consumers = new List<int>[nT];
        // members of conv-headed fused groups are folded into the conv dispatch;
        // groups headed by other ops emit every member standalone, so a Mul
        // inside e.g. a HardSigmoid+Mul (hardswish) group is still foldable.
        var inConvGroup = new bool[nodes.Length];
        for (int ni = 0; ni < nodes.Length; ni++)
        {
            int skip = _compiled.FusedSkip(ni);
            if (nodes[ni].Operator is OperatorId.Conv or OperatorId.ConvTranspose)
                for (int j = ni + 1; j <= ni + skip && j < nodes.Length; j++)
                    inConvGroup[j] = true;
            foreach (uint inp in nodes[ni].Inputs)
            {
                if (inp == uint.MaxValue) continue;
                refCount[(int)inp]++;
                (consumers[(int)inp] ??= new List<int>()).Add(ni);
            }
            prodNode[checked((int)nodes[ni].Outputs[0])] = ni;
        }

        // ---- fused MHSA (SVTR mixer): the Transpose5D -> Slice/Squeeze ->
        // q*scale, k^T -> MatMul -> Softmax -> MatMul -> Transpose chain
        // collapses into one `attn` dispatch reading the packed qkv tensor.
        // Members get no arena slots; the chain's out-Transpose slot is the
        // kernel's destination (the trailing Reshape aliases onto it).
        var attnAt = new Dictionary<int, (int qkv, int outT, int T, int H, int D, float scale)>();
        var attnSkip = new HashSet<int>();
        if (Environment.GetEnvironmentVariable("SIMD_OCR_NOATTN") == null)
        {
            var mem = new List<int>();
            for (int ni = 0; ni < nodes.Length; ni++)
                if (nodes[ni].Operator == OperatorId.Transpose
                    && MatchAttention(ni, mem) is { } spec)
                {
                    attnAt[ni] = spec;
                    foreach (int m in mem) attnSkip.Add(m);
                }
        }

        (int qkv, int outT, int T, int H, int D, float scale)? MatchAttention(int tr, List<int> mem)
        {
            mem.Clear();
            int Sole(int t) => refCount[t] == 1 && consumers[t] is { Count: 1 } c ? c[0] : -1;
            bool Perm(int ni, params int[] perm)
            {
                ReadOnlySpan<byte> tp = _model.GetParameters(nodes[ni]);
                if (U16(tp, 2) != perm.Length) return false;
                for (int i = 0; i < perm.Length; i++)
                    if (I32(tp, 4 + 4 * i) != perm[i]) return false;
                return true;
            }
            NodeRecord t5 = nodes[tr];
            int in5 = checked((int)t5.Inputs[0]);
            int[] s5 = shapes[in5];
            if (s5.Length != 5 || s5[0] != nb || s5[2] != 3 || s5[4] > 32
                || !Perm(tr, 2, 0, 3, 1, 4)) return null;
            int r5 = prodNode[in5];
            if (r5 < 0 || nodes[r5].Operator != OperatorId.Reshape) return null;
            int qkvT = checked((int)nodes[r5].Inputs[0]);
            int T = s5[1], H = s5[3], D = s5[4];
            if (shapes[qkvT].Length != 3 || numel[qkvT] != numel[in5]) return null;
            int tOut = checked((int)t5.Outputs[0]);
            List<int>? cs = consumers[tOut];
            if (cs is not { Count: 3 }) return null;
            int[] role = [-1, -1, -1];
            mem.Add(tr);
            foreach (int sl in cs)
            {
                if (nodes[sl].Operator != OperatorId.Slice) return null;
                (int[] st, int[] stp) = _compiled.ResolveSliceBounds(shapes[tOut], nodes[sl], out _);
                int[] so = shapes[checked((int)nodes[sl].Outputs[0])];
                if (st.Length != 5 || so.Length != 5 || so[0] != 1 || (uint)st[0] > 2
                    || role[st[0]] != -1) return null;
                for (int a = 0; a < 5; a++)
                    if (stp[a] != 1 || (a > 0 && (st[a] != 0 || so[a] != shapes[tOut][a])))
                        return null;
                int sq = Sole(checked((int)nodes[sl].Outputs[0]));
                if (sq < 0 || nodes[sq].Operator != OperatorId.Squeeze) return null;
                role[st[0]] = checked((int)nodes[sq].Outputs[0]);
                mem.Add(sl); mem.Add(sq);
            }
            // q: Mul(scalar const) [-> Reshape] -> MatMul1.A
            int mul = Sole(role[0]);
            if (mul < 0 || nodes[mul].Operator != OperatorId.Mul) return null;
            int sc = nodes[mul].Inputs[0] == (uint)role[0]
                ? checked((int)nodes[mul].Inputs[1]) : checked((int)nodes[mul].Inputs[0]);
            if (!isConst[sc] || numel[sc] != 1) return null;
            float scale = CstF32(sc)[0];
            mem.Add(mul);
            int qt = checked((int)nodes[mul].Outputs[0]);
            int mm1 = Sole(qt);
            if (mm1 >= 0 && nodes[mm1].Operator == OperatorId.Reshape
                && numel[checked((int)nodes[mm1].Outputs[0])] == numel[qt])
            {
                mem.Add(mm1);
                qt = checked((int)nodes[mm1].Outputs[0]);
                mm1 = Sole(qt);
            }
            if (mm1 < 0 || nodes[mm1].Operator != OperatorId.MatMul
                || nodes[mm1].Inputs[0] != (uint)qt) return null;
            // k: Transpose[0,1,3,2] -> MatMul1.B
            int kt = Sole(role[1]);
            if (kt < 0 || nodes[kt].Operator != OperatorId.Transpose || !Perm(kt, 0, 1, 3, 2)
                || nodes[mm1].Inputs[1] != nodes[kt].Outputs[0]) return null;
            int smx = Sole(checked((int)nodes[mm1].Outputs[0]));
            if (smx < 0 || nodes[smx].Operator != OperatorId.Softmax) return null;
            int ax = I32(_model.GetParameters(nodes[smx]), 4);
            if (ax != -1 && ax != 3) return null;
            int mm2 = Sole(checked((int)nodes[smx].Outputs[0]));
            if (mm2 < 0 || nodes[mm2].Operator != OperatorId.MatMul
                || nodes[mm2].Inputs[0] != nodes[smx].Outputs[0]
                || nodes[mm2].Inputs[1] != (uint)role[2] || Sole(role[2]) != mm2) return null;
            int ot = Sole(checked((int)nodes[mm2].Outputs[0]));
            if (ot < 0 || nodes[ot].Operator != OperatorId.Transpose || !Perm(ot, 0, 2, 1, 3))
                return null;
            mem.Add(kt); mem.Add(mm1); mem.Add(smx); mem.Add(mm2); mem.Add(ot);
            return (qkvT, checked((int)nodes[ot].Outputs[0]), T, H, D, scale);
        }

        // ---- pass 1: aliases + which tensors need arena slots ----
        for (int ni = 0; ni < nodes.Length; ni++)
        {
            NodeRecord node = nodes[ni];
            int skip = _compiled.FusedSkip(ni);
            if (attnSkip.Contains(ni)) continue;
            // [n,1,a,b] -> [n,b,1,a] (perm 0,3,1,2): with a unit dim-1 the
            // row-major input flat order already equals the NHWC output's.
            if (node.Operator == OperatorId.Transpose
                && shapes[checked((int)node.Inputs[0])] is { Length: 4 } ts4 && ts4[1] == 1
                && _model.GetParameters(node) is ReadOnlySpan<byte> p4
                && U16(p4, 2) == 4 && I32(p4, 4) == 0 && I32(p4, 8) == 3
                && I32(p4, 12) == 1 && I32(p4, 16) == 2)
            {
                alias[checked((int)node.Outputs[0])] = checked((int)node.Inputs[0]);
                continue;
            }
            if (node.Operator is OperatorId.LayoutConvert or OperatorId.Squeeze
                or OperatorId.Unsqueeze or OperatorId.Reshape)
            {
                alias[checked((int)node.Outputs[0])] = checked((int)node.Inputs[0]);
                continue;
            }
            // rank-3 [n,c,w] -> [n,w,c] transpose is a no-op under the
            // channel-last physical layout: out flat (n*w'+c') index equals the
            // producer's (n*w+c) index because w'=w rows and c'=c channels swap
            // positions but keep the same flat offset.
            if (node.Operator == OperatorId.Transpose
                && shapes[checked((int)node.Inputs[0])].Length == 3
                && _model.GetParameters(node) is ReadOnlySpan<byte> p2
                && U16(p2, 2) == 3 && I32(p2, 4) == 0 && I32(p2, 8) == 2
                && I32(p2, 12) == 1)
            {
                alias[checked((int)node.Outputs[0])] = checked((int)node.Inputs[0]);
                continue;
            }
            foreach (uint inp in node.Inputs)
                if (inp != uint.MaxValue && !isConst[checked((int)inp)])
                    used[checked((int)inp)] = true;
            // the slot that gets written = the fused group's last node output
            int sink = checked((int)nodes[ni + skip].Outputs[0]);
            used[sink] = true;
            // fused members reading tensors produced BEFORE the group head
            // (residuals, dual-write pre-gelu taps) need real slots too —
            // in-group reads never touch the arena.
            for (int j = ni + 1; j <= ni + skip; j++)
                foreach (uint inp2 in nodes[j].Inputs)
                {
                    if (inp2 == uint.MaxValue) continue;
                    int ip = checked((int)inp2);
                    if (!isConst[ip] && prodNode[ip] >= 0 && prodNode[ip] < ni)
                        used[Phys(ip)] = true;
                }
            // conv+bias+gelu groups dual-write the pre-gelu tensor when it also
            // feeds a residual outside the group — reserve its slot
            if (skip == 6 && node.Operator == OperatorId.Conv
                && nodes[ni + 1].Operator == OperatorId.Add
                && nodes[ni + 5].Operator == OperatorId.Mul)
            {
                // preG has exactly 2 in-group consumers (Div ni+2, Mul ni+5);
                // anything beyond that is an external reader needing a slot
                int preG = checked((int)nodes[ni + 1].Outputs[0]);
                if (refCount[preG] > 2) used[preG] = true;
            }
            ni += skip;
        }
        foreach (uint g in _model.GraphOutputs) used[checked((int)g)] = true;
        foreach (var at in attnAt.Values) { used[at.outT] = true; used[Phys(at.qkv)] = true; }

        // graph input gets physically padded to 4 channels when Cin%4!=0 so the
        // input conv's im2col can use the vector path; weights pack zeros there.
        int inCinPad = shapes[inIdx][1] % 4 != 0 ? 4 : 0;

        var off = new long[nT];
        var slabElems = new long[nT];
        long cursor = 0;
        long maxIm2col = 0;   // shared scratch: max M*K_pad over emitted im2col convs
        for (int i = 0; i < nT; i++)
        {
            off[i] = -1;
            if (!used[i] || isConst[i] || alias[i] != i) continue;
            off[i] = cursor;
            // pad every slab to a 128-row tile multiple: coopmat reads pad rows;
            // slabs are 8-element (16 B) aligned: the sg32 coopmat stages
            // 16 B uvec4 loads straight from slab starts
            long sz = numel[i];
            if (i == inIdx && inCinPad != 0)
                sz = numel[i] / shapes[i][1] * inCinPad;
            slabElems[i] = (sz + 7) / 8 * 8 + 128 * 64;
            cursor += slabElems[i];
        }
        // the im2col scratch sits past every slab; its size (and the arena
        // total) is settled after emit, so convs that take a direct or
        // implicit-GEMM path reserve nothing
        long im2colOff = (cursor + 63) / 64 * 64;
        // Role sentinels: the session binds its own grow-only buffers at
        // record time, sized from the schedule's requirements.
        MtlBuffer arena = RoleArena, outF32 = RoleOut, inF32 = RoleIn;
        bool inF32Consumed = false;  // stem conv reads fp32 NCHW directly
        bool convTOut = false;   // last convT wrote fp32 out directly


        // ---- pre-emit fusion detection ----
        // Mul(x, seChannelVec) (the SE gate) gets skipped when EVERY consumer can
        // fold the gating: a pointwise Conv applies it as input-prescale, an Add
        // applies it as scaled-residual-add (addps). Any unhandled consumer keeps
        // the Mul emitted.
        var prescale = new Dictionary<int, (uint x, uint se)>();   // convNi -> tensors
        var addScale = new Dictionary<int, (uint x, uint se, uint oth)>();  // addNi -> tensors
        var skipEmit = new HashSet<int>();
        for (int ni = 0; ni < nodes.Length; ni++)
        {
            NodeRecord nd = nodes[ni];
            if (nd.Operator != OperatorId.Mul || _compiled.FusedSkip(ni) != 0 || inConvGroup[ni])
                continue;
            uint a = nd.Inputs[0], b = nd.Inputs[1];
            if (a == uint.MaxValue || b == uint.MaxValue
                || isConst[(int)a] || isConst[(int)b]) continue;
            // se = input whose numel equals the other's channel count
            // (per-image: nb*C for a batch — se tensors are [n,C,1,1])
            long na = numel[(int)a], nelb = numel[(int)b];
            int[] sa = shapes[(int)a], sb = shapes[(int)b];
            uint xT, seT;
            if (na == (sa.Length >= 2 ? (long)sb[1] * nb : -1) && nelb > na) { xT = b; seT = a; }
            else if (nelb == (sb.Length >= 2 ? (long)sa[1] * nb : -1) && na > nelb) { xT = a; seT = b; }
            else continue;
            if (numel[(int)seT] % 4 != 0) continue;

            var pendPrescale = new List<int>();
            var pendAdd = new List<(int c, uint oth)>();
            bool ok = true;
            var stk = new Stack<uint>();
            var seen = new HashSet<uint>();
            stk.Push(nd.Outputs[0]);
            while (stk.Count > 0 && ok)
            {
                uint t = stk.Pop();
                if (!seen.Add(t)) continue;
                List<int>? cs = consumers[(int)t];
                if (cs == null) { ok = false; break; }
                foreach (int c in cs)
                {
                    NodeRecord cn = nodes[c];
                    if (cn.Operator is OperatorId.LayoutConvert or OperatorId.Squeeze
                        or OperatorId.Unsqueeze or OperatorId.Reshape)
                    { stk.Push(cn.Outputs[0]); continue; }
                    if (cn.Operator == OperatorId.Conv && !inConvGroup[c]
                        && Phys((int)cn.Inputs[0]) == Phys((int)nd.Outputs[0]))
                    {
                        ReadOnlySpan<byte> cp = _model.GetParameters(cn);
                        int ccin = shapes[(int)xT][1];
                        int ccout = shapes[(int)cn.Outputs[0]][1];
                        if (U32(cp, 4) == 1 && I32(cp, 8) == 1 && I32(cp, 12) == 1
                            && I32(cp, 16) == 1 && I32(cp, 20) == 1
                            && ccin % 4 == 0 && ccout % 4 == 0 && ccin <= 256
                            && Environment.GetEnvironmentVariable("SIMD_OCR_NOPRESCALE") == null)
                            pendPrescale.Add(c);
                        else ok = false;
                        continue;
                    }
                    if (cn.Operator == OperatorId.Add && !inConvGroup[c]
                        && _compiled.FusedSkip(c) == 0
                        && Environment.GetEnvironmentVariable("SIMD_OCR_NOADDPS") == null)
                    {
                        uint oth = cn.Inputs[0] == t ? cn.Inputs[1]
                                 : cn.Inputs[1] == t ? cn.Inputs[0] : uint.MaxValue;
                        if (oth != uint.MaxValue && !isConst[(int)oth]
                            && numel[(int)oth] == numel[(int)xT]
                            && numel[(int)xT] % 4 == 0)
                        { pendAdd.Add((c, oth)); continue; }
                        ok = false;
                        continue;
                    }
                    ok = false;
                }
            }
            if (!ok)
            {
                foreach (int c in pendPrescale) prescale.Remove(c);
                continue;
            }
            foreach (int c in pendPrescale) prescale[c] = (xT, seT);
            foreach ((int c, uint oth) in pendAdd) addScale[c] = (xT, seT, oth);
            if (Environment.GetEnvironmentVariable("SIMD_OCR_PS_KEEP") != null)
                continue;   // debug: folds registered but mul still emitted
            skipEmit.Add(ni);
        }

        // SE chain fusion: ReduceMean -> Conv1x1(fc1,+bias) -> Conv1x1(fc2,+bias)
        // -> HardSigmoid emits as a single `se` dispatch writing the gate vector
        // directly to the HardSigmoid output slot.
        var seEmit = new Dictionary<int, (int fc1, int fc2, int hs, uint b1, uint b2)>();
        var concatAbsorbed = new HashSet<int>();   // phys tensors written directly into a concat slice

        if (Environment.GetEnvironmentVariable("SIMD_OCR_NOSE") == null)
        {
            bool IsPwConv(int ni)
            {
                if (nodes[ni].Operator != OperatorId.Conv || inConvGroup[ni]) return false;
                ReadOnlySpan<byte> cp = _model.GetParameters(nodes[ni]);
                return U32(cp, 4) == 1 && I32(cp, 8) == 1 && I32(cp, 12) == 1
                    && I32(cp, 16) == 1 && I32(cp, 20) == 1;
            }
            // Resolve the conv group producing the tensor made by node p:
            // either a bias-carrying Conv (det), or a bias-free Conv whose
            // channel-bias Add is fused into its compiler group (rec).
            // Returns (conv node, fp32 bias tensor id) or (-1, MaxValue).
            (int conv, uint biasT) PwGroup(int p)
            {
                if (p < 0) return (-1, uint.MaxValue);
                int convN; uint bT;
                if (nodes[p].Operator == OperatorId.Conv)
                {
                    if (!IsPwConv(p)
                        || nodes[p].Inputs.Length <= 2
                        || nodes[p].Inputs[2] == uint.MaxValue)
                        return (-1, uint.MaxValue);
                    convN = p; bT = nodes[p].Inputs[2];
                }
                else if (nodes[p].Operator == OperatorId.Add)
                {
                    uint ia = nodes[p].Inputs[0], ib = nodes[p].Inputs[1];
                    bool aConst = isConst[checked((int)ia)],
                         bConst = isConst[checked((int)ib)];
                    if (aConst == bConst) return (-1, uint.MaxValue);
                    bT = aConst ? ia : ib;
                    int c = prodNode[Phys(checked((int)(aConst ? ib : ia)))];
                    if (c < 0 || !IsPwConv(c)
                        || _compiled.FusedSkip(c) < p - c)
                        return (-1, uint.MaxValue);
                    convN = c;
                }
                else return (-1, uint.MaxValue);
                // bias must broadcast per-channel: a single non-1 dim equal to the
                // conv's Cout at channel position, e.g. [C,1,1] or [1,C,1,1]
                // (scalar / spatial-HW broadcasts would make se_join read OOB)
                int[] bsh = shapes[Phys(checked((int)bT))];
                int[] osh = shapes[Phys(checked((int)nodes[convN].Outputs[0]))];
                bool ok = false;
                if (osh.Length >= 2)
                {
                    int nz = 0, zi = -1;
                    for (int i = 0; i < bsh.Length; i++)
                        if (bsh[i] != 1) { nz++; zi = i; }
                    ok = nz == 1 && bsh[zi] == osh[1]
                        && zi + (osh.Length - bsh.Length) == 1;   // right-aligned channel dim
                    if (!ok && nodes[p].Operator == OperatorId.Conv)
                        ok = bsh.Length == 1 && bsh[0] == osh[1];   // Conv-carried bias is [Cout]
                }
                if (!ok) return (-1, uint.MaxValue);
                return (convN, bT);
            }
            bool dbg = Environment.GetEnvironmentVariable("SIMD_OCR_GPU_DUMP") == "1";
            for (int hs = 0; hs < nodes.Length; hs++)
            {
                if (nodes[hs].Operator != OperatorId.HardSigmoid
                    || _compiled.FusedSkip(hs) != 0 || inConvGroup[hs]) continue;
                (int fc2, uint b2T) = PwGroup(
                    prodNode[Phys(checked((int)nodes[hs].Inputs[0]))]);
                if (dbg)
                    Console.Error.WriteLine($"  se? hs=n{hs} fc2=n{fc2} b2={(b2T == uint.MaxValue ? -1 : (int)b2T)} rc2={(fc2 >= 0 ? refCount[Phys(checked((int)nodes[hs].Inputs[0]))] : -1)}");
                if (fc2 < 0
                    || refCount[Phys(checked((int)nodes[hs].Inputs[0]))] != 1) continue;
                int reluNi = prodNode[Phys(checked((int)nodes[fc2].Inputs[0]))];
                if (reluNi < 0 || nodes[reluNi].Operator != OperatorId.Relu
                    || refCount[Phys(checked((int)nodes[reluNi].Outputs[0]))] != 1)
                    continue;
                (int fc1, uint b1T) = PwGroup(
                    prodNode[Phys(checked((int)nodes[reluNi].Inputs[0]))]);
                if (dbg)
                    Console.Error.WriteLine($"    fc1=n{fc1} relu=n{reluNi} b1={(b1T == uint.MaxValue ? -1 : (int)b1T)}");
                if (fc1 < 0
                    || refCount[Phys(checked((int)nodes[reluNi].Inputs[0]))] != 1) continue;
                int rm = prodNode[Phys(checked((int)nodes[fc1].Inputs[0]))];
                if (dbg)
                    Console.Error.WriteLine($"    rm=n{rm} op={(rm >= 0 ? nodes[rm].Operator.ToString() : "?")} rcIn={(rm >= 0 ? refCount[Phys(checked((int)nodes[fc1].Inputs[0]))] : -1)}");
                if (rm < 0 || nodes[rm].Operator != OperatorId.ReduceMean
                    || _compiled.FusedSkip(rm) != 0 || inConvGroup[rm]
                    || refCount[Phys(checked((int)nodes[fc1].Inputs[0]))] != 1) continue;
                int[] xs = shapes[Phys(checked((int)nodes[rm].Inputs[0]))];
                int[] rs = shapes[Phys(checked((int)nodes[fc1].Outputs[0]))];
                int rDim = rs.Length >= 2 ? rs[1] : 0;
                if (dbg)
                    Console.Error.WriteLine($"    xs=[{string.Join('x', xs)}] rDim={rDim}");
                if (xs.Length != 4 || xs[1] % 4 != 0 || xs[1] > 1024
                    || rDim <= 0 || rDim > 256) continue;
                seEmit[rm] = (fc1, fc2, hs, b1T, b2T);
                for (int m = fc1; m <= fc1 + _compiled.FusedSkip(fc1); m++)
                    skipEmit.Add(m);   // fc1 conv + its group members (bias-add / relu)
                if (reluNi < fc1 || reluNi > fc1 + _compiled.FusedSkip(fc1))
                    skipEmit.Add(reluNi);   // standalone relu between the conv groups
                for (int m = fc2; m <= fc2 + _compiled.FusedSkip(fc2); m++)
                    skipEmit.Add(m);   // fc2 conv + its group members
                skipEmit.Add(hs);
            }
        }
        if (Environment.GetEnvironmentVariable("SIMD_OCR_GPU_DUMP") == "1")
        {
            Console.Error.WriteLine($"prescale convs={prescale.Count} addps={addScale.Count} seEmit={seEmit.Count} skipEmit={skipEmit.Count}");
            foreach (int rm in seEmit.Keys.OrderBy(k => k))
                Console.Error.WriteLine($"  se chain rm=n{rm} fc1=n{seEmit[rm].fc1} fc2=n{seEmit[rm].fc2} hs=n{seEmit[rm].hs}");
            foreach (var kv in addScale)
            {
                int px = prodNode[(int)kv.Value.x], ps = prodNode[(int)kv.Value.se], po = prodNode[(int)kv.Value.oth];
                Console.Error.WriteLine($"  addps n{kv.Key}: x=t{kv.Value.x}[{string.Join('x', shapes[(int)kv.Value.x])}] prod={(px < 0 ? "?" : nodes[px].Operator.ToString() + px)} " +
                    $"se=t{kv.Value.se}[{string.Join('x', shapes[(int)kv.Value.se])}] prod={(ps < 0 ? "?" : nodes[ps].Operator.ToString() + ps)} " +
                    $"oth=t{kv.Value.oth} prod={(po < 0 ? "?" : nodes[po].Operator.ToString() + po)}");
            }
            foreach (var kv in prescale)
                Console.Error.WriteLine($"  prescale conv n{kv.Key}: x=t{kv.Value.x} se=t{kv.Value.se}");
        }

        // ---- pass 2: emit ----
        int LastEmitNi = -1;
        List<MetalRec> recs = new();
        MetalRec Emit(MtlPipeline pipe, string tag, (MtlBuffer buf, long elemOff, int elemSize)[] binds,
                 uint[] pc, uint gx, uint gy = 1)
        {
            var bb = new MetalBind[binds.Length];
            for (int b = 0; b < binds.Length; b++)
                bb[b] = new MetalBind(binds[b].buf, (ulong)(binds[b].elemOff * binds[b].elemSize));
            MetalRec r = new() { Pipe = pipe, Binds = bb, Pc = Pcu(pc), Gx = gx, Gy = gy,
                Tag = tag, Tx = ReferenceEquals(pipe, _pLn) || ReferenceEquals(pipe, _pAttn) ? 64u : 256u };
            recs.Add(r);
            return r;
        }
        uint Div256(long n) => (uint)((n + 255) / 256);
        // depthwise kernel choice (emit and addps absorb must agree): lite
        // parts run k <= 3 on the flat kernel with the absorb read — its
        // channel-quad-consecutive loads beat the tile's per-quad halo
        // there; the rest goes to the shared-tile kernel, which sg32 also
        // uses for the 9x9 taps
        bool DwFlatA(int kh, int kw, int sh, int sw, long hw) =>
            _pDw4A is not null && kh <= 3 && kw <= 3 && sh <= 2 && sw <= 2
            && hw <= 2048;
        bool DwTiled(int kh, int kw, int sh, int sw, long hw) => !DwFlatA(kh, kw, sh, sw, hw)
            && kh <= (_sg32 ? 9 : 5) && kw <= (_sg32 ? 9 : 5) && sh <= 2 && sw <= 2;
        // spatial-reduce partitions: ~512 px per workgroup (a 16-WG cap left
        // most of the GPU idle on large DET maps), bounded by partial storage
        int PartSplits(int hw, int c) =>
            Math.Max(1, Math.Min(Math.Min((hw + 511) / 512, 256), PartCtrElem / (c * nb)));
        // Metal GEMM emit: "cm" path → mm_sg (simdgroup 64x64 tile, K-step 16)
        // when the live probe passed, else mm_dot (portable m4n4). Both read
        // n-major fp16 weights [N,K] and take pc {M,N,K,kv4,flags,mImg,scMod}.
        MetalRec EmitMm(bool ps, string tag,
            (MtlBuffer buf, long elemOff, int elemSize)[] binds,
            uint M, uint N, uint K, uint flags, uint mImg, uint scMod)
        {
            uint[] pc = [M, N, K, (uint)(K / 4), flags, mImg, scMod];
            if (_sgm)
                // mm_sg_dd reads fragment rows past M/N on edge tiles — safe:
                // A overread stays inside the arena's ≥1MB tail slack, W rows
                // are padded to /128, and the epilogue masks mm<p.M/nn<p.N.
                return Emit(!ps && K % 16 == 0 && !_noDd
                        ? _pMmDd : ps ? _pMmPs : _pMm,
                    tag, binds, pc, (N + 63) / 64, (M + 63) / 64);
            return Emit(_pMmDot, tag, binds, pc,
                Div256(((M + 3) / 4) * (long)(N / 4)), 1);
        }
        (MtlBuffer, long, uint) Operand(int t, int chan, long n)
        {
            long nel = numel[t];
            uint mode = nel == n ? 0u : nel == chan ? 1u : 2u;
            return isConst[t] ? (ConstF16(t), 0, mode) : (arena, off[Phys(t)], mode);
        }

        // ---- addps absorb: the addps rec disappears; its sole consumer reads
        // a + x*se inline. A consumer qualifies only when its emit path is one
        // of the kernels with an absorb flag (dw4t / 1x1-dot / resize4 /
        // resize4add / concat4) AND the gates below exactly match emit — an
        // absorbed tensor read by a non-absorbing kernel would be garbage.
        var addpsSrc = new Dictionary<int, (uint a, uint x, uint se)>();
        if (Environment.GetEnvironmentVariable("SIMD_OCR_NOAPS") == null)
        foreach ((int addNi, (uint x, uint se, uint oth) asc) in addScale)
        {
            int outP = Phys(checked((int)nodes[addNi].Outputs[0]));
            if (refCount[outP] != 1) continue;
            List<int>? cs = consumers[outP];
            if (cs == null || cs.Count != 1 || Absorbable(cs[0], outP) == false)
                continue;
            addpsSrc[outP] = (asc.oth, asc.x, asc.se);
        }

        bool Absorbable(int cn, int srcPhys)
        {
            NodeRecord c = nodes[cn];
            switch (c.Operator)
            {
                case OperatorId.Conv:
                {
                    if (Phys(checked((int)c.Inputs[0])) != srcPhys) return false;
                    ReadOnlySpan<byte> cp = _model.GetParameters(c);
                    int[] ish2 = shapes[checked((int)c.Inputs[0])];
                    int[] osh2 = shapes[checked((int)c.Outputs[0])];
                    int cin2 = ish2[1], cout2 = osh2[1];
                    int kH2 = I32(cp, 8), kW2 = I32(cp, 12),
                        sH2 = I32(cp, 16), sW2 = I32(cp, 20);
                    int grp2 = Math.Max(1, checked((int)U32(cp, 4)));
                    if (grp2 == cin2 && cout2 == cin2)
                        return cin2 % 4 == 0
                            && (DwTiled(kH2, kW2, sH2, sW2, (long)ish2[2] * ish2[3])
                                || DwFlatA(kH2, kW2, sH2, sW2, (long)ish2[2] * ish2[3]));
                    if (grp2 == 1 && kH2 == 1 && kW2 == 1 && sH2 == 1 && sW2 == 1)
                    {
                        int cinI2 = (srcPhys == inIdx && cin2 % 4 != 0) ? 4 : cin2;
                        if (cinI2 % 4 != 0 || cout2 % 4 != 0 || cinI2 > 128)
                            return false;
                        int cskip = _compiled.FusedSkip(cn);
                        if (cskip == 1 && nodes[cn + 1].Operator == OperatorId.Add)
                        {
                            NodeRecord ad2 = nodes[cn + 1];
                            int bt = ad2.Inputs[0] == c.Outputs[0]
                                ? checked((int)ad2.Inputs[1])
                                : checked((int)ad2.Inputs[0]);
                            if (numel[bt] == 1) return false;   // scalarBias
                        }
                        return !prescale.ContainsKey(cn)
                            && Environment.GetEnvironmentVariable(
                                "SIMD_OCR_NODOT") == null;
                    }
                    return false;
                }
                case OperatorId.Resize:
                    return Phys(checked((int)c.Inputs[0])) == srcPhys
                        && shapes[checked((int)c.Outputs[0])][1] % 4 == 0;
                case OperatorId.Concat:
                {
                    int[] ospc = shapes[checked((int)c.Outputs[0])];
                    if (ospc[1] % 4 != 0) return false;
                    int cOff2 = 0;
                    foreach (uint inp2 in c.Inputs)
                    {
                        int ci2 = shapes[checked((int)inp2)][1];
                        if (Phys(checked((int)inp2)) == srcPhys)
                            return ci2 % 4 == 0 && cOff2 % 4 == 0;
                        cOff2 += ci2;
                    }
                    return false;
                }
                case OperatorId.Add:
                {
                    // consumer Add is the tail of a resize4add fusion: the
                    // other input must come from a Resize that will itself
                    // hit the fused path (sole-consumer, %4, same numel).
                    if (addScale.ContainsKey(cn)) return false;
                    int i0 = Phys(checked((int)c.Inputs[0]));
                    int i1 = Phys(checked((int)c.Inputs[1]));
                    int othP2 = i0 == srcPhys ? i1 : i1 == srcPhys ? i0 : -1;
                    if (othP2 < 0) return false;
                    int prod = prodNode[othP2];
                    if (prod < 0 || nodes[prod].Operator != OperatorId.Resize)
                        return false;
                    int[] osp3 = shapes[checked((int)nodes[prod].Outputs[0])];
                    if (osp3[1] % 4 != 0) return false;
                    if (refCount[othP2] != 1 || consumers[othP2]?.Count != 1
                        || consumers[othP2][0] != cn) return false;
                    return numel[srcPhys] == numel[othP2];
                }
                default: return false;
            }
        }

        // ---- catresize fusion: a Concat whose inputs are sole-consumed
        // Resize nodes (or plain tensors) collapses to ONE dispatch that
        // resamples each source straight into its output slice. The resizes'
        // own recs are skipped (they were the writers, now the kernel writes).
        var catRes = new Dictionary<int,
            (long x, long ra, long se, uint fl, uint inW, uint fh, uint fw,
             uint off4, uint cq4)[]>();
        // catresize kernel is batch-free: batched graphs keep the plain path
        for (int ci2 = 0; nb == 1 && ci2 < nodes.Length; ci2++)
        {
            NodeRecord c = nodes[ci2];
            if (c.Operator != OperatorId.Concat || c.Inputs.Length > 4)
                continue;
            int[] osp = shapes[checked((int)c.Outputs[0])];
            if (osp[1] % 4 != 0) continue;
            var spec = new (long, long, long, uint, uint, uint, uint, uint, uint)
                [c.Inputs.Length];
            int cOff3 = 0; bool okc = true; var skipTmp = new List<int>();
            for (int ii = 0; ii < c.Inputs.Length; ii++)
            {
                uint inp2 = c.Inputs[ii];
                int ip = Phys(checked((int)inp2));
                int ci3 = shapes[checked((int)inp2)][1];
                if (ci3 % 4 != 0 || cOff3 % 4 != 0) { okc = false; break; }
                uint fh3 = 1, fw3 = 1, inW3 = (uint)osp[3];
                int srcP = ip;
                int prod = prodNode[ip];
                if (prod >= 0 && nodes[prod].Operator == OperatorId.Resize
                    && refCount[ip] == 1 && consumers[ip]?.Count == 1
                    && consumers[ip][0] == ci2)
                {
                    int[] rish = shapes[checked((int)nodes[prod].Inputs[0])];
                    if (rish[1] != ci3) { okc = false; break; }
                    fh3 = (uint)(osp[2] / rish[2]);
                    fw3 = (uint)(osp[3] / rish[3]);
                    if (rish[2] * (int)fh3 != osp[2] || rish[3] * (int)fw3 != osp[3])
                    { okc = false; break; }
                    inW3 = (uint)rish[3];
                    srcP = Phys(checked((int)nodes[prod].Inputs[0]));
                    skipTmp.Add(prod);
                }
                else if (refCount[ip] == 1 && consumers[ip]?.Count == 1
                    && consumers[ip][0] == ci2 && prod >= 0
                    && !addpsSrc.ContainsKey(ip))
                {
                    // sole-consumed producer emits a slice-write into this
                    // concat instead of materializing its own tensor —
                    // catRes cannot read it back; keep the old path.
                    okc = false; break;
                }
                uint fl = 0; long xP = off[srcP], raP = 0, seP = 0;
                if (addpsSrc.TryGetValue(srcP, out var ads))
                {
                    xP = off[Phys(checked((int)ads.x))];
                    raP = off[Phys(checked((int)ads.a))];
                    seP = off[Phys(checked((int)ads.se))];
                    fl = 1;
                }
                spec[ii] = (xP, raP, seP, fl, inW3, fh3, fw3,
                            (uint)(cOff3 / 4), (uint)(ci3 / 4));
                cOff3 += ci3;
            }
            if (!okc) continue;
            catRes[ci2] = spec;
            foreach (int p2 in skipTmp) skipEmit.Add(p2);
        }

        for (int ni = 0; ni < emitLimit; ni++)
        {
            NodeRecord node = nodes[ni];
            if (skipEmit.Contains(ni)) continue;
            if (attnAt.TryGetValue(ni, out var att))
            {
                LastEmitNi = ni;
                Emit(_pAttn, $"attn n{ni} T{att.T} H{att.H} D{att.D}",
                    [(arena, off[Phys(att.qkv)], 2), (arena, off[att.outT], 2)],
                    [(uint)att.T, (uint)att.H, (uint)att.D,
                     BitConverter.SingleToUInt32Bits(att.scale)],
                    (uint)((att.T + 63) / 64), (uint)(nb * att.H));
                continue;
            }
            if (attnSkip.Contains(ni)) continue;
            try
            {
            int skip = _compiled.FusedSkip(ni);
            ReadOnlySpan<byte> p = _model.GetParameters(node);
            int outPhys = Phys(checked((int)nodes[ni + skip].Outputs[0]));
            LastEmitNi = ni;
            long SlotOf(uint t) => off[Phys(checked((int)t))];

            switch (node.Operator)
            {
                case OperatorId.LayoutConvert:
                case OperatorId.Squeeze:
                case OperatorId.Unsqueeze:
                case OperatorId.Reshape:
                    break;

                case OperatorId.Conv:
                {
                    int[] ishp = shapes[node.Inputs[0]];
                    int[] oshp = shapes[node.Outputs[0]];
                    int cin = ishp[1], cout = oshp[1];
                    int inH = ishp[2], inW = ishp[3], outH = oshp[2], outW = oshp[3];
                    int kH = I32(p, 8), kW = I32(p, 12), sH = I32(p, 16), sW = I32(p, 20);
                    int pt = I32(p, 32), pl = I32(p, 36);
                    int group = Math.Max(1, checked((int)U32(p, 4)));

                    int act = 0;
                    MtlBuffer biasBuf = arena;
                    uint resT = uint.MaxValue, dualT = uint.MaxValue;
                    uint hasBias = 0, scalarBias = 0, flags16 = 0;
                    bool dualRaw = false;
                    if (node.Inputs.Length > 2 && node.Inputs[2] != uint.MaxValue)
                    { biasBuf = ConstF16(checked((int)node.Inputs[2])); hasBias = 1; }
                    if (skip == 1 && nodes[ni + 1].Operator == OperatorId.Relu)
                        act = 1;
                    else if (skip == 1 && nodes[ni + 1].Operator == OperatorId.Add)
                    {
                        // conv (no bias) + channel-bias add
                        NodeRecord add = nodes[ni + 1];
                        int bt = add.Inputs[0] == node.Outputs[0]
                            ? checked((int)add.Inputs[1]) : checked((int)add.Inputs[0]);
                        biasBuf = ConstF16(bt); hasBias = 1;
                        if (numel[bt] == 1) scalarBias = 8u;
                    }
                    else if (skip == 2 && nodes[ni + 1].Operator == OperatorId.HardSigmoid
                             && nodes[ni + 2].Operator == OperatorId.Mul)
                    {
                        act = 3;
                        ReadOnlySpan<byte> hp = _model.GetParameters(nodes[ni + 1]);
                        float hsA = F32(hp, 4), hsB = F32(hp, 8);
                        if (hsB != 0.5f)
                            throw new NotSupportedException($"hardsigmoid beta={hsB} at node {ni + 1}");
                        flags16 |= (uint)Half2Bits(hsA) << 16;
                    }
                    else if (skip == 6
                             && nodes[ni + 1].Operator == OperatorId.Add
                             && nodes[ni + 2].Operator == OperatorId.Div
                             && nodes[ni + 3].Operator == OperatorId.Erf
                             && nodes[ni + 4].Operator == OperatorId.Add
                             && nodes[ni + 5].Operator == OperatorId.Mul
                             && nodes[ni + 6].Operator == OperatorId.Mul
                             && Phys(checked((int)nodes[ni + 2].Inputs[0]))
                                == Phys(checked((int)nodes[ni + 1].Outputs[0]))
                             && (Phys(checked((int)nodes[ni + 5].Inputs[0]))
                                 == Phys(checked((int)nodes[ni + 1].Outputs[0]))
                              || Phys(checked((int)nodes[ni + 5].Inputs[1]))
                                 == Phys(checked((int)nodes[ni + 1].Outputs[0]))))
                    {
                        // compiler-fused conv + bias-Add + gelu chain:
                        // out = 0.5*x*(1+erf(x/√2)) where x = conv + bias.
                        NodeRecord add = nodes[ni + 1];
                        int bt = add.Inputs[0] == node.Outputs[0]
                            ? checked((int)add.Inputs[1])
                            : checked((int)add.Inputs[0]);
                        biasBuf = ConstF16(bt); hasBias = 1;
                        if (numel[bt] == 1) scalarBias = 8u;
                        act = 2;
                        int preG = Phys(checked((int)nodes[ni + 1].Outputs[0]));
                        if (refCount[preG] > 2)
                        {
                            // conv+bias also feeds a residual outside the
                            // group: sink slot gets gelu(acc) via o; the preG
                            // slot gets raw acc via o2 (flag bit10).
                            dualT = (uint)preG; dualRaw = true;
                        }
                    }
                    else if (skip == 2
                             && nodes[ni + 1].Operator == OperatorId.Add
                             && nodes[ni + 2].Operator == OperatorId.Add)
                    {
                        // conv + channel-bias Add + residual Add
                        NodeRecord add = nodes[ni + 1];
                        int bt = add.Inputs[0] == node.Outputs[0]
                            ? checked((int)add.Inputs[1])
                            : checked((int)add.Inputs[0]);
                        if (!isConst[bt])
                            throw new NotSupportedException(
                                $"conv+add+add mid-add non-const at node {ni + 1}");
                        biasBuf = ConstF16(bt); hasBias = 1;
                        if (numel[bt] == 1) scalarBias = 8u;
                        NodeRecord res = nodes[ni + 2];
                        int mid = Phys(checked((int)add.Outputs[0]));
                        uint oth = Phys(checked((int)res.Inputs[0])) == mid
                            ? res.Inputs[1]
                            : Phys(checked((int)res.Inputs[1])) == mid
                                ? res.Inputs[0] : uint.MaxValue;
                        if (oth == uint.MaxValue || isConst[(int)oth]
                            || numel[(int)oth] != numel[mid])
                            throw new NotSupportedException(
                                $"conv+add+add residual form at node {ni + 2}");
                        resT = oth;
                    }
                    else if (skip != 0)
                        throw new NotSupportedException(
                            $"conv fused skip={skip} at node {ni} (next={nodes[ni + 1].Operator})");

                    // ---- emit-time fusion extensions (compiler didn't group these) ----
                    // pointwise conv + residual Add (+ optional gelu pattern) —
                    // cm/dot kernels implement res binding (flags bit1) and act (bits4-6).
                    if (group == 1 && kH == 1 && kW == 1 && sH == 1 && sW == 1
                        && Environment.GetEnvironmentVariable("SIMD_OCR_NOEXTEND") == null)
                    {
                        int ge = ni + skip;
                        int j = ge + 1;
                        // residual Add may only be absorbed when the conv group
                        // carries no activation: kernels evaluate act(conv+res),
                        // but act(conv)+res is the ONNX semantics (e.g. relu then
                        // add must NOT become relu of the sum).
                        if (j < nodes.Length && nodes[j].Operator == OperatorId.Add
                            && !inConvGroup[j] && _compiled.FusedSkip(j) == 0
                            && !addScale.ContainsKey(j) && act == 0
                            && Environment.GetEnvironmentVariable("SIMD_OCR_NOEXTR") == null)
                        {
                            NodeRecord ad = nodes[j];
                            int prev = Phys(checked((int)nodes[ge].Outputs[0]));
                            int ia = Phys(checked((int)ad.Inputs[0]));
                            int ib = Phys(checked((int)ad.Inputs[1]));
                            uint other = ia == prev ? ad.Inputs[1]
                                       : ib == prev ? ad.Inputs[0] : uint.MaxValue;
                            if (other != uint.MaxValue && !isConst[(int)other]
                                && numel[(int)other] == numel[prev]
                                && refCount[prev] == 1)
                            { resT = other; ge = j; j++; }
                        }
                        if (j < nodes.Length
                            && nodes[j].Operator == OperatorId.Div
                            && Environment.GetEnvironmentVariable("SIMD_OCR_NOEXTG") == null
                            && _compiled.FusedSkip(j) == 4
                            && Phys(checked((int)nodes[j].Inputs[0]))
                                == Phys(checked((int)nodes[ge].Outputs[0])))
                        {
                            int preG = Phys(checked((int)nodes[ge].Outputs[0]));
                            if (refCount[preG] == 1 && act == 0)
                            { act = 2; ge = j + 4; }
                            else if (refCount[preG] == 2)
                            {
                                // out also feeds a residual elsewhere — conv dual-
                                // writes plain out (preG) and gelu(out) (gelu sink)
                                dualT = (uint)Phys(checked((int)nodes[j + 4].Outputs[0]));
                                outPhys = preG;
                                ge = j + 4;
                            }
                        }
                        if (ge != ni + skip)
                        {
                            if (dualT == uint.MaxValue)
                                outPhys = Phys(checked((int)nodes[ge].Outputs[0]));
                            skip = ge - ni;
                        }
                    }
                    bool hasPs = prescale.TryGetValue(ni, out (uint x, uint se) psv);
                    uint flags = hasBias | scalarBias | (uint)(act << 4) | flags16
                        | (resT != uint.MaxValue ? 2u : 0u)
                        | (hasPs ? 4u : 0u)
                        | (dualT != uint.MaxValue ? 8u : 0u)
                        | (dualRaw ? 1024u : 0u);

                    if (kH == 1 && kW == 1 && sH == 1 && sW == 1 && group == 1)
                    {
                        int inT = Phys(checked((int)node.Inputs[0]));
                        int cinIn = (inT == inIdx && cin % 4 != 0) ? 4 : cin;
                        if (cinIn % 4 != 0)
                            throw new NotSupportedException($"conv1x1 cin={cin} not %4 at node {ni}");
                        MtlBuffer wbuf = ConstF16(checked((int)node.Inputs[1]),
                            padRows: ((cout + 127) / 128) * 128, rowElems: cin,
                            rowPad: cinIn);
                        uint mImg = (uint)(outH * outW);
                        uint M = mImg * (uint)nb;   // flat rows span the batch
                        bool dotOk = cout % 4 == 0 && scalarBias == 0
                            && (cinIn <= 128 || (hasPs && cinIn <= 256))
                            && Environment.GetEnvironmentVariable("SIMD_OCR_NODOT") == null;
                        // sg32 coopmat (SE prescale included) outruns the dot
                        // kernel once the output leaves split-K range (lite:
                        // a quarter of that already);
                        // addps-absorbed inputs need the dot kernel's fused read
                        if (dotOk && _sg32 && (long)M * cout > 1L << (_lite ? 16 : 18)
                            && (hasPs || !addpsSrc.ContainsKey(Phys(checked((int)node.Inputs[0])))))
                            dotOk = false;
                        if (dotOk)
                        {
                            // small-K pointwise conv: direct dot kernel beats coopmat.
                            // prescale: read x (not the mul output) + per-channel se scale.
                            long aOff = hasPs ? SlotOf(psv.x) : SlotOf(node.Inputs[0]);
                            bool aps = addpsSrc.TryGetValue(
                                Phys(checked((int)node.Inputs[0])), out var ads)
                                && !hasPs;
                            if (aps) aOff = SlotOf(ads.x);
                            MtlBuffer wk = ConstKMajor(checked((int)node.Inputs[1]),
                                cout, cin, 1, cinIn, cinIn);
                            // se tensors are per-batch [n, C] — mImg lets the
                            // kernel pick the batch's scale vector; 0 = batch-free.
                            uint mIm = hasPs || aps ? mImg : 0u;
                            uint dFlags = flags | (aps ? 512u : 0u);
                            long dTiles = ((M + 3) / 4) * (long)(cout / 4);
                            bool dSplit = cinIn >= 64 && dTiles <= 16384 && !s_noSplitK
                                && (dFlags & (8u | 512u | 1024u)) == 0;
                            Emit(dSplit ? _pDotSk : _pDot, $"conv1x1d{(dSplit ? "sk" : "")} n{ni} {M}x{cinIn}x{cout}",
                                [(arena, aOff, 2), (wk, 0, 2),
                                 (biasBuf, 0, 2),
                                 (arena, resT != uint.MaxValue ? SlotOf(resT) : 0, 2),
                                 (arena, off[outPhys], 2),
                                 (arena, hasPs ? SlotOf(psv.se)
                                              : aps ? SlotOf(ads.se) : 0, 2),
                                 (arena, dualT != uint.MaxValue ? SlotOf(dualT) : 0, 2),
                                 (arena, aps ? SlotOf(ads.a) : 0, 2)],
                                [M, (uint)cout, (uint)cinIn, (uint)(cinIn / 4),
                                 dFlags, (uint)(cinIn / 4), mIm],
                                dSplit ? (uint)((dTiles + 15) / 16) : Div256(dTiles));
                        }
                        else
                        {
                            EmitMm(hasPs, $"conv1x1 n{ni} {M}x{cin}x{cout}",
                                [(arena, hasPs ? SlotOf(psv.x) : SlotOf(node.Inputs[0]), 2), (wbuf, 0, 2),
                                 (biasBuf, 0, 2),
                                 (arena, resT != uint.MaxValue ? SlotOf(resT) : 0, 2),
                                 (arena, off[outPhys], 2),
                                 (arena, dualT != uint.MaxValue ? SlotOf(dualT) : 0, 2),
                                 (arena, hasPs ? SlotOf(psv.se) : 0, 2)],
                                M, (uint)cout, (uint)cinIn, flags,
                                hasPs ? mImg : 0u, (uint)(cinIn / 4));
                        }
                    }
                    else if (group == cin && cout == cin)
                    {
                        if (cin % 4 == 0)
                        {
                            if (DwTiled(kH, kW, sH, sW, (long)inH * inW))
                            {
                                // shared-tile variant: ~kH*kW less global traffic
                                uint tx = (uint)((outW + 15) / 16),
                                     ty = (uint)((outH + 15) / 16);
                                bool aps = addpsSrc.TryGetValue(
                                    Phys(checked((int)node.Inputs[0])), out var ads);
                                Emit(_pDw4T, $"conv_dw4t n{ni} {cout}ch k{kH}s{sH}",
                                    [(arena, aps ? SlotOf(ads.x)
                                                : SlotOf(node.Inputs[0]), 2),
                                     (ConstDwTap(checked((int)node.Inputs[1]), cout, kH * kW), 0, 2),
                                     (biasBuf, 0, 2), (arena, off[outPhys], 2),
                                     (arena, aps ? SlotOf(ads.a) : 0, 2),
                                     (arena, aps ? SlotOf(ads.se) : 0, 2)],
                                    [(uint)outW, (uint)outH, (uint)cout, (uint)kH, (uint)kW,
                                     (uint)sH, (uint)sW, (uint)pt, (uint)pl,
                                     (uint)inW, (uint)inH,
                                     flags | (aps ? 256u : 0u)],
                                    tx * ty * (uint)(cout / 4), (uint)nb);
                            }
                            else if (DwFlatA(kH, kW, sH, sW, (long)inH * inW))
                            {
                                bool aps = addpsSrc.TryGetValue(
                                    Phys(checked((int)node.Inputs[0])), out var ads);
                                Emit(_pDw4A!, $"conv_dw4a n{ni} {cout}ch k{kH}s{sH}",
                                    [(arena, aps ? SlotOf(ads.x)
                                                : SlotOf(node.Inputs[0]), 2),
                                     (ConstDwTap(checked((int)node.Inputs[1]), cout, kH * kW), 0, 2),
                                     (biasBuf, 0, 2), (arena, off[outPhys], 2),
                                     (arena, aps ? SlotOf(ads.a) : 0, 2),
                                     (arena, aps ? SlotOf(ads.se) : 0, 2)],
                                    [(uint)outW, (uint)outH, (uint)cout, (uint)kH, (uint)kW,
                                     (uint)sH, (uint)sW, (uint)pt, (uint)pl,
                                     (uint)inW, (uint)inH,
                                     flags | (aps ? 256u : 0u)],
                                    Div256((long)outW * outH * (cout / 4)), (uint)nb);
                            }
                            else
                            Emit(_pDw4, $"conv_dw4 n{ni} {cout}ch k{kH}s{sH}",
                                [(arena, SlotOf(node.Inputs[0]), 2),
                                 (ConstDwTap(checked((int)node.Inputs[1]), cout, kH * kW), 0, 2),
                                 (biasBuf, 0, 2), (arena, off[outPhys], 2)],
                                [(uint)outW, (uint)outH, (uint)cout, (uint)kH, (uint)kW,
                                 (uint)sH, (uint)sW, (uint)pt, (uint)pl,
                                 (uint)inW, (uint)inH, flags],
                                Div256((long)outW * outH * (cout / 4)),
                                (uint)nb);
                        }
                        else
                        {
                            if (nb > 1)
                                throw new NotSupportedException(
                                    $"scalar dw conv lacks batch support (n{ni})");
                            Emit(_pDw, $"conv_dw n{ni} {cout}ch k{kH}s{sH}",
                                [(arena, SlotOf(node.Inputs[0]), 2),
                                 (ConstF16(checked((int)node.Inputs[1])), 0, 2),
                                 (biasBuf, 0, 2), (arena, off[outPhys], 2)],
                                [(uint)outW, (uint)outH, (uint)cout, (uint)kH, (uint)kW,
                                 (uint)sH, (uint)sW, (uint)pt, (uint)pl,
                                 (uint)inW, (uint)inH, flags],
                                Div256((long)outW * outH * cout));
                        }
                    }
                    else if (group == 1)
                    {
                        // dense kxk conv → explicit im2col (tap-major) + coopmat GEMM.
                        // graph-input channels are physically padded to 4 (cinIn).
                        int inT = Phys(checked((int)node.Inputs[0]));
                        int cinIn = (inT == inIdx && cin % 4 != 0) ? 4 : cin;
                        int K = cinIn * kH * kW, Kp = (K + 15) / 16 * 16;
                        uint M = (uint)(outH * outW);
                        // im2col-free direct conv: tap addressing inline in the
                        // dot kernel; skips materializing the K-expanded matrix.
                        // batched graphs always take it: the im2col fallback is batch-free
                        if (cout % 4 == 0 && scalarBias == 0 && cinIn % 4 == 0
                            && (nb > 1 || Kp <= (Environment.GetEnvironmentVariable(
                                "SIMD_OCR_CONVD_KMAX") is string km
                                ? int.Parse(km) : 1024))
                            && Environment.GetEnvironmentVariable("SIMD_OCR_NODCONV") == null)
                        {
                            // stem conv on the fp32 NCHW input: skip nchw2nhwc
                            // when this is the sole consumer of the graph input
                            bool f32In = inT == inIdx && cinIn == 4 && cin <= 4
                                && Environment.GetEnvironmentVariable(
                                    "SIMD_OCR_NOF32IN") == null;
                            if (f32In && (consumers[inIdx]?.Count ?? 0) == 1)
                                inF32Consumed = true;
                            // sole-consumer concat: write straight into its slice
                            long wO = off[outPhys]; uint dcv = 0, dco = 0;
                            {
                                List<int>? cs = consumers[outPhys];
                                if (!_noCatAbs && refCount[outPhys] == 1 && cs != null
                                    && cs.Count == 1
                                    && nodes[cs[0]].Operator == OperatorId.Concat)
                                {
                                    int cn = cs[0];
                                    int[] ospc = shapes[nodes[cn].Outputs[0]];
                                    int co = 0; bool hit = false;
                                    foreach (uint cin_ in nodes[cn].Inputs)
                                    {
                                        if (Phys(checked((int)cin_)) == outPhys)
                                        { hit = true; break; }
                                        co += shapes[checked((int)cin_)][1];
                                    }
                                    if (hit && co % 4 == 0 && ospc[1] % 4 == 0)
                                    {
                                        wO = off[Phys(checked((int)nodes[cn].Outputs[0]))];
                                        dcv = (uint)(ospc[1] / 4);
                                        dco = (uint)(co / 4);
                                        concatAbsorbed.Add(outPhys);
                                    }
                                }
                            }
                            if (_sgm && !_noIc && nb == 1 && !f32In
                                && !concatAbsorbed.Contains(outPhys))
                            {
                                // unbatched conv: implicit-GEMM (tap gather in
                                // the MMA staging loop) beats the scalar-dot
                                // convd kernel — same weights, tap-major pack.
                                MtlBuffer wic = ConstTapMajor(checked((int)node.Inputs[1]),
                                    cout, cin, kH, kW, Kp, cinPad: cinIn);
                                Emit(_pMmIc32, $"icconv n{ni} {M}x{Kp}x{cout}",
                                    [(arena, SlotOf(node.Inputs[0]), 2),
                                     (wic, 0, 2),
                                     (biasBuf, 0, 2),
                                     (arena, resT != uint.MaxValue ? SlotOf(resT) : 0, 2),
                                     (arena, off[outPhys], 2),
                                     (arena, dualT != uint.MaxValue ? SlotOf(dualT) : 0, 2),
                                     (arena, 0, 2)],
                                    [M, (uint)cout, (uint)Kp, (uint)(Kp / 4),
                                     flags, 0u, 0u,
                                     (uint)outW, (uint)inW, (uint)inH,
                                     (uint)sH, (uint)sW, (uint)pt, (uint)pl,
                                     (uint)kW, (uint)cinIn],
                                    ((uint)cout + 63) / 64, (M + 63) / 64);
                            }
                            else
                            Emit(f32In ? _pConvDF32 : _pConvD,
                                $"convd n{ni} {M}x{K}x{cout}",
                                [(f32In ? inF32 : arena,
                                  f32In ? 0 : SlotOf(node.Inputs[0]),
                                  f32In ? 4 : 2),
                                 (ConstKMajor(checked((int)node.Inputs[1]),
                                     cout, cin, kH * kW, Kp, cinIn), 0, 2),
                                 (biasBuf, 0, 2),
                                 (arena, resT != uint.MaxValue ? SlotOf(resT) : 0, 2),
                                 (arena, wO, 2)],
                                f32In
                                ? [M, (uint)cout, (uint)outW, (uint)inW, (uint)inH,
                                   (uint)(cinIn / 4), (uint)(kH * kW), (uint)kW,
                                   (uint)sH, (uint)sW, (uint)pt, (uint)pl, flags,
                                   dcv, dco, (uint)cin, (uint)(inH * inW)]
                                : [M, (uint)cout, (uint)outW, (uint)inW, (uint)inH,
                                   (uint)(cinIn / 4), (uint)(kH * kW), (uint)kW,
                                   (uint)sH, (uint)sW, (uint)pt, (uint)pl, flags,
                                   dcv, dco],
                                Div256(((M + 3) / 4) * (long)(cout / 4)),
                                (uint)nb);
                        }
                        // scalarBias shares flags bit3 with the mm kernels'
                        // dual-write — the ic epilogue would write o2 garbage.
                        else if (_sgm && !_noIc && scalarBias == 0
                            && cinIn % 4 == 0 && nb == 1)
                        {
                            // implicit-GEMM conv: mm_ic_sg gathers A through
                            // tap-major im2col addressing inside the staging
                            // loop — no [M,Kp] materialization round-trip.
                            MtlBuffer wic = ConstTapMajor(checked((int)node.Inputs[1]),
                                cout, cin, kH, kW, Kp, cinPad: cinIn);
                            Emit(_pMmIc32, $"icconv n{ni} {M}x{Kp}x{cout}",
                                [(arena, SlotOf(node.Inputs[0]), 2),
                                 (wic, 0, 2),
                                 (biasBuf, 0, 2),
                                 (arena, resT != uint.MaxValue ? SlotOf(resT) : 0, 2),
                                 (arena, off[outPhys], 2),
                                 (arena, dualT != uint.MaxValue ? SlotOf(dualT) : 0, 2),
                                 (arena, 0, 2)],
                                [M, (uint)cout, (uint)Kp, (uint)(Kp / 4),
                                 flags, 0u, 0u,
                                 (uint)outW, (uint)inW, (uint)inH,
                                 (uint)sH, (uint)sW, (uint)pt, (uint)pl,
                                 (uint)kW, (uint)cinIn],
                                ((uint)cout + 63) / 64, (M + 63) / 64);
                        }
                        else
                        {
                        if (nb > 1)
                            throw new NotSupportedException(
                                $"im2col conv path lacks batch support (n{ni})");
                        maxIm2col = Math.Max(maxIm2col, (long)M * Kp);
                        Emit(_pIm2col, $"im2col n{ni} M{M} K{K}",
                            [(arena, SlotOf(node.Inputs[0]), 2),
                             (arena, im2colOff, 2)],
                            [(uint)outW, (uint)outH, (uint)cinIn, (uint)kH, (uint)kW,
                             (uint)sH, (uint)sW, (uint)pt, (uint)pl,
                             (uint)inW, (uint)inH, (uint)K, (uint)Kp,
                             cinIn % 4 != 0 ? 1u : 0u],
                            Div256(M * (long)(Kp / 4)));
                        MtlBuffer wbuf = ConstTapMajor(checked((int)node.Inputs[1]),
                            cout, cin, kH, kW, Kp, cinPad: cinIn);
                        if (cout % 4 == 0 && scalarBias == 0 && Kp <= 128)
                        {
                            MtlBuffer wk = ConstKMajor(checked((int)node.Inputs[1]),
                                cout, cin, kH * kW, Kp, cinIn);
                            Emit(_pDot, $"im2c_dot n{ni} {M}x{Kp}x{cout}",
                                [(arena, im2colOff, 2), (wk, 0, 2),
                                 (biasBuf, 0, 2), (arena, 0, 2),
                                 (arena, off[outPhys], 2), (arena, 0, 2),
                                 (arena, 0, 2)],
                                [M, (uint)cout, (uint)Kp, (uint)(Kp / 4),
                                 flags, 0u, 0u],
                                Div256(((M + 3) / 4) * (long)(cout / 4)));
                        }
                        else
                        {
                            // ConstTapMajor W is already n-major [Cout][Kp]
                            // (row = tap*cinPad+ci) — mm_* read it directly.
                            EmitMm(false, $"im2colconv n{ni} {M}x{Kp}x{cout}",
                                [(arena, im2colOff, 2), (wbuf, 0, 2),
                                 (biasBuf, 0, 2), (arena, 0, 2), (arena, off[outPhys], 2),
                                 (arena, 0, 2), (arena, 0, 2)],
                                M, (uint)cout, (uint)Kp, flags, 0u, 0u);
                        }
                        }
                    }
                    else
                    {
                        if (nb > 1)
                            throw new NotSupportedException(
                                $"dense conv path lacks batch support (n{ni})");
                        Emit(_pDense, $"conv3x3 n{ni} {cin}->{cout} k{kH}s{sH}",
                            [(arena, SlotOf(node.Inputs[0]), 2),
                             (ConstF16(checked((int)node.Inputs[1])), 0, 2),
                             (biasBuf, 0, 2), (arena, off[outPhys], 2)],
                            [(uint)outW, (uint)outH, (uint)cout, (uint)cin,
                             (uint)kH, (uint)kW, (uint)sH, (uint)sW,
                             (uint)pt, (uint)pl, (uint)inW, (uint)inH, flags],
                            Div256((long)outW * outH * cout));
                    }
                    ni += skip;
                    break;
                }

                case OperatorId.Div when skip == 4:
                {
                    // fused GELU: write to the group sink (last Mul output)
                    long n = numel[Phys(checked((int)nodes[ni + 4].Outputs[0]))];
                    Emit(n % 4 == 0 ? _pElem4 : _pElem, $"gelu n{ni}",
                        [(arena, SlotOf(node.Inputs[0]), 2),
                         (arena, 0, 2), (arena, off[outPhys], 2)],
                        [(uint)n, 1u, 2u, 0u, 0u], Div256(n % 4 == 0 ? n / 4 : n));
                    ni += 4;
                    break;
                }

                case OperatorId.Add or OperatorId.Mul or OperatorId.Sub or OperatorId.Div
                    or OperatorId.Pow:
                {
                    long n = numel[outPhys];
                    if (addScale.TryGetValue(ni, out (uint x, uint se, uint oth) asc))
                    {
                        if (addpsSrc.ContainsKey(outPhys)) break; // consumer absorbs
                        // a + x*se — the SE Mul got skipped, fold it here
                        // per-batch se vector: imgV = vec4 count of one image
                        long seN = numel[(int)asc.se];
                        Emit(_pAddPs, $"addps n{ni}",
                            [(arena, SlotOf(asc.oth), 2), (arena, SlotOf(asc.x), 2),
                             (arena, SlotOf(asc.se), 2), (arena, off[outPhys], 2)],
                            [(uint)n, (uint)(seN / 4 / nb),
                             (uint)(seN == n ? 0 : n / 4 / nb)], Div256(n / 4));
                        break;
                    }
                    int[] osp = shapes[checked((int)node.Outputs[0])];
                    int chan = osp.Length >= 2 ? osp[1] : (int)n;
                    (MtlBuffer bA, long oA, uint mA) = Operand(checked((int)node.Inputs[0]), chan, n);
                    (MtlBuffer bB, long oB, uint mB) = Operand(checked((int)node.Inputs[1]), chan, n);
                    // vector broadcast along the contiguous (last physical) dim:
                    // rank-3 tails like [n,T,C] + [C] need C as the modulus —
                    // the vector operand's own numel, not osp[1].
                    {
                        long neA = numel[checked((int)node.Inputs[0])];
                        long neB = numel[checked((int)node.Inputs[1])];
                        // per-image channel vector [n,C,1,1] (nel == chan*nb):
                        // mode 3 = kernel picks b[(i/perImg)*C + i%C] using aux;
                        // flat tail vector [C] vs [n,T,C]: mode 1, chan = neB.
                        if (mB == 2 && neB > 1 && neB < n)
                        { if (neB == (long)chan * nb) mB = 3; else { mB = 1; chan = (int)neB; } }
                        else if (mA == 2 && neA > 1 && neA < n)
                        { if (neA == (long)chan * nb) mA = 3; else { mA = 1; chan = (int)neA; } }
                    }
                    uint op2 = node.Operator switch
                    {
                        OperatorId.Add => 8u, OperatorId.Mul => 9u, OperatorId.Sub => 10u,
                        OperatorId.Div => 11u, OperatorId.Pow => 13u, _ => 8u,
                    };
                    bool v4 = n % 4 == 0 && (mA is not (1 or 3) || chan % 4 == 0)
                        && (mB is not (1 or 3) || chan % 4 == 0);
                    Emit(v4 ? _pElem4 : _pElem, $"bin{node.Operator} n{ni}",
                        [(bA, oA, 2), (bB, oB, 2), (arena, off[outPhys], 2)],
                        [(uint)n, (uint)chan, op2, mA, mB, (uint)(n / nb)], Div256(v4 ? n / 4 : n));
                    break;
                }

                case OperatorId.Relu or OperatorId.Sigmoid or OperatorId.HardSigmoid
                    or OperatorId.Erf or OperatorId.Sqrt:
                {
                    // compiler-fused HS+Mul (hardswish, x*hs(x)): emit op 14
                    // against the group's sink instead of a bare hardsigmoid.
                    bool hswish = node.Operator == OperatorId.HardSigmoid
                        && skip == 1
                        && nodes[ni + 1].Operator == OperatorId.Mul
                        && Phys(checked((int)nodes[ni + 1].Inputs[0]))
                           == Phys(checked((int)node.Outputs[0]))
                        && Phys(checked((int)nodes[ni + 1].Inputs[1]))
                           == Phys(checked((int)node.Inputs[0]));
                    if (hswish) ni += 1;
                    long n = numel[outPhys];
                    uint op2 = node.Operator switch
                    {
                        OperatorId.Relu => 1u, OperatorId.HardSigmoid => 3u,
                        OperatorId.Sigmoid => 4u, OperatorId.Erf => 5u,
                        OperatorId.Sqrt => 6u, _ => 0u,
                    };
                    if (hswish) op2 = 14u;
                    uint aux = 0u;
                    if (node.Operator == OperatorId.HardSigmoid)
                        aux = HsAux(_model.GetParameters(node));
                    Emit(n % 4 == 0 ? _pElem4 : _pElem, $"un{node.Operator} n{ni}",
                        [(arena, SlotOf(node.Inputs[0]), 2),
                         (arena, 0, 2), (arena, off[outPhys], 2)],
                        [(uint)n, 1u, op2, 0u, 0u, aux], Div256(n % 4 == 0 ? n / 4 : n));
                    break;
                }

                case OperatorId.ReduceMean when skip == 8:
                {
                    // compiler-fused LayerNorm over the last axis
                    int xT = checked((int)node.Inputs[0]);
                    int[] xs = shapes[xT];
                    int cN = xs[^1];
                    int xP = Phys(xT);
                    // last axis must be physically contiguous: rank-3 row-major,
                    // or an NHWC slab whose channel dim is that axis
                    bool contiguous = xs.Length == 3
                        && (shapes[xP].Length != 4 || shapes[xP][1] == cN);
                    int ConstIn(NodeRecord nd, int other)
                    {
                        int a0 = checked((int)nd.Inputs[0]), a1 = checked((int)nd.Inputs[1]);
                        int c = Phys(a0) == Phys(other) ? a1 : Phys(a1) == Phys(other) ? a0 : -1;
                        return c >= 0 && isConst[c] ? c : -1;
                    }
                    NodeRecord nSub = nodes[ni + 1], nPow = nodes[ni + 2], nRm = nodes[ni + 3],
                        nEps = nodes[ni + 4], nSq = nodes[ni + 5], nDiv = nodes[ni + 6],
                        nG = nodes[ni + 7], nB = nodes[ni + 8];
                    int powC = nPow.Operator == OperatorId.Pow
                        ? ConstIn(nPow, checked((int)nSub.Outputs[0])) : -1;
                    int epsC = nEps.Operator == OperatorId.Add
                        ? ConstIn(nEps, checked((int)nRm.Outputs[0])) : -1;
                    int gC = nG.Operator == OperatorId.Mul
                        ? ConstIn(nG, checked((int)nDiv.Outputs[0])) : -1;
                    int bC = nB.Operator == OperatorId.Add
                        ? ConstIn(nB, checked((int)nG.Outputs[0])) : -1;
                    bool lastAxis = U16(p, 2) == 1
                        && (I32(p, 12) == -1 || I32(p, 12) == xs.Length - 1);
                    if (!contiguous || !lastAxis || cN > 1024 || numel[xT] / cN > 65535
                        || nSub.Operator != OperatorId.Sub
                        || nRm.Operator != OperatorId.ReduceMean || nSq.Operator != OperatorId.Sqrt
                        || nDiv.Operator != OperatorId.Div || powC < 0 || epsC < 0 || gC < 0
                        || bC < 0 || CstF32(powC)[0] != 2f || numel[epsC] != 1
                        || numel[gC] != cN || numel[bC] != cN)
                        throw new NotSupportedException($"layernorm pattern at node {ni}");
                    long rowsLn = numel[xT] / cN;
                    Emit(_pLn, $"layernorm n{ni} {rowsLn}x{cN}",
                        [(arena, SlotOf(node.Inputs[0]), 2), (ConstF32(gC), 0, 4),
                         (ConstF32(bC), 0, 4), (arena, off[outPhys], 2)],
                        [(uint)rowsLn, (uint)cN, BitConverter.SingleToUInt32Bits(CstF32(epsC)[0])],
                        (uint)rowsLn);
                    ni += 8;
                    break;
                }

                case OperatorId.ReduceMean:
                {
                    int[] ishp = shapes[node.Inputs[0]];
                    int hw = ishp[2] * ishp[3], c = ishp[1];
                    int cv4 = c / 4;
                    if (seEmit.TryGetValue(ni, out (int fc1, int fc2, int hs, uint b1, uint b2) sev))
                    {
                        NodeRecord f1 = nodes[sev.fc1], f2 = nodes[sev.fc2];
                        ReadOnlySpan<byte> hpp = _model.GetParameters(nodes[sev.hs]);
                        int rDim = shapes[Phys(checked((int)f1.Outputs[0]))][1];
                        uint cvP = 1; while (cvP < (uint)(c / 4)) cvP <<= 1;
                        int hsOut = Phys(checked((int)nodes[sev.hs].Outputs[0]));
                        int s = PartSplits(hw, c);
                        int pp = (hw + s - 1) / s;
                        MtlBuffer pb2 = PartBuf(s * c * nb);
                        uint[] pcSe = [(uint)hw, (uint)c, (uint)s, (uint)pp, cvP,
                             (uint)rDim,
                             BitConverter.SingleToUInt32Bits(F32(hpp, 4)),
                             BitConverter.SingleToUInt32Bits(F32(hpp, 8))];
                        // paravirt atomics are relaxed-only: two dispatches
                        // (partials → barrier → single-WG join) replace the
                        // Vulkan ticket handshake.
                        Emit(_pSePart, $"se_p n{ni} c{c} s{s} r{rDim}",
                            [(arena, SlotOf(node.Inputs[0]), 2), (pb2, 0, 2)],
                            pcSe, (uint)s, (uint)nb);
                        Emit(_pSeJoin, $"se_j n{ni} c{c} s{s} r{rDim}",
                            [(pb2, 0, 2),
                             (ConstF32(checked((int)f1.Inputs[1])), 0, 4),
                             (ConstF32(checked((int)sev.b1)), 0, 4),
                             (ConstF32(checked((int)f2.Inputs[1])), 0, 4),
                             (ConstF32(checked((int)sev.b2)), 0, 4),
                             (arena, off[hsOut], 2)],
                            pcSe, (uint)nb, 1);
                        break;
                    }
                    // lite parts take it at any size: reduce_hw's one-channel
                    // workgroups read 2 bytes at a C*2 stride
                    if (c % 4 == 0 && 256 % cv4 == 0 && (hw >= 4096 || _lite))
                    {
                        // two-phase: S pixel partitions → fp32 partials → mean
                        int s = PartSplits(hw, c);
                        int pp = (hw + s - 1) / s;
                        MtlBuffer pb = PartBuf(s * c * nb);
                        Emit(_pReduce4, $"reduce4a n{ni} c{c}",
                            [(arena, SlotOf(node.Inputs[0]), 2), (pb, 0, 2)],
                            [(uint)hw, (uint)c, (uint)s, (uint)pp],
                            (uint)s, (uint)nb);
                        Emit(_pReduce4b, $"reduce4b n{ni} c{c}",
                            [(pb, 0, 2), (arena, off[outPhys], 2)],
                            [(uint)s, (uint)c, (uint)hw], (uint)c, (uint)nb);
                    }
                    else
                        Emit(_pReduce, $"reduceHW n{ni} c{c}",
                            [(arena, SlotOf(node.Inputs[0]), 2), (arena, off[outPhys], 2)],
                            [(uint)hw, (uint)c], (uint)c, (uint)nb);
                    break;
                }

                case OperatorId.MaxPool:
                {
                    int[] ishp = shapes[node.Inputs[0]];
                    // both kernels hard-code 2x2 / stride 1 / pad-end
                    if (!(I32(p, 8) == 2 && I32(p, 12) == 2 && I32(p, 16) == 1
                          && I32(p, 20) == 1 && I32(p, 24) == 0 && I32(p, 28) == 0
                          && shapes[node.Outputs[0]][2] == ishp[2]
                          && shapes[node.Outputs[0]][3] == ishp[3]))
                        throw new NotSupportedException($"maxpool shape at node {ni}");
                    if (ishp[1] % 4 == 0)
                    {
                        long wO = off[outPhys]; uint dcv = 0, dco = 0;
                        {
                            int rp = outPhys;
                            List<int>? cs = consumers[rp];
                            if (!_noCatAbs && refCount[rp] == 1 && cs != null && cs.Count == 1
                                && nodes[cs[0]].Operator == OperatorId.Concat)
                            {
                                int cn = cs[0];
                                int[] ospc = shapes[nodes[cn].Outputs[0]];
                                int co = 0; bool hit = false;
                                foreach (uint cin_ in nodes[cn].Inputs)
                                {
                                    if (Phys(checked((int)cin_)) == rp) { hit = true; break; }
                                    co += shapes[checked((int)cin_)][1];
                                }
                                if (hit && co % 4 == 0 && ospc[1] % 4 == 0)
                                {
                                    wO = off[Phys(checked((int)nodes[cn].Outputs[0]))];
                                    dcv = (uint)(ospc[1] / 4);
                                    dco = (uint)(co / 4);
                                    concatAbsorbed.Add(rp);
                                }
                            }
                        }
                        Emit(_pPool4, $"maxpool4 n{ni}",
                            [(arena, SlotOf(node.Inputs[0]), 2), (arena, wO, 2)],
                            [(uint)ishp[3], (uint)ishp[2], (uint)ishp[1], dcv, dco],
                            Div256(numel[outPhys] / 4 / nb), (uint)nb);
                    }
                    else if (nb > 1)
                        throw new NotSupportedException($"scalar maxpool lacks batch support (n{ni})");
                    else
                        Emit(_pPool, $"maxpool n{ni}",
                            [(arena, SlotOf(node.Inputs[0]), 2), (arena, off[outPhys], 2)],
                            [(uint)ishp[3], (uint)ishp[2], (uint)ishp[1]],
                            Div256(numel[outPhys]));
                    break;
                }

                case OperatorId.Resize:
                {
                    if (nb > 1)
                        throw new NotSupportedException(
                            $"resize lacks batch support (n{ni})");
                    int[] ishp = shapes[node.Inputs[0]];
                    int[] osp = shapes[node.Outputs[0]];
                    if (osp[1] % 4 == 0)
                    {
                        // sole-consumer fusion: resize -> Add (FPN merge) or
                        // resize -> Concat (write into the channel slice)
                        int rp = outPhys;
                        List<int>? cs = consumers[rp];
                        int cn = refCount[rp] == 1 && cs != null && cs.Count == 1
                            ? cs[0] : -1;
                        if (cn >= 0 && nodes[cn].Operator == OperatorId.Add
                            && _compiled.FusedSkip(cn) == 0 && !inConvGroup[cn]
                            && !addScale.ContainsKey(cn))
                        {
                            NodeRecord ad = nodes[cn];
                            uint oth = ad.Inputs[0] == node.Outputs[0]
                                ? ad.Inputs[1] : ad.Inputs[0];
                            int othP = Phys(checked((int)oth));
                            if (!isConst[othP] && numel[othP] == numel[rp]
                                && Phys(checked((int)ad.Inputs[0]))
                                   != Phys(checked((int)ad.Inputs[1])))
                            {
                                int ao = Phys(checked((int)ad.Outputs[0]));
                                // addps-absorb on either operand
                                long xOff4 = SlotOf(node.Inputs[0]);
                                long aOff4 = SlotOf(oth), raOff4 = 0, seOff4 = 0;
                                uint raFl = 0;
                                if (addpsSrc.TryGetValue(
                                    Phys(checked((int)node.Inputs[0])), out var adx))
                                { xOff4 = SlotOf(adx.x); raOff4 = SlotOf(adx.a);
                                  seOff4 = SlotOf(adx.se); raFl |= 256u; }
                                if (addpsSrc.TryGetValue(
                                    Phys(checked((int)oth)), out var ada))
                                { aOff4 = SlotOf(ada.x); raOff4 = SlotOf(ada.a);
                                  seOff4 = SlotOf(ada.se); raFl |= 512u; }
                                Emit(_pResize4Add, $"resizeadd n{ni}+{cn}",
                                    [(arena, xOff4, 2),
                                     (arena, aOff4, 2),
                                     (arena, off[ao], 2),
                                     (arena, raOff4, 2), (arena, seOff4, 2)],
                                    [(uint)osp[3], (uint)osp[2], (uint)osp[1],
                                     (uint)(osp[2] / ishp[2]), (uint)(osp[3] / ishp[3]),
                                     raFl],
                                    Div256(numel[rp] / 4));
                                skipEmit.Add(cn);
                                break;
                            }
                        }
                        long wO = off[outPhys]; uint dcv = 0, dco = 0;
                        if (!_noCatAbs && cn >= 0 && nodes[cn].Operator == OperatorId.Concat)
                        {
                            int[] ospc = shapes[nodes[cn].Outputs[0]];
                            int co = 0; bool hit = false;
                            foreach (uint cin_ in nodes[cn].Inputs)
                            {
                                if (Phys(checked((int)cin_)) == rp) { hit = true; break; }
                                co += shapes[checked((int)cin_)][1];
                            }
                            if (hit && co % 4 == 0 && ospc[1] % 4 == 0)
                            {
                                wO = off[Phys(checked((int)nodes[cn].Outputs[0]))];
                                dcv = (uint)(ospc[1] / 4);
                                dco = (uint)(co / 4);
                                concatAbsorbed.Add(rp);
                            }
                        }
                        bool aps = addpsSrc.TryGetValue(
                            Phys(checked((int)node.Inputs[0])), out var ads);
                        Emit(_pResize4, $"resize4 n{ni} x{osp[2] / ishp[2]}",
                            [(arena, aps ? SlotOf(ads.x)
                                        : SlotOf(node.Inputs[0]), 2),
                             (arena, wO, 2),
                             (arena, aps ? SlotOf(ads.a) : 0, 2),
                             (arena, aps ? SlotOf(ads.se) : 0, 2)],
                            [(uint)osp[3], (uint)osp[2], (uint)osp[1],
                             (uint)(osp[2] / ishp[2]), (uint)(osp[3] / ishp[3]),
                             dcv, dco, aps ? 256u : 0u],
                            Div256(numel[outPhys] / 4));
                    }
                    else
                        Emit(_pResize, $"resize n{ni} x{osp[2] / ishp[2]}",
                            [(arena, SlotOf(node.Inputs[0]), 2), (arena, off[outPhys], 2)],
                            [(uint)osp[3], (uint)osp[2], (uint)osp[1],
                             (uint)(osp[2] / ishp[2]), (uint)(osp[3] / ishp[3])],
                            Div256(numel[outPhys]));
                    break;
                }

                case OperatorId.Concat:
                {
                    int[] osp = shapes[node.Outputs[0]];
                    if (osp.Length != 4 || (I32(p, 4) is int cax && cax != 1 && cax != -3))
                        throw new NotSupportedException($"concat axis/rank at node {ni}");
                    // NHWC channel concat: pixels are flat over the batch too
                    long catPx = (long)osp[2] * osp[3] * nb;
                    if (catRes.TryGetValue(ni, out var spec))
                    {
                        var bb = new (MtlBuffer, long, int)[13];
                        var pc2 = new uint[19];
                        pc2[0] = (uint)osp[3]; pc2[1] = (uint)osp[2];
                        pc2[2] = (uint)osp[1];
                        for (int s = 0; s < 4; s++)
                        {
                            long xP = 0, raP = 0, seP = 0;
                            uint fl = 0, inW3 = 0, fhfw = 0, offc = 0;
                            if (s < spec.Length)
                            {
                                var t = spec[s];
                                xP = t.Item1; raP = t.Item2; seP = t.Item3;
                                fl = t.Item4; inW3 = t.Item5;
                                fhfw = t.Item6 | (t.Item7 << 16);
                                offc = t.Item8 | (t.Item9 << 16);
                            }
                            bb[s * 3] = (arena, xP, 2);
                            bb[s * 3 + 1] = (arena, raP, 2);
                            bb[s * 3 + 2] = (arena, seP, 2);
                            pc2[3 + s * 4] = offc; pc2[4 + s * 4] = inW3;
                            pc2[5 + s * 4] = fhfw; pc2[6 + s * 4] = fl;
                        }
                        bb[12] = (arena, off[outPhys], 2);
                        Emit(_pCatRes, $"catres n{ni}", bb, pc2,
                            Div256(numel[outPhys] / 4));
                        break;
                    }
                    int cOff = 0;
                    foreach (uint inp in node.Inputs)
                    {
                        int it = checked((int)inp);
                        int ci = shapes[it][1];
                        if (concatAbsorbed.Contains(Phys(it)))
                        { cOff += ci; continue; }
                        if (ci % 4 == 0 && cOff % 4 == 0 && osp[1] % 4 == 0)
                        {
                            bool aps = addpsSrc.TryGetValue(Phys(it), out var ads);
                            if (aps && nb > 1)   // concat4's se index is batch-free
                                throw new NotSupportedException($"batched addps concat at node {ni}");
                            Emit(_pConcat4, $"concat4 n{ni} c{ci}@{cOff}",
                                [(arena, aps ? SlotOf(ads.x) : SlotOf(inp), 2),
                                 (arena, off[outPhys], 2),
                                 (arena, aps ? SlotOf(ads.a) : 0, 2),
                                 (arena, aps ? SlotOf(ads.se) : 0, 2)],
                                [(uint)catPx, (uint)ci, (uint)osp[1],
                                 (uint)cOff, aps ? 256u : 0u],
                                Div256(catPx * (ci / 4)));
                        }
                        else
                            Emit(_pConcat, $"concat n{ni} c{ci}@{cOff}",
                                [(arena, SlotOf(inp), 2), (arena, off[outPhys], 2)],
                                [(uint)catPx, (uint)ci, (uint)osp[1], (uint)cOff],
                                Div256(catPx * ci));
                        cOff += ci;
                    }
                    break;
                }

                case OperatorId.ConvTranspose:
                {
                    if (nb > 1)
                        throw new NotSupportedException(
                            $"convtranspose lacks batch support (n{ni})");
                    int[] ishp = shapes[node.Inputs[0]];
                    int[] oshp = shapes[node.Outputs[0]];
                    if (!(I32(p, 8) == 2 && I32(p, 12) == 2 && I32(p, 16) == 2 && I32(p, 20) == 2
                          && I32(p, 32) == 0 && I32(p, 36) == 0))
                        throw new NotSupportedException($"ConvTranspose shape at node {ni}");
                    int act = 0;
                    MtlBuffer biasBuf = arena;
                    uint flags2 = 0;
                    if (skip == 2 && nodes[ni + 1].Operator == OperatorId.Add)
                    {
                        NodeRecord add = nodes[ni + 1];
                        int bt = add.Inputs[0] == node.Outputs[0]
                            ? checked((int)add.Inputs[1]) : checked((int)add.Inputs[0]);
                        biasBuf = ConstF16(bt);
                        flags2 = 1u | (numel[bt] == 1 ? 8u : 0u);
                        OperatorId actOp = nodes[ni + 2].Operator;
                        act = actOp == OperatorId.Relu ? 1 : actOp == OperatorId.Sigmoid ? 4 : 0;
                    }
                    if (ishp[1] % 4 == 0 && oshp[1] % 4 == 0)
                        Emit(_pConvT4, $"convT4 n{ni} {ishp[1]}->{oshp[1]}",
                            [(arena, SlotOf(node.Inputs[0]), 2),
                             (ConstConvT(checked((int)node.Inputs[1]), ishp[1], oshp[1]), 0, 2),
                             (biasBuf, 0, 2), (arena, off[outPhys], 2)],
                            [(uint)oshp[3], (uint)oshp[2], (uint)oshp[1], (uint)ishp[1],
                             (uint)ishp[3], flags2 | (uint)(act << 4)],
                            Div256(numel[outPhys] / 4));
                    else
                    {
                        // scalar-tail convT writing the graph output: emit fp32
                        // straight into the readback buffer (kills the `out` rec)
                        if (outPhys == Phys(outIdx)) { flags2 |= 128u; convTOut = true; }
                        Emit(_pConvT, $"convT n{ni} {ishp[1]}->{oshp[1]}",
                            [(arena, SlotOf(node.Inputs[0]), 2),
                             (ConstF16(checked((int)node.Inputs[1])), 0, 2),
                             (biasBuf, 0, 2), (arena, off[outPhys], 2),
                             (outF32, 0, 4)],
                            [(uint)oshp[3], (uint)oshp[2], (uint)oshp[1], (uint)ishp[1],
                             (uint)ishp[3], flags2 | (uint)(act << 4)],
                            Div256(numel[outPhys]));
                    }
                    ni += skip;
                    break;
                }

                case OperatorId.Transpose:
                    // rank-3 [0,2,1] transposes were folded into aliases in
                    // pass 1 (channel-last physical layout makes them free).
                    if (Phys(checked((int)node.Outputs[0]))
                        != Phys(checked((int)node.Inputs[0])))
                        throw new NotSupportedException(
                            $"non-trivial Transpose at node {ni}");
                    break;

                case OperatorId.AveragePool:
                {
                    int[] ishp = shapes[node.Inputs[0]];
                    int[] osp2 = shapes[node.Outputs[0]];
                    if (ishp[1] % 4 != 0 || ishp.Length != 4)
                        throw new NotSupportedException(
                            $"avgpool C%4 at node {ni}");
                    Emit(_pAvg4, $"avgpool4 n{ni}",
                        [(arena, SlotOf(node.Inputs[0]), 2),
                         (arena, off[outPhys], 2)],
                        [(uint)osp2[3], (uint)osp2[2], (uint)ishp[1],
                         (uint)I32(p, 8), (uint)I32(p, 12),
                         (uint)I32(p, 16), (uint)I32(p, 20),
                         (uint)I32(p, 24), (uint)I32(p, 28),
                         (uint)ishp[3], (uint)ishp[2]],
                        Div256(numel[outPhys] / 4), (uint)nb);
                    break;
                }

                case OperatorId.BatchNormalization:
                {
                    // fold to per-channel affine: o = x*s4 + t4 where
                    // s = scale/sqrt(var+eps), t = bias - mean*s
                    float eps = F32(p, 4);
                    int bt = checked((int)node.Inputs[1]);
                    ReadOnlySpan<float> sc = CstF32(bt),
                        bi = CstF32(checked((int)node.Inputs[2])),
                        mn = CstF32(checked((int)node.Inputs[3])),
                        va = CstF32(checked((int)node.Inputs[4]));
                    int cc = sc.Length;
                    float[] s = new float[cc], t = new float[cc];
                    for (int i = 0; i < cc; i++)
                    {
                        s[i] = sc[i] / MathF.Sqrt(va[i] + eps);
                        t[i] = bi[i] - mn[i] * s[i];
                    }
                    long n = numel[outPhys];
                    if (n % 4 != 0 || cc % 4 != 0)
                        throw new NotSupportedException($"bn vec4 at node {ni}");
                    Emit(_pAffine, $"bn4 n{ni} c{cc}",
                        [(arena, SlotOf(node.Inputs[0]), 2),
                         (VecF16((ni, 0), s), 0, 2), (VecF16((ni, 1), t), 0, 2),
                         (arena, off[outPhys], 2)],
                        [(uint)(n / 4), (uint)(cc / 4)], Div256(n / 4));
                    break;
                }

                case OperatorId.Softmax:
                {
                    // last-axis softmax (cls head [n,2]); one invocation per row.
                    int[] ssp = shapes[node.Inputs[0]];
                    long cols = ssp[^1];
                    long rows = numel[outPhys] / cols;
                    if (cols <= 0 || rows <= 0 || rows * cols != numel[outPhys])
                        throw new NotSupportedException($"softmax at node {ni}");
                    Emit(_pSoftmax, $"softmax n{ni} {rows}x{cols}",
                        [(arena, SlotOf(node.Inputs[0]), 2),
                         (arena, off[outPhys], 2)],
                        [(uint)rows, (uint)cols], Div256(rows));
                    break;
                }

                case OperatorId.MatMul:
                {
                    // [n,M,K] x [K,N]: flat rows over batch feed the coopmat
                    // 1x1-conv GEMM as-is; weights repack to [N,K] fp16.
                    int[] asp = shapes[node.Inputs[0]];
                    int[] bsp = shapes[node.Inputs[1]];
                    int mmK = asp[^1], mmN = bsp[^1];
                    if (bsp.Length != 2 || !isConst[(int)node.Inputs[1]]
                        || mmK % 4 != 0 || mmN % 4 != 0)
                        throw new NotSupportedException($"matmul at node {ni}: asp=[{string.Join(',', asp)}] bsp=[{string.Join(',', bsp)}] const={isConst[(int)node.Inputs[1]]}");
                    uint mmM = (uint)(numel[checked((int)node.Inputs[0])] / mmK);
                    // fold a following bias Add [N] into the GEMM epilogue
                    uint mmFlags = 0; MtlBuffer mmBias = arena;
                    if (ni + 1 < emitLimit
                        && nodes[ni + 1].Operator == OperatorId.Add
                        && _compiled.FusedSkip(ni + 1) == 0)
                    {
                        NodeRecord ad = nodes[ni + 1];
                        uint oth = ad.Inputs[0] == node.Outputs[0] ? ad.Inputs[1]
                                 : ad.Inputs[1] == node.Outputs[0] ? ad.Inputs[0]
                                 : uint.MaxValue;
                        if (oth != uint.MaxValue && isConst[(int)oth]
                            && numel[(int)oth] == mmN
                            && refCount[Phys(checked((int)node.Outputs[0]))] == 1)
                        {
                            mmBias = ConstF16(checked((int)oth));
                            mmFlags |= 1u;
                            outPhys = Phys(checked((int)ad.Outputs[0]));
                            ni += 1;
                        }
                    }
                    // narrow-M token GEMMs (SVTR mixer, n*T rows): the direct
                    // dot kernel keeps occupancy where a 128x128 coopmat tile
                    // would leave most of the M dimension idle. Its epilogue
                    // also folds swish (Sigmoid+Mul) or a residual Add.
                    bool mmDot = mmM <= 16384
                        && Environment.GetEnvironmentVariable("SIMD_OCR_MMCM") == null;
                    if (mmDot)
                    {
                        int cur = outPhys;
                        long resOff = 0;
                        int j = ni + 1;
                        bool Free(int t) => t != Phys(outIdx) && refCount[t] >= 1;
                        if (j + 1 < emitLimit && (mmFlags & 1u) != 0
                            && nodes[j].Operator == OperatorId.Sigmoid
                            && nodes[j + 1].Operator == OperatorId.Mul
                            && _compiled.FusedSkip(j) == 0 && _compiled.FusedSkip(j + 1) == 0
                            && Phys(checked((int)nodes[j].Inputs[0])) == cur
                            && refCount[cur] == 2 && Free(cur)
                            && refCount[Phys(checked((int)nodes[j].Outputs[0]))] == 1
                            && ((Phys(checked((int)nodes[j + 1].Inputs[0])) == cur
                                 && Phys(checked((int)nodes[j + 1].Inputs[1]))
                                    == Phys(checked((int)nodes[j].Outputs[0])))
                             || (Phys(checked((int)nodes[j + 1].Inputs[1])) == cur
                                 && Phys(checked((int)nodes[j + 1].Inputs[0]))
                                    == Phys(checked((int)nodes[j].Outputs[0])))))
                        {
                            mmFlags |= 5u << 4;
                            outPhys = Phys(checked((int)nodes[j + 1].Outputs[0]));
                            ni += 2;
                        }
                        else if (j < emitLimit && nodes[j].Operator == OperatorId.Add
                            && _compiled.FusedSkip(j) == 0 && refCount[cur] == 1 && Free(cur)
                            && !addScale.ContainsKey(j))
                        {
                            NodeRecord ad = nodes[j];
                            int ia = Phys(checked((int)ad.Inputs[0]));
                            int ib = Phys(checked((int)ad.Inputs[1]));
                            int oth = ia == cur ? checked((int)ad.Inputs[1])
                                    : ib == cur ? checked((int)ad.Inputs[0]) : -1;
                            if (oth >= 0 && !isConst[oth] && numel[oth] == numel[cur]
                                && Phys(oth) != cur)
                            {
                                resOff = SlotOf((uint)oth);
                                mmFlags |= 2u;
                                outPhys = Phys(checked((int)ad.Outputs[0]));
                                ni += 1;
                            }
                        }
                        // fewer than ~64 workgroups of 4x4 tiles: the serial K
                        // loop is the latency floor, so split K over 16 lanes
                        long tiles = ((mmM + 3) / 4) * (long)(mmN / 4);
                        bool splitK = mmK >= 64 && tiles <= 16384 && !s_noSplitK;
                        Emit(splitK ? _pDotSk : _pDot, $"mmdot{(splitK ? "sk" : "")} n{ni} {mmM}x{mmK}x{mmN}",
                            [(arena, SlotOf(node.Inputs[0]), 2),
                             (ConstF16(checked((int)node.Inputs[1])), 0, 2),
                             (mmBias, 0, 2), (arena, resOff, 2),
                             (arena, off[outPhys], 2), (arena, 0, 2),
                             (arena, 0, 2), (arena, 0, 2)],
                            [mmM, (uint)mmN, (uint)mmK, (uint)(mmK / 4), mmFlags, 0u, 0u],
                            splitK ? (uint)((tiles + 15) / 16) : Div256(tiles));
                        break;
                    }
                    EmitMm(false, $"matmul n{ni} {mmM}x{mmK}x{mmN}",
                        [(arena, SlotOf(node.Inputs[0]), 2),
                         (ConstGemmW(checked((int)node.Inputs[1]), mmK, mmN), 0, 2),
                         (mmBias, 0, 2), (arena, 0, 2),
                         (arena, off[outPhys], 2),
                         (arena, 0, 2), (arena, 0, 2)],
                        mmM, (uint)mmN, (uint)mmK, mmFlags, 0u, 0u);
                    break;
                }

                default:
                    throw new NotSupportedException($"op {node.Operator} at node {ni}");
            }
            }
            catch (Exception ex)
            {
                throw new NotSupportedException(
                    $"BuildPlan failed at node {ni} op={node.Operator} " +
                    $"in=[{string.Join(',', node.Inputs)}] out=[{string.Join(',', node.Outputs)}]", ex);
            }
        }

        // finalize: graph output → fp32 readback.
        // If the last node is a STANDALONE Sigmoid (its own elem dispatch was
        // the last rec), replace it with a sigmoid-ing f32 writeback. If the
        // sigmoid was consumed into a fused group (e.g. convT+bias+sigmoid),
        // the sink slot already holds sigmoid'd values → plain copy.
        int lastNi = recs.Count > 0 ? LastEmitNi : -1;
        NodeRecord last = nodes[nodes.Length - 1];
        bool standaloneSigmoid = lastNi == nodes.Length - 1
            && last.Operator == OperatorId.Sigmoid
            && checked((int)last.Outputs[0]) == outIdx;
        int outSrc;
        uint outAct;
        if (standaloneSigmoid)
        {
            recs.RemoveAt(recs.Count - 1);
            outSrc = Phys(checked((int)last.Inputs[0]));
            outAct = 4u;
        }
        else
        {
            outSrc = Phys(outIdx);
            outAct = 0u;
        }
        if (!convTOut)
            Emit(_pOut, "out", [(arena, off[outSrc], 2), (outF32, 0, 4)],
                [(uint)numel[outIdx], outAct], Div256(numel[outIdx]));

        // head: fp32 NCHW input → fp16 NHWC (channel-padded to inCinPad if set).
        // Skipped entirely when the stem conv read the fp32 input itself.
        if (!inF32Consumed)
        {
            int[] isp = shapes[inIdx];
            int hw = isp[2] * isp[3], c = isp[1];
            uint cout = inCinPad != 0 ? (uint)inCinPad : (uint)c;
            recs.Insert(0, new MetalRec
            {
                Pipe = _pNchw,
                Binds = [new MetalBind(inF32, 0), new MetalBind(arena, (ulong)off[inIdx] * 2)],
                Gx = Div256((long)hw), Gy = (uint)nb,
                Pc = Pcu((uint)hw, (uint)c, cout), Tag = "nchw2nhwc",
            });
        }

        if (Environment.GetEnvironmentVariable("SIMD_OCR_GPU_DUMP") == "1")
            for (int ri = 0; ri < recs.Count; ri++)
            {
                var r = recs[ri];
                Console.Error.WriteLine($"rec[{ri}] {r.Tag} gx={r.Gx} gy={r.Gy} " +
                    $"binds=[{string.Join(", ", r.Binds.Select(b => $"{(ReferenceEquals(b.Buf, RoleArena) ? "arena" : ReferenceEquals(b.Buf, RoleIn) ? "in" : ReferenceEquals(b.Buf, RoleOut) ? "out" : ReferenceEquals(b.Buf, RolePart) ? "part" : "buf")}+{(long)b.ByteOffset}"))}] " +
                    $"pc={Convert.ToHexString(r.Pc)}");
            }

        // device-independent, but the sg16 (Arc) kernel set has not been
        // verified against packed slabs yet
        if (_sg32 && Environment.GetEnvironmentVariable("SIMD_OCR_NOPACK") == null)
            PackSlabs(recs, arena, off, slabElems, ref im2colOff);
        // +128*512: coopmat A-tile reads pad rows past M
        long arenaElems = im2colOff + maxIm2col + 128 * 512 + (1L << 20);
        return new MetalSchedule
        {
            Recs = recs.ToArray(),
            OutElems = (int)numel[outIdx], InElems = numel[inIdx], ArenaElems = arenaElems,
            Off = off, Alias = alias, Numel = numel, Shapes = shapes,
            Im2colOff = im2colOff,
        };
    }

    /// <summary>
    /// Re-packs the one-slab-per-tensor arena by lifetime: a slab lives from
    /// the first to the last rec that binds it, and slabs with disjoint
    /// lifetimes share memory (every rec is followed by a barrier, so a later
    /// writer never races an earlier reader). Rewrites the arena bindings,
    /// <paramref name="off"/> and the im2col scratch offset in place. Leaves
    /// everything untouched when a rec binds the arena anywhere but a slab
    /// start or the scratch. Afterwards only slabs still live at the end of
    /// the schedule keep their values for the debug readers.
    /// </summary>
    private static void PackSlabs(List<MetalRec> recs, MtlBuffer arena, long[] off,
        long[] slabElems, ref long im2colOff)
    {
        var slabAt = new Dictionary<long, int>();
        for (int i = 0; i < off.Length; i++)
            if (off[i] >= 0) slabAt[off[i]] = i;
        var first = new int[off.Length];
        var last = new int[off.Length];
        Array.Fill(first, -1);
        for (int r = 0; r < recs.Count; r++)
            foreach (MetalBind b in recs[r].Binds)
            {
                if (!ReferenceEquals(b.Buf, arena)) continue;
                long e = (long)(b.ByteOffset / 2);
                if (e == im2colOff) continue;
                if ((b.ByteOffset & 1) != 0 || !slabAt.TryGetValue(e, out int i)) return;
                if (first[i] < 0) first[i] = r;
                last[i] = r;
            }

        var order = new List<int>();
        for (int i = 0; i < off.Length; i++)
            if (first[i] >= 0) order.Add(i);
        order.Sort((a, b) => first[a] != first[b] ? first[a].CompareTo(first[b]) : a.CompareTo(b));
        var newOff = new long[off.Length];
        Array.Fill(newOff, -1L);
        var free = new List<(long Off, long Len)>();   // sorted by offset, coalesced
        var live = new List<int>();
        long top = 0;
        foreach (int i in order)
        {
            for (int k = live.Count - 1; k >= 0; k--)
            {
                int j = live[k];
                if (last[j] >= first[i]) continue;
                live.RemoveAt(k);
                Release(free, newOff[j], slabElems[j]);
            }
            long need = slabElems[i];
            int best = -1;
            for (int k = 0; k < free.Count; k++)
                if (free[k].Len >= need && (best < 0 || free[k].Len < free[best].Len)) best = k;
            if (best >= 0)
            {
                newOff[i] = free[best].Off;
                if (free[best].Len == need) free.RemoveAt(best);
                else free[best] = (free[best].Off + need, free[best].Len - need);
            }
            else if (free.Count > 0 && free[^1].Off + free[^1].Len == top)
            {
                newOff[i] = free[^1].Off;
                top = newOff[i] + need;
                free.RemoveAt(free.Count - 1);
            }
            else
            {
                newOff[i] = top;
                top += need;
            }
            live.Add(i);
        }

        long newIm2col = (top + 63) / 64 * 64;
        foreach (MetalRec rec in recs)
        {
            MetalBind[] bb = (MetalBind[])rec.Binds.Clone();
            for (int k = 0; k < bb.Length; k++)
            {
                if (!ReferenceEquals(bb[k].Buf, arena)) continue;
                long e = (long)(bb[k].ByteOffset / 2);
                bb[k] = new MetalBind(arena, (ulong)(e == im2colOff ? newIm2col : newOff[slabAt[e]]) * 2);
            }
            rec.Binds = bb;
        }
        for (int i = 0; i < off.Length; i++)
            if (off[i] >= 0) off[i] = newOff[i];
        im2colOff = newIm2col;

        static void Release(List<(long Off, long Len)> free, long o, long len)
        {
            int k = 0;
            while (k < free.Count && free[k].Off < o) k++;
            free.Insert(k, (o, len));
            if (k + 1 < free.Count && free[k].Off + free[k].Len == free[k + 1].Off)
            {
                free[k] = (free[k].Off, free[k].Len + free[k + 1].Len);
                free.RemoveAt(k + 1);
            }
            if (k > 0 && free[k - 1].Off + free[k - 1].Len == free[k].Off)
            {
                free[k - 1] = (free[k - 1].Off, free[k - 1].Len + free[k].Len);
                free.RemoveAt(k);
            }
        }
    }

    private static byte[] Pcu(params uint[] v)
    {
        byte[] b = new byte[v.Length * 4];
        for (int i = 0; i < v.Length; i++)
            BinaryPrimitives.WriteUInt32LittleEndian(b.AsSpan(i * 4), v[i]);
        return b;
    }

    private static ushort U16(ReadOnlySpan<byte> p, int o) => BinaryPrimitives.ReadUInt16LittleEndian(p[o..]);
    private static int I32(ReadOnlySpan<byte> p, int o) => BinaryPrimitives.ReadInt32LittleEndian(p[o..]);
    private static uint U32(ReadOnlySpan<byte> p, int o) => BinaryPrimitives.ReadUInt32LittleEndian(p[o..]);
    private static float F32(ReadOnlySpan<byte> p, int o) => BinaryPrimitives.ReadSingleLittleEndian(p[o..]);
    // fp16 bits of alpha (lo16) packed for shaders that read aux/flags via unpackHalf2x16
    private static ushort Half2Bits(float v) => BitConverter.HalfToUInt16Bits((Half)v);
    private static uint HsAux(ReadOnlySpan<byte> p) =>
        (uint)Half2Bits(F32(p, 4)) | ((uint)Half2Bits(F32(p, 8)) << 16);

}
