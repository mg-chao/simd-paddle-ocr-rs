using System.Numerics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
#if !NETSTANDARD2_0
using System.Runtime.Intrinsics;
using System.Runtime.Intrinsics.X86;
#endif
using System.Threading.Tasks;

using static Sdcb.SimdPaddleOCR.Kernels.SimdOps;

namespace Sdcb.SimdPaddleOCR.Kernels;

internal static partial class Conv1x1
{
    internal static unsafe bool Try(ReadOnlySpan<float> input, ReadOnlySpan<float> weights,
        ReadOnlySpan<float> bias, Span<float> output, int batch, int inputChannels,
        int height, int width, int outputChannels, int groups, int intraOpThreads = 1)
    {
        // Zen 5: prefer 4-OC / 8-OC × Vector512 spatial-16. Avoid 16-OC ZMM
        // tiles (register spills). Prefer FourOutputs; use Eight when aligned.
#if !NETSTANDARD2_0
        if (Avx512F.IsSupported)
        {
            int inputPerGroup = inputChannels / groups;
            int outputPerGroup = outputChannels / groups;
            int plane = checked(height * width);
            if (CanShardOutputs(intraOpThreads, batch, groups, outputChannels,
                (long)outputChannels * inputPerGroup * plane))
            {
                int workers = Math.Min(intraOpThreads, outputChannels / 4);
                fixed (float* inputPtr = input, weightsPtr = weights, biasPtr = bias, outputPtr = output)
                {
                    nint inputAddress = (nint)inputPtr, weightsAddress = (nint)weightsPtr,
                        biasAddress = (nint)biasPtr, outputAddress = (nint)outputPtr;
                    int inputLength = input.Length, weightsLength = weights.Length, biasLength = bias.Length,
                        outputLength = output.Length;
                    Parallel.For(0, workers, worker =>
                    {
                        int begin = (outputChannels * worker / workers) & ~3;
                        int end = worker == workers - 1 ? outputChannels : (outputChannels * (worker + 1) / workers) & ~3;
                        if (end <= begin) return;
                        int count = end - begin;
                        ReadOnlySpan<float> inSpan = new((void*)inputAddress, inputLength);
                        ReadOnlySpan<float> w = new ReadOnlySpan<float>((void*)weightsAddress, weightsLength).Slice(begin * inputPerGroup, count * inputPerGroup);
                        ReadOnlySpan<float> b = biasLength == 0 ? [] : new ReadOnlySpan<float>((void*)biasAddress, biasLength).Slice(begin, count);
                        Span<float> outSpan = new Span<float>((void*)outputAddress, outputLength).Slice(begin * plane, count * plane);
                        Try(inSpan, w, b, outSpan, 1, inputChannels, height, width, count, 1);
                    });
                }
            }
            else if (outputPerGroup >= 4 && (outputPerGroup & 3) == 0)
            {
                // Prefer 8-OC spatial-16; else 4-OC dual-spatial. Avoid 16-OC ZMM.
                if ((outputPerGroup & 7) == 0)
                    Conv1x1EightOutputsAvx512(input, weights, bias, output, batch, inputChannels, height, width,
                        outputChannels, groups, inputPerGroup, outputPerGroup, plane);
                else
                    Conv1x1FourOutputsAvx512(input, weights, bias, output, batch, inputChannels, height, width,
                        outputChannels, groups, inputPerGroup, outputPerGroup, plane);
            }
            else
            {
                for (int b = 0; b < batch; b++)
                {
                    int inputBatch = b * inputChannels * plane;
                    int outputBatch = b * outputChannels * plane;
                    for (int g = 0; g < groups; g++)
                    {
                        int inputGroup = inputBatch + g * inputPerGroup * plane;
                        int outputGroup = outputBatch + g * outputPerGroup * plane;
                        for (int co = 0; co < outputPerGroup; co++)
                        {
                            int globalCo = g * outputPerGroup + co;
                            int outputOffset = outputGroup + co * plane;
                            float initial = bias.IsEmpty ? 0f : bias[globalCo];
                            Vector512<float> initialVector = Vector512.Create(initial);
                            int spatial = 0;
                            for (; spatial <= plane - 16; spatial += 16)
                                Store512(output, outputOffset + spatial, initialVector);
                            for (; spatial < plane; spatial++) output[outputOffset + spatial] = initial;
                            int weightBase = globalCo * inputPerGroup;
                            for (int ci = 0; ci < inputPerGroup; ci++)
                            {
                                ReadOnlySpan<float> inputChannel = input.Slice(inputGroup + ci * plane, plane);
                                float weight = weights[weightBase + ci];
                                spatial = 0;
                                for (; spatial <= plane - 16; spatial += 16)
                                {
                                    Vector512<float> value = Load512(inputChannel, spatial);
                                    Vector512<float> current = Load512(output, outputOffset + spatial);
                                    Store512(output, outputOffset + spatial, AddMul512(current, value, weight));
                                }
                                for (; spatial < plane; spatial++)
                                    output[outputOffset + spatial] += inputChannel[spatial] * weight;
                            }
                        }
                    }
                }
            }
        }
        else if (Avx.IsSupported)
        {
            int inputPerGroup = inputChannels / groups;
            int outputPerGroup = outputChannels / groups;
            int plane = checked(height * width);
            if (CanShardOutputs(intraOpThreads, batch, groups, outputChannels,
                (long)outputChannels * inputPerGroup * plane))
            {
                int workers = Math.Min(intraOpThreads, outputChannels / 4);
                fixed (float* inputPtr = input, weightsPtr = weights, biasPtr = bias, outputPtr = output)
                {
                    nint inputAddress = (nint)inputPtr, weightsAddress = (nint)weightsPtr,
                        biasAddress = (nint)biasPtr, outputAddress = (nint)outputPtr;
                    int inputLength = input.Length, weightsLength = weights.Length, biasLength = bias.Length,
                        outputLength = output.Length;
                    Parallel.For(0, workers, worker =>
                    {
                        int begin = (outputChannels * worker / workers) & ~3;
                        int end = worker == workers - 1 ? outputChannels : (outputChannels * (worker + 1) / workers) & ~3;
                        if (end <= begin) return;
                        int count = end - begin;
                        ReadOnlySpan<float> inSpan = new((void*)inputAddress, inputLength);
                        ReadOnlySpan<float> w = new ReadOnlySpan<float>((void*)weightsAddress, weightsLength).Slice(begin * inputPerGroup, count * inputPerGroup);
                        ReadOnlySpan<float> b = biasLength == 0 ? [] : new ReadOnlySpan<float>((void*)biasAddress, biasLength).Slice(begin, count);
                        Span<float> outSpan = new Span<float>((void*)outputAddress, outputLength).Slice(begin * plane, count * plane);
                        Try(inSpan, w, b, outSpan, 1, inputChannels, height, width, count, 1);
                    });
                }
            }
            else if ((outputPerGroup & 15) == 0 && outputPerGroup >= 16)
            {
                Conv1x1SixteenOutputs(input, weights, bias, output, batch, inputChannels, height, width,
                    outputChannels, groups, inputPerGroup, outputPerGroup, plane);
            }
            else if ((outputPerGroup & 7) == 0 && outputPerGroup >= 8)
            {
                Conv1x1EightOutputs(input, weights, bias, output, batch, inputChannels, height, width,
                    outputChannels, groups, inputPerGroup, outputPerGroup, plane);
            }
            else if (outputPerGroup >= 4)
            {
                Conv1x1FourOutputs(input, weights, bias, output, batch, inputChannels, height, width,
                    outputChannels, groups, inputPerGroup, outputPerGroup, plane);
            }
            else
            {
                for (int b = 0; b < batch; b++)
                {
                    int inputBatch = b * inputChannels * plane;
                    int outputBatch = b * outputChannels * plane;
                    for (int g = 0; g < groups; g++)
                    {
                        int inputGroup = inputBatch + g * inputPerGroup * plane;
                        int outputGroup = outputBatch + g * outputPerGroup * plane;
                        for (int co = 0; co < outputPerGroup; co++)
                        {
                            int globalCo = g * outputPerGroup + co;
                            int outputOffset = outputGroup + co * plane;
                            float initial = bias.IsEmpty ? 0f : bias[globalCo];
                            Vector256<float> initialVector = Vector256.Create(initial);
                            int spatial = 0;
                            for (; spatial <= plane - 8; spatial += 8)
                                Store(output, outputOffset + spatial, initialVector);
                            for (; spatial < plane; spatial++) output[outputOffset + spatial] = initial;

                            int weightBase = globalCo * inputPerGroup;
                            for (int ci = 0; ci < inputPerGroup; ci++)
                            {
                                ReadOnlySpan<float> inputChannel = input.Slice(inputGroup + ci * plane, plane);
                                float weight = weights[weightBase + ci];
                                spatial = 0;
                                for (; spatial <= plane - 8; spatial += 8)
                                {
                                    Vector256<float> value = Load(inputChannel, spatial);
                                    Vector256<float> current = Load(output, outputOffset + spatial);
                                    Store(output, outputOffset + spatial, AddMul(current, value, weight));
                                }
                                for (; spatial < plane; spatial++)
                                    output[outputOffset + spatial] += inputChannel[spatial] * weight;
                            }
                        }
                    }
                }
            }
        }
        else
#endif
        {
            if (Vector.IsHardwareAccelerated)
            {
                TryVector(input, weights, bias, output, batch, inputChannels,
                    height, width, outputChannels, groups, intraOpThreads);
            }
            else
            {
                Conv1x1Scalar(input, weights, bias, output, batch, inputChannels, height, width,
                    outputChannels, groups, intraOpThreads);
            }
        }
        return true;
    }

    /// <summary>
    /// OC-major packed 1x1: weights are [ic][oc_padded_to_16]. Used when the
    /// spatial plane is too small for spatial Avx512 tiles to amortize weight traffic.
    /// </summary>
    internal static unsafe bool TryOcMajor(ReadOnlySpan<float> input,
        ReadOnlySpan<float> packedOc16, ReadOnlySpan<float> bias, Span<float> output,
        int batch, int inputChannels, int height, int width, int outputChannels,
        int intraOpThreads = 1)
    {
        if ((outputChannels & 15) != 0 || outputChannels < 16)
            return false;
        int plane = checked(height * width);
        // OC-major is useful when the output plane is small: each input scalar
        // then updates one contiguous vector of output channels. Keep the
        // output in NCHW so all graph consumers remain unchanged.
        if (plane >= 48) return false;
        int coutPadded = (outputChannels + 15) & ~15;
        if (packedOc16.Length < checked(inputChannels * coutPadded)) return false;

#if !NETSTANDARD2_0
        if (Avx512F.IsSupported)
        {
            if (intraOpThreads > 1 && batch == 1 && outputChannels >= 32 &&
                (long)outputChannels * inputChannels * plane >= 1_000_000)
            {
                int ocBlocks = outputChannels / 16;
                int workers = Math.Min(intraOpThreads, ocBlocks);
                fixed (float* inputPtr = input, weightsPtr = packedOc16,
                    biasPtr = bias, outputPtr = output)
                {
                    nint inputAddress = (nint)inputPtr, weightsAddress = (nint)weightsPtr,
                        biasAddress = (nint)biasPtr, outputAddress = (nint)outputPtr;
                    int inputLength = input.Length, weightsLength = packedOc16.Length,
                        biasLength = bias.Length, outputLength = output.Length;
                    Parallel.For(0, workers, worker =>
                    {
                        int beginOc = (ocBlocks * worker / workers) * 16;
                        int endOc = worker == workers - 1
                            ? outputChannels
                            : (ocBlocks * (worker + 1) / workers) * 16;
                        if (endOc <= beginOc) return;
                        int shardCout = endOc - beginOc;
                        ReadOnlySpan<float> inSpan = new((void*)inputAddress, inputLength);
                        // Full weight buffer; kernel indexes by absolute OC via coutPadded.
                        ReadOnlySpan<float> weightSpan = new((void*)weightsAddress, weightsLength);
                        ReadOnlySpan<float> biasSpan = biasLength == 0 ? []
                            : new ReadOnlySpan<float>((void*)biasAddress, biasLength).Slice(beginOc, shardCout);
                        Span<float> outSpan = new Span<float>((void*)outputAddress, outputLength)
                            .Slice(beginOc * plane, shardCout * plane);
                        Conv1x1OcMajorAvx512Unsafe(inSpan, weightSpan, biasSpan, outSpan, 1,
                            inputChannels, height, width, shardCout, coutPadded, beginOc);
                    });
                }
            }
            else
            {
                Conv1x1OcMajorAvx512Unsafe(input, packedOc16, bias, output, batch,
                    inputChannels, height, width, outputChannels, coutPadded, 0);
            }
        }
        else
#endif
            if (Vector.IsHardwareAccelerated)
            {
                int tile = Vector<float>.Count >= 8 ? 8 : 4;
                if (intraOpThreads > 1 && batch == 1 && outputChannels >= tile * 2 &&
                    (long)outputChannels * inputChannels * plane >= 8_000_000)
                {
                    int blocks = outputChannels / tile;
                    int workers = Math.Min(intraOpThreads, blocks);
                    fixed (float* inputPtr = input, weightsPtr = packedOc16,
                        biasPtr = bias, outputPtr = output)
                    {
                        nint inputAddress = (nint)inputPtr, weightsAddress = (nint)weightsPtr,
                            biasAddress = (nint)biasPtr, outputAddress = (nint)outputPtr;
                        int inputLength = input.Length, weightsLength = packedOc16.Length,
                            biasLength = bias.Length, outputLength = output.Length;
                        Parallel.For(0, workers, worker =>
                        {
                            int begin = (blocks * worker / workers) * tile;
                            int end = worker == workers - 1
                                ? outputChannels : (blocks * (worker + 1) / workers) * tile;
                            if (end <= begin) return;
                            int count = end - begin;
                            ReadOnlySpan<float> inSpan = new((void*)inputAddress, inputLength);
                            ReadOnlySpan<float> weightSpan = new ReadOnlySpan<float>((void*)weightsAddress, weightsLength);
                            ReadOnlySpan<float> biasSpan = biasLength == 0 ? []
                                : new ReadOnlySpan<float>((void*)biasAddress, biasLength).Slice(begin, count);
                            Span<float> outSpan = new Span<float>((void*)outputAddress, outputLength)
                                .Slice(begin * plane, count * plane);
                            Conv1x1OcMajorVector(inSpan, weightSpan, biasSpan, outSpan, 1,
                                inputChannels, height, width, count, coutPadded, begin);
                        });
                    }
                }
                else
                    Conv1x1OcMajorVector(input, packedOc16, bias, output, batch,
                        inputChannels, height, width, outputChannels, coutPadded, 0);
            }
            else
                return false;
        return true;
    }

    internal static bool FusesResidualInPackedEight(int outputChannels, int inputChannels,
        int packedOc8Length)
    {
#if NETSTANDARD2_0
        return false;
#else
        return Avx512F.IsSupported && outputChannels >= 8 && (outputChannels & 7) == 0 &&
            packedOc8Length == checked(outputChannels * inputChannels);
#endif
    }

    /// <summary>Runs a 1x1 convolution from C's [block4, input, lane] packed weights.</summary>
    internal static unsafe bool TryPacked(ReadOnlySpan<float> input,
        ReadOnlySpan<float> packedWeights, ReadOnlySpan<float> bias, Span<float> output,
        int batch, int inputChannels, int height, int width, int outputChannels,
        int intraOpThreads = 1, PackedConv1x1Int8? packedInt8 = null,
        ReadOnlySpan<float> packedOc8 = default, ReadOnlySpan<float> residual = default)
    {
        // Packed [block8, ic, 8] for AVX-512 8-OC; [block4, ic, 4] otherwise.
#if !NETSTANDARD2_0
        // A batched REC request has several independent NCHW samples.  The
        // single-sample kernels are substantially better tuned than their
        // batch loop, so distribute samples across the session's intra-op
        // budget before selecting the AVX2/AVX-512 micro-kernel.  Each worker
        // receives a disjoint output slice and therefore needs no reduction.
        int packedPlane = checked(height * width);
        long packedWork = checked((long)outputChannels * inputChannels * packedPlane);
        // For wide REC batches, let the NHWC tiled kernel own the complete
        // batch.  Splitting into one sample per task prevents its row tiles
        // from sharing the scheduling/cache decisions and oversubscribes the
        // outer batched recognizer units.  Shapes without the AVX2 blocked
        // layout retain the existing per-sample sharding below.
        bool useBatchedNhwc = Avx.IsSupported && packedOc8.Length == checked(inputChannels * outputChannels) &&
            outputChannels >= 16 && (outputChannels & 15) == 0 && packedPlane > 4096 && packedWork >= 4_000_000;
        if (Avx.IsSupported && batch > 1 && intraOpThreads > 1 &&
            (long)outputChannels * inputChannels * height * width >= 1_000_000 && !useBatchedNhwc)
        {
            int plane = checked(height * width);
            int workers = Math.Min(intraOpThreads, batch);
            fixed (float* inputPtr = input, weightsPtr = packedWeights,
                biasPtr = bias, outputPtr = output, residualPtr = residual,
                packedOc8Ptr = packedOc8)
            {
                nint inputAddress = (nint)inputPtr, weightsAddress = (nint)weightsPtr,
                    biasAddress = (nint)biasPtr, outputAddress = (nint)outputPtr,
                    residualAddress = (nint)residualPtr, packedOc8Address = (nint)packedOc8Ptr;
                int inputLength = input.Length, weightsLength = packedWeights.Length,
                    biasLength = bias.Length, outputLength = output.Length,
                    packedOc8Length = packedOc8.Length;
                bool hasResidual = residual.Length == output.Length;
                Parallel.For(0, workers, worker =>
                {
                    for (int b = worker; b < batch; b += workers)
                    {
                        ReadOnlySpan<float> inSpan = new ReadOnlySpan<float>((void*)inputAddress, inputLength)
                            .Slice(b * inputChannels * plane, inputChannels * plane);
                        Span<float> outSpan = new Span<float>((void*)outputAddress, outputLength)
                            .Slice(b * outputChannels * plane, outputChannels * plane);
                        ReadOnlySpan<float> residualSpan = hasResidual
                            ? new ReadOnlySpan<float>((void*)residualAddress, outputLength)
                                .Slice(b * outputChannels * plane, outputChannels * plane)
                            : default;
                        TryPacked(inSpan, new ReadOnlySpan<float>((void*)weightsAddress, weightsLength),
                            biasLength == 0 ? [] : new ReadOnlySpan<float>((void*)biasAddress, biasLength),
                            outSpan, 1, inputChannels, height, width, outputChannels, 1,
                            packedInt8,
                            new ReadOnlySpan<float>((void*)packedOc8Address, packedOc8Length), residualSpan);
                    }
                });
            }
            return true;
        }
        // residual.IsEmpty is required, not cosmetic: the VNNI kernel has no
        // residual parameter, so letting it win this branch would silently drop
        // the residual that FusesResidualInPackedEight promised to fuse. Today
        // the caller keeps packedInt8 null (InferenceSession enables Int8 VNNI
        // behind a const false), so this is a latent contract mismatch rather
        // than a live bug — but it is exactly the shape that turns into one.
        if (residual.IsEmpty && AvxVnni.IsSupported && packedInt8 is not null &&
            inputChannels >= 192 && (inputChannels & 3) == 0 && (outputChannels & 7) == 0 &&
            packedInt8.Weights.Length == checked(inputChannels * outputChannels) &&
            packedInt8.Scales.Length == outputChannels && packedInt8.Sums.Length == outputChannels &&
            Conv1x1PackedEightOutputsInt8VnniUnsafe(input, packedInt8, bias, output,
                batch, inputChannels, height, width, outputChannels, intraOpThreads))
        {
            // Int8 VNNI kernel already wrote the output.
        }
        else if (Avx512F.IsSupported && outputChannels >= 8 && (outputChannels & 7) == 0 &&
            packedOc8.Length == checked(outputChannels * inputChannels))
        {
            int plane = checked(height * width), blocks8 = outputChannels / 8;
            if (intraOpThreads > 1 && batch == 1 && blocks8 >= 2 &&
                (long)outputChannels * inputChannels * plane >= 1_000_000)
            {
                int workers = Math.Min(intraOpThreads, blocks8);
                bool hasResidual = residual.Length == output.Length;
                fixed (float* inputPtr = input, weightsPtr = packedOc8,
                    biasPtr = bias, outputPtr = output, residualPtr = residual)
                {
                    nint inputAddress = (nint)inputPtr, weightsAddress = (nint)weightsPtr,
                        biasAddress = (nint)biasPtr, outputAddress = (nint)outputPtr,
                        residualAddress = (nint)residualPtr;
                    int inputLength = input.Length, weightsLength = packedOc8.Length,
                        biasLength = bias.Length, outputLength = output.Length;
                    Parallel.For(0, workers, worker =>
                    {
                        int beginBlock = blocks8 * worker / workers, endBlock = blocks8 * (worker + 1) / workers;
                        if (endBlock <= beginBlock) return;
                        int shardCout = (endBlock - beginBlock) * 8;
                        int shardPlane = shardCout * plane;
                        ReadOnlySpan<float> inSpan = new((void*)inputAddress, inputLength);
                        ReadOnlySpan<float> weightSpan = new ReadOnlySpan<float>((void*)weightsAddress, weightsLength)
                            .Slice(beginBlock * inputChannels * 8, (endBlock - beginBlock) * inputChannels * 8);
                        ReadOnlySpan<float> biasSpan = biasLength == 0 ? []
                            : new ReadOnlySpan<float>((void*)biasAddress, biasLength).Slice(beginBlock * 8, (endBlock - beginBlock) * 8);
                        Span<float> outSpan = new Span<float>((void*)outputAddress, outputLength)
                            .Slice(beginBlock * 8 * plane, shardPlane);
                        ReadOnlySpan<float> residualSpan = hasResidual
                            ? new ReadOnlySpan<float>((void*)residualAddress, outputLength)
                                .Slice(beginBlock * 8 * plane, shardPlane)
                            : default;
                        Conv1x1PackedEightOutputsAvx512Unsafe(inSpan, weightSpan, biasSpan, outSpan, 1,
                            inputChannels, height, width, shardCout, residualSpan);
                    });
                }
            }
            else
            {
                Conv1x1PackedEightOutputsAvx512Unsafe(input, packedOc8, bias, output, batch,
                    inputChannels, height, width, outputChannels, residual);
            }
        }
        else if (Avx512F.IsSupported && outputChannels >= 4 && (outputChannels & 3) == 0)
        {
            int plane = checked(height * width), blocks = outputChannels / 4;
            if (intraOpThreads > 1 && batch == 1 && blocks >= 2 &&
                (long)outputChannels * inputChannels * plane >= 1_000_000)
            {
                int workers = Math.Min(intraOpThreads, blocks);
                fixed (float* inputPtr = input, weightsPtr = packedWeights,
                    biasPtr = bias, outputPtr = output)
                {
                    nint inputAddress = (nint)inputPtr, weightsAddress = (nint)weightsPtr,
                        biasAddress = (nint)biasPtr, outputAddress = (nint)outputPtr;
                    int inputLength = input.Length, weightsLength = packedWeights.Length,
                        biasLength = bias.Length, outputLength = output.Length;
                    Parallel.For(0, workers, worker =>
                    {
                        int beginBlock = blocks * worker / workers, endBlock = blocks * (worker + 1) / workers;
                        ReadOnlySpan<float> inSpan = new((void*)inputAddress, inputLength);
                        ReadOnlySpan<float> weightSpan = new ReadOnlySpan<float>((void*)weightsAddress, weightsLength)
                            .Slice(beginBlock * inputChannels * 4, (endBlock - beginBlock) * inputChannels * 4);
                        ReadOnlySpan<float> biasSpan = biasLength == 0 ? []
                            : new ReadOnlySpan<float>((void*)biasAddress, biasLength).Slice(beginBlock * 4, (endBlock - beginBlock) * 4);
                        Span<float> outSpan = new Span<float>((void*)outputAddress, outputLength)
                            .Slice(beginBlock * 4 * plane, (endBlock - beginBlock) * 4 * plane);
                        int shardCout = (endBlock - beginBlock) * 4;
                        if ((shardCout & 15) == 0 && inputChannels <= 64)
                            Conv1x1PackedSixteenOutputsAvx512Unsafe(inSpan, weightSpan, biasSpan, outSpan, 1,
                                inputChannels, height, width, shardCout);
                        else
                            Conv1x1PackedAvx512Unsafe(inSpan, weightSpan, biasSpan, outSpan, 1, inputChannels,
                                height, width, shardCout);
                    });
                }
            }
            else if ((outputChannels & 15) == 0 && inputChannels <= 64)
            {
                // 16-OC helps when ic is modest (input reuse beats spill cost).
                Conv1x1PackedSixteenOutputsAvx512Unsafe(input, packedWeights, bias, output, batch,
                    inputChannels, height, width, outputChannels);
            }
            else
            {
                Conv1x1PackedAvx512Unsafe(input, packedWeights, bias, output, batch, inputChannels,
                    height, width, outputChannels);
            }
        }
        else if (Avx.IsSupported && outputChannels >= 16 && (outputChannels & 15) == 0 &&
            packedOc8.Length == checked(inputChannels * outputChannels) &&
            Conv1x1PackedNhwcTiledAvx2(input, packedOc8, bias, output, batch, inputChannels,
                height, width, outputChannels, intraOpThreads))
        {
            // Tiled NHWC working set already wrote the output.
        }
        else if (Avx.IsSupported && outputChannels >= 16 && (outputChannels & 15) == 0 &&
            packedOc8.Length == checked(inputChannels * outputChannels) &&
            Conv1x1PackedNhwcAvx2(input, packedOc8, bias, output, batch, inputChannels,
                height, width, outputChannels, intraOpThreads))
        {
            // NHWC blocked GEMM path already wrote the output.
        }
        else if (Avx.IsSupported && outputChannels >= 4 && (outputChannels & 3) == 0)
        {
            int plane = checked(height * width), blocks = outputChannels / 4;
            if (intraOpThreads > 1 && batch == 1 && plane >= 4096 &&
                (long)outputChannels * inputChannels * plane >= 8_000_000)
            {
                int workers = Math.Min(intraOpThreads, Math.Max(1, plane / 16));
                fixed (float* inputPtr = input, weightsPtr = packedWeights,
                    biasPtr = bias, outputPtr = output)
                {
                    nint inputAddress = (nint)inputPtr, weightsAddress = (nint)weightsPtr,
                        biasAddress = (nint)biasPtr, outputAddress = (nint)outputPtr;
                    int inputLength = input.Length, weightsLength = packedWeights.Length,
                        biasLength = bias.Length, outputLength = output.Length;
                    Parallel.For(0, workers, worker =>
                    {
                        int begin = (plane * worker / workers) & ~15;
                        int end = worker == workers - 1 ? plane : (plane * (worker + 1) / workers) & ~15;
                        ReadOnlySpan<float> inSpan = new((void*)inputAddress, inputLength);
                        ReadOnlySpan<float> weightSpan = new((void*)weightsAddress, weightsLength);
                        ReadOnlySpan<float> biasSpan = biasLength == 0 ? []
                            : new ReadOnlySpan<float>((void*)biasAddress, biasLength);
                        Span<float> outSpan = new((void*)outputAddress, outputLength);
                        Conv1x1PackedUnsafe(inSpan, weightSpan, biasSpan, outSpan, 1, inputChannels,
                            height, width, outputChannels, begin, end);
                    });
                }
            }
            else if (intraOpThreads > 1 && batch == 1 && blocks >= 2 &&
                (long)outputChannels * inputChannels * plane >= 1_000_000)
            {
                int workers = Math.Min(intraOpThreads, blocks);
                fixed (float* inputPtr = input, weightsPtr = packedWeights,
                    biasPtr = bias, outputPtr = output)
                {
                    nint inputAddress = (nint)inputPtr, weightsAddress = (nint)weightsPtr,
                        biasAddress = (nint)biasPtr, outputAddress = (nint)outputPtr;
                    int inputLength = input.Length, weightsLength = packedWeights.Length,
                        biasLength = bias.Length, outputLength = output.Length;
                    Parallel.For(0, workers, worker =>
                    {
                        int beginBlock = blocks * worker / workers, endBlock = blocks * (worker + 1) / workers;
                        ReadOnlySpan<float> inSpan = new((void*)inputAddress, inputLength);
                        ReadOnlySpan<float> weightSpan = new ReadOnlySpan<float>((void*)weightsAddress, weightsLength)
                            .Slice(beginBlock * inputChannels * 4, (endBlock - beginBlock) * inputChannels * 4);
                        ReadOnlySpan<float> biasSpan = biasLength == 0 ? []
                            : new ReadOnlySpan<float>((void*)biasAddress, biasLength).Slice(beginBlock * 4, (endBlock - beginBlock) * 4);
                        Span<float> outSpan = new Span<float>((void*)outputAddress, outputLength)
                            .Slice(beginBlock * 4 * plane, (endBlock - beginBlock) * 4 * plane);
                        Conv1x1PackedUnsafe(inSpan, weightSpan, biasSpan, outSpan, 1, inputChannels,
                            height, width, (endBlock - beginBlock) * 4);
                    });
                }
            }
            else if ((outputChannels & 7) == 0)
                Conv1x1PackedUnsafe(input, packedWeights, bias, output, batch, inputChannels,
                    height, width, outputChannels);
            else
            {
                Conv1x1PackedUnsafe(input, packedWeights, bias, output, batch, inputChannels,
                    height, width, outputChannels);
            }
        }
        else
#endif
            // 16-OC / intra-op>2: AdvSimd (Count==4) skips Eight so Four can
            // shard 4 ways (Eight only has two 8-OC blocks). Vector256 keeps
            // Eight — that is the ns2 default; skipping it sent 16-OC through
            // Four and was part of the 9c54d56 win-x64 ns2 regression.
            if (Vector.IsHardwareAccelerated && outputChannels >= 8 && (outputChannels & 7) == 0 &&
                packedOc8.Length == checked(outputChannels * inputChannels) &&
                !(Vector<float>.Count == 4 && outputChannels == 16 && intraOpThreads > outputChannels / 8))
            {
                TryPackedEightVector(input, packedOc8, bias, output, batch, inputChannels,
                    height, width, outputChannels, intraOpThreads);
            }
            else if (Vector.IsHardwareAccelerated && outputChannels >= 4 && (outputChannels & 3) == 0)
            {
                TryPackedVector(input, packedWeights, bias, output, batch, inputChannels,
                    height, width, outputChannels, intraOpThreads);
            }
            else if (outputChannels >= 4 && (outputChannels & 3) == 0)
            {
                Conv1x1PackedScalar(input, packedWeights, bias, output, batch, inputChannels,
                    height, width, outputChannels, intraOpThreads);
            }
            else
                return false;
        return true;
    }
}
