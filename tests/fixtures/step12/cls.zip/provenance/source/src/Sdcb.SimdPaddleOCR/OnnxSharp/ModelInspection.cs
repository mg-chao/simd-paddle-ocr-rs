namespace Sdcb.SimdPaddleOCR.OnnxSharp;

// Diagnostic contracts deliberately precede physical layout planning. Nothing
// here is allocated by ordinary Model.Load calls; callbacks consume data while
// the corresponding importer stage is still alive.
internal sealed record ModelInspectionDimension(string Kind, object? Value = null);
internal sealed record ModelInspectionShape(bool RankKnown, IReadOnlyList<ModelInspectionDimension> Dims);
internal sealed record ModelInspectionAttribute(string Kind, object? Value = null,
    object? Values = null, object? Bits = null, string? Hex = null);
internal sealed record ModelInspectionTensor(string Key, string Name, string Dtype,
    ModelInspectionShape Shape, bool Constant, ReadOnlyMemory<byte> Data);
internal sealed record ModelInspectionNode(string Key, string Name, string OpType,
    string Domain, long Opset, int[] SourceIndices, string?[] Inputs, string?[] Outputs,
    IReadOnlyDictionary<string, ModelInspectionAttribute> Attributes);
internal sealed record ModelInspectionRecipe(string NodeKey, string DataInput, string ShapeInput,
    ModelInspectionShape Template, int[] SourceIndices);
internal sealed record ModelInspectionIntegerConstant(string Key, string Name, string Dtype,
    ModelInspectionShape Shape, long[] Values);
internal sealed record ModelInspectionMetadata(IReadOnlyList<ModelInspectionNode> Nodes,
    IReadOnlyList<ModelInspectionIntegerConstant> Constants);
internal sealed record ModelInspectionOpset(string Domain, long Version);
internal sealed record ModelInspectionSnapshot(int SchemaVersion, string Stage, long IrVersion,
    IReadOnlyList<ModelInspectionOpset> Opsets, string[] Inputs, string[] Outputs,
    IReadOnlyList<ModelInspectionTensor> Tensors, IReadOnlyList<ModelInspectionNode> Nodes,
    IReadOnlyList<ModelInspectionRecipe> Recipes, ModelInspectionMetadata ShapeMetadata);

public sealed partial class Model
{
    private sealed class ImportInspectionState
    {
        private readonly OnnxModelData _parsed;
        private readonly OnnxGraphData _graph;
        private readonly Action<ModelInspectionSnapshot> _observer;
        private readonly Dictionary<string, OnnxValueInfoData> _values;
        private readonly Dictionary<string, string> _keys = new(StringComparer.Ordinal);
        private readonly Dictionary<OnnxNodeData, int[]> _sources = new();
        private readonly List<ModelInspectionRecipe> _recipes = [];

        public ImportInspectionState(OnnxModelData parsed, Action<ModelInspectionSnapshot> observer)
        {
            _parsed = parsed;
            _graph = parsed.Graph!;
            _observer = observer;
            _values = new(StringComparer.Ordinal);
            foreach (OnnxValueInfoData value in _graph.Inputs.Concat(_graph.ValueInfo).Concat(_graph.Outputs))
                _values[value.Name] = value;
        }

        private string Key(string name) => _keys.TryGetValue(name, out string? key) ? key : "original:" + name;
        private ModelInspectionShape Shape(string name) => _values.TryGetValue(name, out OnnxValueInfoData? value)
            ? value.InspectionShape ?? new(false, []) : new(false, []);
        private static ModelInspectionShape Shape(IReadOnlyList<long> dims) => new(true,
            dims.Select(d => new ModelInspectionDimension("known", d)).ToArray());
        private static string Dtype(int dtype) => dtype switch
        {
            1 => "f32", 6 => "i32", 7 => "i64", 2 => "u8", _ => "onnx:" + dtype
        };
        private long Opset(string domain) => _parsed.Opsets.FirstOrDefault(o => o.Domain == domain
            || (domain is "" or "ai.onnx" && o.Domain is "" or "ai.onnx"))?.Version ?? 0;
        private ModelInspectionTensor Tensor(OnnxTensorData tensor, string? name = null)
        {
            name ??= tensor.Name;
            (_, byte[] bytes) = TensorBytes(tensor);
            return new(Key(name), name, Dtype(tensor.DataType), Shape(tensor.Dims), true, bytes);
        }

        public void EmitRaw()
        {
            Dictionary<string, ModelInspectionTensor> tensors = new(StringComparer.Ordinal);
            foreach (OnnxTensorData tensor in _graph.Initializers) tensors[tensor.Name] = Tensor(tensor);
            foreach (OnnxValueInfoData value in _graph.Inputs.Concat(_graph.ValueInfo).Concat(_graph.Outputs))
                if (!tensors.ContainsKey(value.Name))
                    tensors[value.Name] = new(Key(value.Name), value.Name, Dtype(value.ElementType),
                        Shape(value.Name), false, ReadOnlyMemory<byte>.Empty);
            foreach (OnnxNodeData node in _graph.Nodes)
                foreach (string name in node.Inputs.Concat(node.Outputs))
                    if (name.Length != 0 && !tensors.ContainsKey(name))
                        tensors[name] = new(Key(name), name, "unknown", new(false, []), false, ReadOnlyMemory<byte>.Empty);
            Emit("raw", _graph.Inputs.Select(v => Key(v.Name)).ToArray(), _graph.Outputs.Select(v => Key(v.Name)).ToArray(),
                tensors.Values.OrderBy(t => t.Key, StringComparer.Ordinal).ToArray(),
                _graph.Nodes.Select(n => Node(n, effective: false)).ToArray(), []);
        }

        public void TrackClone(OnnxNodeData node) => _sources[node] = [node.SourceIndex];
        public void TrackBatchNormalization(OnnxNodeData conv, OnnxNodeData bn, string weight, string bias)
        {
            _keys[weight] = $"generated:bn_weight:{conv.SourceIndex}:{bn.SourceIndex}";
            _keys[bias] = $"generated:bn_bias:{conv.SourceIndex}:{bn.SourceIndex}";
            MergeSources(conv, bn);
        }
        public void TrackBranch(OnnxNodeData conv, OnnxNodeData other, OnnxNodeData add, string weight, string? bias)
        {
            _keys[weight] = $"generated:branch_weight:{add.SourceIndex}";
            if (bias is not null) _keys[bias] = $"generated:branch_bias:{add.SourceIndex}";
            MergeSources(conv, other, add);
        }
        private void MergeSources(OnnxNodeData node, params OnnxNodeData[] merged) => _sources[node] =
            new[] { node }.Concat(merged).SelectMany(n => _sources.TryGetValue(n, out int[]? sources)
                ? sources : [n.SourceIndex]).Distinct().OrderBy(i => i).ToArray();

        public void TrackRecipe(OnnxNodeData reshape, string dataInput, string shapeInput)
        {
            Dictionary<string, OnnxNodeData> producers = new(StringComparer.Ordinal);
            foreach (OnnxNodeData node in _graph.Nodes)
                foreach (string output in node.Outputs) if (output.Length != 0) producers[output] = node;
            HashSet<int> sources = [];
            HashSet<string> visited = new(StringComparer.Ordinal);
            void Visit(string name)
            {
                if (name == dataInput || !visited.Add(name) || !producers.TryGetValue(name, out OnnxNodeData? node)) return;
                sources.Add(node.SourceIndex);
                if (node.OpType == "Shape") return;
                foreach (string input in node.Inputs) if (input.Length != 0) Visit(input);
            }
            Visit(shapeInput);
            _recipes.Add(new("node:" + reshape.SourceIndex, Key(dataInput), Key(shapeInput),
                Shape(reshape.Outputs[0]), sources.OrderBy(i => i).ToArray()));
        }

        public void EmitNormalized(IReadOnlyList<string> names, Dictionary<string, OnnxTensorData> initializers,
            IReadOnlyList<OnnxNodeData> nodes, string[] inputs, string[] outputs, byte[][] data, int opset)
        {
            List<ModelInspectionTensor> tensors = [];
            for (int i = 0; i < names.Count; i++)
            {
                string name = names[i];
                if (initializers.TryGetValue(name, out OnnxTensorData? tensor))
                    tensors.Add(new(Key(name), name, Dtype(tensor.DataType), Shape(tensor.Dims), true, data[i]));
                else
                    tensors.Add(new(Key(name), name, _values.TryGetValue(name, out OnnxValueInfoData? value)
                        ? Dtype(value.ElementType) : "f32", Shape(name), false, ReadOnlyMemory<byte>.Empty));
            }
            HashSet<string> surviving = new(nodes.Select(n => "node:" + n.SourceIndex), StringComparer.Ordinal);
            ModelInspectionRecipe[] recipes = _recipes.Where(r => surviving.Contains(r.NodeKey))
                .OrderBy(r => r.NodeKey, StringComparer.Ordinal).ToArray();
            HashSet<int> metadataSources = new(recipes.SelectMany(r => r.SourceIndices));
            OnnxNodeData[] metadataNodes = _graph.Nodes.Where(n => metadataSources.Contains(n.SourceIndex)).ToArray();
            Dictionary<string, ModelInspectionIntegerConstant> metadataConstants = new(StringComparer.Ordinal);
            foreach (OnnxNodeData node in metadataNodes)
                foreach (string name in node.Inputs.Concat(node.Outputs))
                    if (initializers.TryGetValue(name, out OnnxTensorData? constant) && constant.DataType is 6 or 7)
                        metadataConstants[Key(name)] = new(Key(name), name, Dtype(constant.DataType), Shape(constant.Dims), TensorInts(constant));
            ModelInspectionMetadata metadata = new(metadataNodes.Select(n => Node(n, false)).ToArray(),
                metadataConstants.Values.OrderBy(c => c.Key, StringComparer.Ordinal).ToArray());
            Emit("normalized", inputs.Select(Key).ToArray(), outputs.Select(Key).ToArray(),
                tensors.OrderBy(t => t.Key, StringComparer.Ordinal).ToArray(), nodes.Select(n => Node(n, true)).ToArray(),
                recipes, metadata);
        }

        private void Emit(string stage, string[] inputs, string[] outputs, IReadOnlyList<ModelInspectionTensor> tensors,
            IReadOnlyList<ModelInspectionNode> nodes, IReadOnlyList<ModelInspectionRecipe> recipes,
            ModelInspectionMetadata? metadata = null) => _observer(new(1, stage,
                _parsed.IrVersion, _parsed.Opsets.Select(o => new ModelInspectionOpset(o.Domain, o.Version)).ToArray(),
                inputs, outputs, tensors, nodes, recipes, metadata ?? new([], [])));

        private ModelInspectionNode Node(OnnxNodeData node, bool effective) => new("node:" + node.SourceIndex,
            node.Name, node.OpType, node.Domain, Opset(node.Domain), _sources.TryGetValue(node, out int[]? sources)
                ? (int[])sources.Clone() : [node.SourceIndex], node.Inputs.Select(n => n.Length == 0 ? null : Key(n)).ToArray(),
            node.Outputs.Select(n => n.Length == 0 ? null : Key(n)).ToArray(), effective ? EffectiveAttributes(node) :
                node.Attributes.ToDictionary(a => a.Name, Attribute, StringComparer.Ordinal));

        private ModelInspectionAttribute Attribute(OnnxAttributeData attribute) => attribute.Type switch
        {
            1 => Float(attribute.Float), 2 => Integer(attribute.Int),
            3 => Bytes(attribute.String), 4 when attribute.Tensor is not null => new("tensor", Tensor(attribute.Tensor)),
            6 => Floats(attribute.Floats), 7 => Integers(attribute.Ints),
            8 => new("strings", Values: attribute.Strings.Select(Hex).ToArray()),
            _ => new("unsupported", attribute.Type)
        };
        private static ModelInspectionAttribute Integer(long value) => new("int", value);
        private static ModelInspectionAttribute Integers(IEnumerable<long> values) => new("ints", Values: values.ToArray());
        private static ModelInspectionAttribute Float(float value) => new("float", Bits: unchecked((uint)BitConverterCompat.SingleToInt32Bits(value)));
        private static ModelInspectionAttribute Floats(IEnumerable<float> values) => new("floats", Bits: values.Select(v => unchecked((uint)BitConverterCompat.SingleToInt32Bits(v))).ToArray());
        private static string Hex(byte[] bytes) => string.Concat(bytes.Select(b => b.ToString("x2")));
        private static ModelInspectionAttribute Bytes(byte[] bytes) => new("bytes", Hex: Hex(bytes));

        private IReadOnlyDictionary<string, ModelInspectionAttribute> EffectiveAttributes(OnnxNodeData node)
        {
            Dictionary<string, ModelInspectionAttribute> result = new(StringComparer.Ordinal);
            OnnxAttributeData? Find(string name) => node.Attributes.FirstOrDefault(a => a.Name == name);
            void Int(string name, long fallback) => result[name] = Integer(Find(name)?.Int ?? fallback);
            void F32(string name, float fallback) => result[name] = Float(Find(name)?.Float ?? fallback);
            void Ints(string name, params long[] fallback) => result[name] = Integers(Find(name)?.Ints ?? (IEnumerable<long>)fallback);
            void Text(string name, string fallback) => result[name] = Bytes(Find(name)?.String ?? System.Text.Encoding.UTF8.GetBytes(fallback));
            switch (node.OpType)
            {
                case "Conv": case "ConvTranspose":
                    Ints("kernel_shape"); Ints("strides", 1, 1); Ints("dilations", 1, 1); Ints("pads", 0, 0, 0, 0); Int("group", 1);
                    if (Find("auto_pad") is { String.Length: > 0 } auto && System.Text.Encoding.UTF8.GetString(auto.String) != "NOTSET")
                        result["auto_pad"] = Bytes(auto.String);
                    break;
                case "BatchNormalization": F32("epsilon", 1e-5f); F32("momentum", 0.9f); Int("training_mode", 0); break;
                case "HardSigmoid": F32("alpha", 0.2f); F32("beta", 0.5f); break;
                case "Squeeze": case "Unsqueeze": Ints("axes"); break;
                case "Transpose": Ints("perm"); break;
                case "Softmax": case "Concat": Int("axis", 1); break;
                case "ReduceMean": Ints("axes"); Int("keepdims", 1); Int("noop_with_empty_axes", 0); break;
                case "AveragePool": case "MaxPool":
                    Ints("kernel_shape"); Ints("strides", 1, 1); Ints("pads", 0, 0, 0, 0); Int("ceil_mode", 0); Int("count_include_pad", 0); break;
                case "Resize":
                    result["scales"] = Floats(Find("scales")?.Floats ?? []);
                    Text("mode", "nearest"); Text("coordinate_transformation_mode", "asymmetric"); Text("nearest_mode", "floor"); break;
                case "Reshape": Int("allowzero", 0); break;
                case "Slice":
                    foreach (string name in new[] { "starts", "ends", "axes", "steps" })
                        if (Find(name) is not null) Ints(name);
                    break;
            }
            return result;
        }
    }
}
