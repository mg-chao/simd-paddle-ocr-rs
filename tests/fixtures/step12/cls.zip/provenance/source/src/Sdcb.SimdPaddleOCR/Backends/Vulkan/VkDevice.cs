// Thin object wrappers over Vk.cs: instance/device/queue, buffers with
// memory-type selection (ReBAR fast path vs host-visible staging), shader
// modules from embedded SPIR-V, compute pipelines, descriptor sets, and
// one-shot command submission.
using System.Runtime.InteropServices;

namespace Sdcb.SimdPaddleOCR.Backends.Vulkan;

internal unsafe sealed class VkDevice : IDisposable
{
    public IntPtr Instance, PhysDevice, Device, Queue;
    public string DeviceName = "";
    public uint VendorId;
    public uint SubgroupSize;         // actual subgroup size (lanes)
    public uint SubgroupOps;          // VkSubgroupFeatureFlags (SHUFFLE = 0x10)
    public uint SubgroupStages;       // VkShaderStageFlags (COMPUTE = 0x20)
    public uint QueueFamily;
    public Vk.VkPhysicalDeviceMemoryProperties MemProps;
    public bool CoherentDeviceLocal;   // DEVICE_LOCAL|HOST_VISIBLE|HOST_COHERENT exists (ReBAR)
    public bool CoopMatrix;            // VK_KHR_cooperative_matrix (feature + ext enabled)
    public bool SubgroupSizeControl;   // VK_EXT_subgroup_size_control
    public bool ComputeSubgroupSize;   // ...and requiredSubgroupSizeStages covers compute
    public bool Coop16x16x16;          // fp16 A/B, fp32 C/result, subgroup scope 16x16x16
    public bool Coop8x16x16;           // same types, MxNxK 8x16x16 (Arc)
    public uint SubgroupMin = 1, SubgroupMax = 128;
    public uint MaxSharedMemory;       // maxComputeSharedMemorySize (bytes per workgroup)
    public ulong MaxStorageRange = uint.MaxValue;   // maxStorageBufferRange (bytes per binding)
    public int CoopM, CoopN, CoopK;    // best fp16->fp32 subgroup coopmat config
    public bool Storage16Bit;          // storageBuffer16BitAccess + shaderInt16 enabled
    public bool ShaderFloat16;         // shaderFloat16 (VK_KHR_shader_float16_int8) enabled — required by fp16 shaders
    public uint DeviceLocalHostVisibleType = uint.MaxValue;
    public uint HostVisibleCoherentType = uint.MaxValue;
    public bool PushDescriptors;
    /// <summary>Cannot pin a 16-lane subgroup: the sg32 cm shaders instead of sg16.</summary>
    public bool Sg32Subgroup => SubgroupMin > 16 && SubgroupMax >= 32;
    /// <summary>The MMA shape of the cm shader set this device selects is advertised:
    /// sg32 uses 16x16x16, sg16 (<c>conv1x1_cm</c>) uses 8x16x16.</summary>
    public bool CoopGemm => CoopMatrix && (Sg32Subgroup ? Coop16x16x16 : Coop8x16x16);
    public uint QueuePriority;          // VkQueueGlobalPriority granted (0 = driver default)
    private unsafe delegate* unmanaged[Cdecl]<IntPtr, uint, IntPtr, uint, uint, Vk.VkWriteDescriptorSet*, void> _pushDesc;
    public double TimestampPeriodNs = 1;
    private IntPtr _commandPool;
    private IntPtr _descPool;
    /// <summary>Guards the device-level command pool / descriptor pool (uploads, debug).</summary>
    public readonly object Sync = new();
    /// <summary>vkQueueSubmit on the single compute queue is externally synchronized;
    /// sessions record into their own pools and only serialize the submit itself.</summary>
    public readonly object QueueLock = new();
    private readonly Dictionary<string, VkPipeline> _pipes = new();

    /// <summary>Process-wide pipeline cache: every graph/session shares one
    /// VkPipeline per (shader, subgroup size). Set layouts carry
    /// PUSH_DESCRIPTOR_BIT when the extension is available — such layouts are
    /// only ever fed via vkCmdPushDescriptorSetKHR, never allocated sets.</summary>
    public VkPipeline GetPipeline(string name, Func<byte[]> spirv, int bindings, int pcBytes, uint reqSg = 0)
    {
        lock (_pipes)
        {
            string key = name + "/" + reqSg;
            if (_pipes.TryGetValue(key, out VkPipeline? p)) return p;
            p = NewPipeline(NewShaderModule(spirv()), bindings, pcBytes, reqSg, PushDescriptors);
            p.Name = name;
            p.Bindings = bindings;
            _pipes[key] = p;
            return p;
        }
    }

    public static VkDevice Create(uint deviceIndex = 0)
    {
        Vk.RegisterResolver();
        var d = new VkDevice();

        Vk.VkApplicationInfo app = new()
        {
            SType = VkConst.StApplicationInfo,
            AppVersion = 1, EngineVersion = 1, ApiVersion = (1u << 22) | (1u << 12), // Vulkan 1.1
        };
        Vk.VkInstanceCreateInfo ici = new() { SType = VkConst.StInstanceCreateInfo, PAppInfo = &app };
        Vk.Check(Vk.vkCreateInstance(&ici, null, out d.Instance), "vkCreateInstance");

        uint ndev = 0;
        Vk.Check(Vk.vkEnumeratePhysicalDevices(d.Instance, &ndev, null), "enum physical devices");
        if (ndev == 0) throw new PlatformNotSupportedException("Vulkan: no physical devices (no Vulkan-capable GPU/driver)");
        IntPtr* devs = stackalloc IntPtr[(int)ndev];
        Vk.Check(Vk.vkEnumeratePhysicalDevices(d.Instance, &ndev, devs), "enum physical devices");

        // Prefer discrete GPU; honor deviceIndex as "the nth discrete first, else nth overall".
        int chosen = -1;
        for (int pass = 0; pass < 2 && chosen < 0; pass++)
        {
            uint seen = 0;
            for (int i = 0; i < (int)ndev; i++)
            {
                Vk.VkPhysicalDeviceProperties p;
                Vk.vkGetPhysicalDeviceProperties(devs[i], &p);
                bool want = pass == 0 ? p.DeviceType == VkConst.PhysDeviceDiscrete : p.DeviceType != VkConst.PhysDeviceCpu;
                if (!want) continue;
                if (seen++ == deviceIndex) { chosen = i; break; }
            }
        }
        if (chosen < 0) throw new PlatformNotSupportedException($"Vulkan: device index {deviceIndex} out of range ({ndev} devices)");
        d.PhysDevice = devs[chosen];

        Vk.VkPhysicalDeviceProperties props;
        Vk.vkGetPhysicalDeviceProperties(d.PhysDevice, &props);
        d.DeviceName = Marshal.PtrToStringAnsi((IntPtr)props.DeviceName) ?? "?";
        d.VendorId = props.VendorID;
        d.TimestampPeriodNs = props.TimestampPeriodNs;
        d.MaxSharedMemory = props.MaxComputeSharedMemorySize;
        d.MaxStorageRange = props.MaxStorageBufferRange;

        uint nqf = 0;
        Vk.vkGetPhysicalDeviceQueueFamilyProperties(d.PhysDevice, &nqf, null);
        Vk.VkQueueFamilyProperties* qf = stackalloc Vk.VkQueueFamilyProperties[(int)nqf];
        Vk.vkGetPhysicalDeviceQueueFamilyProperties(d.PhysDevice, &nqf, qf);
        // Prefer a compute-only family (no GRAPHICS bit): on Intel Arc it maps
        // to the dedicated CCS engine, on NVIDIA/AMD to async-compute queues —
        // our dispatches then no longer time-slice with desktop/compositor
        // 3D work on the render engine. SIMD_OCR_VK_QUEUE=gfx forces family 0-style.
        d.QueueFamily = uint.MaxValue;
        bool allowDedicated = !string.Equals(
            Environment.GetEnvironmentVariable("SIMD_OCR_VK_QUEUE"), "gfx", StringComparison.OrdinalIgnoreCase);
        for (uint i = 0; i < nqf && allowDedicated; i++)
            if ((qf[i].QueueFlags & VkConst.QueueCompute) != 0 && (qf[i].QueueFlags & 1u) == 0
                && qf[i].TimestampValidBits != 0)
            { d.QueueFamily = i; break; }
        for (uint i = 0; i < nqf && d.QueueFamily == uint.MaxValue; i++)
            if ((qf[i].QueueFlags & VkConst.QueueCompute) != 0) { d.QueueFamily = i; break; }
        if (Environment.GetEnvironmentVariable("HYMT_VK_VERBOSE") == "1")
            for (uint i = 0; i < nqf; i++)
                Console.Error.WriteLine($"[vk] qfamily {i}: flags=0x{qf[i].QueueFlags:x} count={qf[i].QueueCount} tsBits={qf[i].TimestampValidBits}{(i == d.QueueFamily ? " <- selected" : "")}");
        if (d.QueueFamily == uint.MaxValue)
            throw new PlatformNotSupportedException("Vulkan: no compute queue family");

        // Feature probe: 16-bit storage (u16 buffer views for non-4B-aligned blocks like Q6_K) + shaderInt16.
        Vk.VkPhysicalDevice16BitStorageFeatures s16query = new() { SType = VkConst.StPhysicalDevice16BitStorageFeatures };
        Vk.VkPhysicalDeviceShaderFloat16Int8Features f16query = new() { SType = VkConst.StPhysicalDeviceShaderFloat16Int8Features };
        s16query.PNext = &f16query;
        Vk.VkPhysicalDeviceFeatures2 f2 = new() { SType = VkConst.StPhysicalDeviceFeatures2, PNext = &s16query };
        Vk.vkGetPhysicalDeviceFeatures2(d.PhysDevice, &f2);
        Vk.VkPhysicalDeviceFeatures coreF;
        Vk.vkGetPhysicalDeviceFeatures(d.PhysDevice, &coreF);
        d.Storage16Bit = s16query.StorageBuffer16BitAccess != 0 && coreF.ShaderInt16 != 0;
        d.ShaderFloat16 = f16query.ShaderFloat16 != 0;
        if (Environment.GetEnvironmentVariable("HYMT_VK_DEBUG") == "1")
            Console.Error.WriteLine($"vk-dbg device={d.DeviceName} api={props.ApiVersion:x8} s16={s16query.StorageBuffer16BitAccess} int16(core)={coreF.ShaderInt16} int16(f2)={f2.Features.ShaderInt16} f36core={coreF.F[36]}");

        // Extension probe: VK_KHR_push_descriptor (llama.cpp-style inline descriptor writes,
        // skips per-dispatch descriptor-set binds).
        uint next = 0;
        Vk.vkEnumerateDeviceExtensionProperties(d.PhysDevice, null, &next, null);
        Vk.VkExtensionProperties* exts = stackalloc Vk.VkExtensionProperties[(int)next];
        Vk.vkEnumerateDeviceExtensionProperties(d.PhysDevice, null, &next, exts);
        byte* wantPush = stackalloc byte[] { (byte)'V', (byte)'K', (byte)'_', (byte)'K', (byte)'H', (byte)'R',
            (byte)'_', (byte)'p', (byte)'u', (byte)'s', (byte)'h', (byte)'_', (byte)'d', (byte)'e', (byte)'s', (byte)'c',
            (byte)'r', (byte)'i', (byte)'p', (byte)'t', (byte)'o', (byte)'r', 0 };
        bool hasPush = false, hasCoop = false, hasSgc = false, hasF16Int8 = false;
        string? prioExt = null;
        for (int i = 0; i < (int)next; i++)
        {
            string en = new((sbyte*)exts[i].ExtensionName);
            if (en == "VK_KHR_push_descriptor") hasPush = true;
            else if (en == "VK_KHR_global_priority") prioExt = en;
            else if (en == "VK_EXT_global_priority") prioExt ??= en;
            else if (en == "VK_KHR_cooperative_matrix") hasCoop = true;
            else if (en == "VK_EXT_subgroup_size_control") hasSgc = true;
            else if (en == "VK_KHR_shader_float16_int8") hasF16Int8 = true;
        }
        // SIMD_OCR_VK_NOPUSH=1: exercise the descriptor-pool fallback on devices that have push
        if (Environment.GetEnvironmentVariable("SIMD_OCR_VK_NOPUSH") == "1") hasPush = false;

        Vk.VkPhysicalDeviceCooperativeMatrixFeaturesKHR coopQ = new() { SType = VkConst.StPhysicalDeviceCooperativeMatrixFeaturesKHR };
        if (hasCoop)
        {
            Vk.VkPhysicalDeviceFeatures2 fq = new() { SType = VkConst.StPhysicalDeviceFeatures2, PNext = &coopQ };
            Vk.vkGetPhysicalDeviceFeatures2(d.PhysDevice, &fq);
            d.CoopMatrix = coopQ.CooperativeMatrix != 0;
        }

        float prio = 1f;
        Vk.VkDeviceQueueCreateInfo qci = new()
        {
            SType = VkConst.StDeviceQueueCreateInfo,
            QueueFamilyIndex = d.QueueFamily, QueueCount = 1, PQueuePriorities = &prio,
        };
        Vk.VkPhysicalDevice16BitStorageFeatures s16en = new()
        {
            SType = VkConst.StPhysicalDevice16BitStorageFeatures,
            StorageBuffer16BitAccess = d.Storage16Bit ? 1u : 0u,
        };
        Vk.VkPhysicalDeviceCooperativeMatrixFeaturesKHR coopEn = new()
        {
            SType = VkConst.StPhysicalDeviceCooperativeMatrixFeaturesKHR,
            CooperativeMatrix = d.CoopMatrix ? 1u : 0u,
        };
        {
            Vk.VkPhysicalDeviceSubgroupProperties sgP = new() { SType = VkConst.StPhysicalDeviceSubgroupProperties };
            Vk.VkPhysicalDeviceSubgroupSizeControlProperties sgcP = new() { SType = VkConst.StPhysicalDeviceSubgroupSizeControlPropertiesEXT };
            if (hasSgc) sgP.PNext = &sgcP;
            Vk.VkPhysicalDeviceProperties2 p2 = new() { SType = VkConst.StPhysicalDeviceProperties2, PNext = &sgP };
            Vk.vkGetPhysicalDeviceProperties2(d.PhysDevice, &p2);
            d.SubgroupSize = sgP.SubgroupSize;
            d.SubgroupOps = sgP.SupportedOperations;
            d.SubgroupStages = sgP.SupportedStages;
            if (hasSgc)
            {
                d.SubgroupMin = sgcP.MinSubgroupSize; d.SubgroupMax = sgcP.MaxSubgroupSize;
                d.ComputeSubgroupSize = (sgcP.RequiredSubgroupSizeStages & VkConst.StageComputeShader) != 0;
            }
        }

        Vk.VkPhysicalDeviceSubgroupSizeControlFeaturesEXT sgcEn = new()
        {
            SType = VkConst.StPhysicalDeviceSubgroupSizeControlFeaturesEXT,
            SubgroupSizeControl = hasSgc ? 1u : 0u,
        };
        d.SubgroupSizeControl = hasSgc;
        Vk.VkPhysicalDeviceShaderFloat16Int8Features f16en = new()
        {
            SType = VkConst.StPhysicalDeviceShaderFloat16Int8Features,
            ShaderFloat16 = d.ShaderFloat16 ? 1u : 0u,
        };
        if (Environment.GetEnvironmentVariable("HYMT_VK_DEBUG") == "1")
            Console.Error.WriteLine($"vk-dbg coop={d.CoopMatrix} sgc={hasSgc} sgMin={d.SubgroupMin} sgMax={d.SubgroupMax} push={hasPush} f16={d.ShaderFloat16}");
        f16en.PNext = d.CoopMatrix ? &coopEn : hasSgc ? &sgcEn : null;
        s16en.PNext = hasF16Int8 && d.ShaderFloat16 ? &f16en : f16en.PNext;
        coopEn.PNext = hasSgc ? &sgcEn : null;
        Vk.VkPhysicalDeviceFeatures feats = new();
        if (d.Storage16Bit) feats.ShaderInt16 = 1;
        byte* wantCoop = stackalloc byte[] { (byte)'V', (byte)'K', (byte)'_', (byte)'K', (byte)'H', (byte)'R',
            (byte)'_', (byte)'c', (byte)'o', (byte)'o', (byte)'p', (byte)'e', (byte)'r', (byte)'a', (byte)'t',
            (byte)'i', (byte)'v', (byte)'e', (byte)'_', (byte)'m', (byte)'a', (byte)'t', (byte)'r', (byte)'i',
            (byte)'x', 0 };
        byte* wantSgc = stackalloc byte[] { (byte)'V', (byte)'K', (byte)'_', (byte)'E', (byte)'X', (byte)'T',
            (byte)'_', (byte)'s', (byte)'u', (byte)'b', (byte)'g', (byte)'r', (byte)'o', (byte)'u', (byte)'p',
            (byte)'_', (byte)'s', (byte)'i', (byte)'z', (byte)'e', (byte)'_', (byte)'c', (byte)'o', (byte)'n',
            (byte)'t', (byte)'r', (byte)'o', (byte)'l', 0 };
        byte* wantF16 = stackalloc byte[] { (byte)'V', (byte)'K', (byte)'_', (byte)'K', (byte)'H', (byte)'R',
            (byte)'_', (byte)'s', (byte)'h', (byte)'a', (byte)'d', (byte)'e', (byte)'r', (byte)'_', (byte)'f',
            (byte)'l', (byte)'o', (byte)'a', (byte)'t', (byte)'1', (byte)'6', (byte)'_', (byte)'i', (byte)'n',
            (byte)'t', (byte)'8', 0 };
        byte** extsToEnable = stackalloc byte*[5];
        uint nExt = 0;
        if (hasPush) extsToEnable[nExt++] = wantPush;
        if (d.CoopMatrix) extsToEnable[nExt++] = wantCoop;
        if (hasSgc) extsToEnable[nExt++] = wantSgc;
        if (hasF16Int8 && d.ShaderFloat16) extsToEnable[nExt++] = wantF16;
        Vk.VkDeviceCreateInfo dci = new()
        {
            SType = VkConst.StDeviceCreateInfo,
            QueueCreateInfoCount = 1, PQueueCreateInfos = &qci,
            PEnabledFeatures = &feats,
            PNext = &s16en,
            EnabledExtensionCount = nExt,
            PpEnabledExtensionNames = nExt > 0 ? extsToEnable : null,
        };
        if (Environment.GetEnvironmentVariable("HYMT_VK_VERBOSE") == "1")
            Console.Error.WriteLine($"[vk] devext push={hasPush} coop={d.CoopMatrix} sgc={hasSgc} sgRange={d.SubgroupMin}-{d.SubgroupMax} sgcCompute={d.ComputeSubgroupSize} lds={d.MaxSharedMemory} prio={prioExt}");
        // Global queue priority (latency-sensitive inference sharing the GPU
        // with a desktop/compositor): try HIGH, then fall back to default when
        // the OS refuses (VK_ERROR_NOT_PERMITTED / INITIALIZATION_FAILED).
        // SIMD_OCR_VK_PRIORITY=off|medium|high|realtime overrides.
        uint wantPrio = (Environment.GetEnvironmentVariable("SIMD_OCR_VK_PRIORITY") ?? "high").ToLowerInvariant() switch
        {
            "off" or "medium" => 0u, "realtime" => 1024u, _ => 512u,
        };
        VkResult created = VkResult.ErrorInitializationFailed;
        if (prioExt != null && wantPrio != 0)
        {
            byte[] prioName = System.Text.Encoding.ASCII.GetBytes(prioExt + "\0");
            fixed (byte* pn = prioName)
            {
                extsToEnable[nExt] = pn;
                dci.EnabledExtensionCount = nExt + 1;
                dci.PpEnabledExtensionNames = extsToEnable;
                Vk.VkDeviceQueueGlobalPriorityCreateInfo gp = new()
                {
                    SType = 1000174000u, GlobalPriority = wantPrio,
                };
                qci.PNext = &gp;
                created = Vk.vkCreateDevice(d.PhysDevice, &dci, null, out d.Device);
                qci.PNext = null;
                if (created == VkResult.Success) d.QueuePriority = wantPrio;
            }
            dci.EnabledExtensionCount = nExt;
            dci.PpEnabledExtensionNames = nExt > 0 ? extsToEnable : null;
        }
        if (created != VkResult.Success)
            Vk.Check(Vk.vkCreateDevice(d.PhysDevice, &dci, null, out d.Device), "vkCreateDevice");
        if (Environment.GetEnvironmentVariable("HYMT_VK_VERBOSE") == "1")
            Console.Error.WriteLine($"[vk] queue family={d.QueueFamily} globalPriority={d.QueuePriority}");
        Vk.vkGetDeviceQueue(d.Device, d.QueueFamily, 0, out d.Queue);
        if (d.CoopMatrix)
        {
            byte* fnCm = stackalloc byte[] { (byte)'v', (byte)'k', (byte)'G', (byte)'e', (byte)'t',
                (byte)'P', (byte)'h', (byte)'y', (byte)'s', (byte)'i', (byte)'c', (byte)'a', (byte)'l',
                (byte)'D', (byte)'e', (byte)'v', (byte)'i', (byte)'c', (byte)'e', (byte)'C', (byte)'o',
                (byte)'o', (byte)'p', (byte)'e', (byte)'r', (byte)'a', (byte)'t', (byte)'i', (byte)'v',
                (byte)'e', (byte)'M', (byte)'a', (byte)'t', (byte)'r', (byte)'i', (byte)'x', (byte)'P',
                (byte)'r', (byte)'o', (byte)'p', (byte)'e', (byte)'r', (byte)'t', (byte)'i', (byte)'e',
                (byte)'s', (byte)'K', (byte)'H', (byte)'R', 0 };
            IntPtr fncm = Vk.vkGetInstanceProcAddr(d.Instance, fnCm);
            if (fncm != IntPtr.Zero)
            {
                var qprops = (delegate* unmanaged[Cdecl]<IntPtr, uint*, Vk.VkCooperativeMatrixPropertiesKHR*, VkResult>)fncm;
                uint np = 0;
                qprops(d.PhysDevice, &np, null);
                var cmprops = stackalloc Vk.VkCooperativeMatrixPropertiesKHR[(int)np];
                for (int i = 0; i < (int)np; i++) cmprops[i].SType = VkConst.StCooperativeMatrixPropertiesKHR;
                qprops(d.PhysDevice, &np, cmprops);
                for (int i = 0; i < (int)np; i++)
                {
                    // AType/BType 0 = float16 KHR, CType/ResultType 1 = float32, scope 3 = subgroup
                    if (cmprops[i].AType == 0 && cmprops[i].BType == 0 && cmprops[i].ResultType == 1 && cmprops[i].Scope == 3
                        && cmprops[i].MSize > (uint)d.CoopM)
                    {
                        d.CoopM = (int)cmprops[i].MSize; d.CoopN = (int)cmprops[i].NSize; d.CoopK = (int)cmprops[i].KSize;
                    }
                    if (cmprops[i].AType == 0 && cmprops[i].BType == 0 && cmprops[i].CType == 1 && cmprops[i].ResultType == 1
                        && cmprops[i].Scope == 3 && cmprops[i].NSize == 16 && cmprops[i].KSize == 16)
                    {
                        if (cmprops[i].MSize == 16) d.Coop16x16x16 = true;
                        if (cmprops[i].MSize == 8) d.Coop8x16x16 = true;
                    }
                    if (Environment.GetEnvironmentVariable("HYMT_VK_VERBOSE") == "1")
                        Console.Error.WriteLine($"[vk] coopmat {cmprops[i].MSize}x{cmprops[i].NSize}x{cmprops[i].KSize} at={cmprops[i].AType} bt={cmprops[i].BType} ct={cmprops[i].CType} rt={cmprops[i].ResultType} scope={cmprops[i].Scope}");
                }
            }
        }
        if (hasPush)
        {
            byte* fnName = stackalloc byte[] { (byte)'v', (byte)'k', (byte)'C', (byte)'m', (byte)'d',
                (byte)'P', (byte)'u', (byte)'s', (byte)'h', (byte)'D', (byte)'e', (byte)'s', (byte)'c',
                (byte)'r', (byte)'i', (byte)'p', (byte)'t', (byte)'o', (byte)'r', (byte)'S', (byte)'e',
                (byte)'t', (byte)'K', (byte)'H', (byte)'R', 0 };
            IntPtr fn = Vk.vkGetDeviceProcAddr(d.Device, fnName);
            if (Environment.GetEnvironmentVariable("HYMT_VK_VERBOSE") == "1")
                Console.Error.WriteLine($"[vk] push_descriptor ext={hasPush} fn=0x{fn:X}");
            if (fn != IntPtr.Zero)
            {
                d.PushDescriptors = true;
                d._pushDesc = (delegate* unmanaged[Cdecl]<IntPtr, uint, IntPtr, uint, uint, Vk.VkWriteDescriptorSet*, void>)fn;
            }
        }

        fixed (Vk.VkPhysicalDeviceMemoryProperties* mp = &d.MemProps)
            Vk.vkGetPhysicalDeviceMemoryProperties(d.PhysDevice, mp);
        for (int i = 0; i < (int)d.MemProps.MemoryTypeCount; i++)
        {
            uint f = d.MemProps.TypeAt(i).PropertyFlags;
            if ((f & (VkConst.MemDeviceLocal | VkConst.MemHostVisible | VkConst.MemHostCoherent)) == (VkConst.MemDeviceLocal | VkConst.MemHostVisible | VkConst.MemHostCoherent)
                && d.DeviceLocalHostVisibleType == uint.MaxValue)
                d.DeviceLocalHostVisibleType = (uint)i;
            if ((f & (VkConst.MemHostVisible | VkConst.MemHostCoherent)) == (VkConst.MemHostVisible | VkConst.MemHostCoherent)
                && d.HostVisibleCoherentType == uint.MaxValue)
                d.HostVisibleCoherentType = (uint)i;
        }
        d.CoherentDeviceLocal = d.DeviceLocalHostVisibleType != uint.MaxValue;

        Vk.VkCommandPoolCreateInfo cpci = new()
        {
            SType = VkConst.StCommandPoolCreateInfo,
            Flags = VkConst.CmdPoolResetCommandBuffer,
            QueueFamilyIndex = d.QueueFamily,
        };
        Vk.Check(Vk.vkCreateCommandPool(d.Device, &cpci, null, out d._commandPool), "vkCreateCommandPool");

        Vk.VkDescriptorPoolSize psz = new() { Type = VkConst.DescStorageBuffer, DescriptorCount = 1 << 20 };
        Vk.VkDescriptorPoolCreateInfo dpci = new()
        {
            SType = VkConst.StDescriptorPoolCreateInfo,
            // FREE_DESCRIPTOR_SET_BIT: the GPU graph evicts cached plans
            // (variable-shape runs) and releases their descriptor sets.
            Flags = 1, MaxSets = 1 << 16, PoolSizeCount = 1, PPoolSizes = &psz,
        };
        Vk.Check(Vk.vkCreateDescriptorPool(d.Device, &dpci, null, out d._descPool), "vkCreateDescriptorPool");
        return d;
    }

    /// <summary>Allocate a storage buffer. hostVisible=false prefers DEVICE_LOCAL;
    /// hostVisible=true prefers DEVICE_LOCAL|HOST_VISIBLE|HOST_COHERENT (ReBAR zero-copy), falling
    /// back to HOST_VISIBLE|HOST_COHERENT. preferHost skips DEVICE_LOCAL types — for buffers the
    /// CPU reads (uncached WC reads from VRAM are ~15MB/s, catastrophic).</summary>
    public VkBuffer NewStorageBuffer(ulong bytes, bool hostVisible, bool preferHost = false)
    {
        var b = new VkBuffer { Dev = Device, Size = bytes };
        Vk.VkBufferCreateInfo bci = new()
        {
            SType = VkConst.StBufferCreateInfo,
            Size = bytes,
            Usage = VkConst.BufferUsageStorageBuffer | VkConst.BufferUsageTransferSrc | VkConst.BufferUsageTransferDst,
            SharingMode = VkConst.SharingExclusive,
        };
        Vk.Check(Vk.vkCreateBuffer(Device, &bci, null, out IntPtr buffer), "vkCreateBuffer");
        b.Buffer = buffer;
        try
        {
            Vk.VkMemoryRequirements req;
            Vk.vkGetBufferMemoryRequirements(Device, b.Buffer, &req);
            uint memType = uint.MaxValue;
            for (int i = 0; i < (int)MemProps.MemoryTypeCount; i++)
            {
                if ((req.MemoryTypeBits & (1u << i)) == 0) continue;
                uint f = MemProps.TypeAt(i).PropertyFlags;
                bool ok;
                if (!hostVisible)
                    ok = (f & VkConst.MemDeviceLocal) != 0;
                else if (preferHost)
                    ok = (f & (VkConst.MemHostVisible | VkConst.MemHostCoherent)) == (VkConst.MemHostVisible | VkConst.MemHostCoherent)
                         && (f & VkConst.MemDeviceLocal) == 0
                         && (f & VkConst.MemHostCached) != 0;
                else
                    ok = (f & VkConst.MemHostVisible) != 0 && (f & VkConst.MemHostCoherent) != 0;
                if (ok && (memType == uint.MaxValue || (!preferHost && (f & VkConst.MemDeviceLocal) != 0)))
                {
                    memType = (uint)i;
                    if (preferHost || (f & VkConst.MemDeviceLocal) != 0) break;
                }
            }
            if (memType == uint.MaxValue && preferHost)
            {
                // relax: some drivers expose host-visible non-local types without CACHED
                for (int i = 0; i < (int)MemProps.MemoryTypeCount && memType == uint.MaxValue; i++)
                {
                    if ((req.MemoryTypeBits & (1u << i)) == 0) continue;
                    uint f = MemProps.TypeAt(i).PropertyFlags;
                    if ((f & (VkConst.MemHostVisible | VkConst.MemHostCoherent)) == (VkConst.MemHostVisible | VkConst.MemHostCoherent)
                        && (f & VkConst.MemDeviceLocal) == 0)
                        memType = (uint)i;
                }
            }
            // UMA (Intel iGPU): every heap is DEVICE_LOCAL, so the non-local
            // preference above matches nothing. Cached host-visible is still
            // the CPU readback type. Discrete parts never get here — they
            // have a non-local host type and already returned.
            if (memType == uint.MaxValue && preferHost)
            {
                for (int i = 0; i < (int)MemProps.MemoryTypeCount && memType == uint.MaxValue; i++)
                {
                    if ((req.MemoryTypeBits & (1u << i)) == 0) continue;
                    uint f = MemProps.TypeAt(i).PropertyFlags;
                    if ((f & (VkConst.MemHostVisible | VkConst.MemHostCoherent | VkConst.MemHostCached))
                        == (VkConst.MemHostVisible | VkConst.MemHostCoherent | VkConst.MemHostCached))
                        memType = (uint)i;
                }
                for (int i = 0; i < (int)MemProps.MemoryTypeCount && memType == uint.MaxValue; i++)
                {
                    if ((req.MemoryTypeBits & (1u << i)) == 0) continue;
                    uint f = MemProps.TypeAt(i).PropertyFlags;
                    if ((f & (VkConst.MemHostVisible | VkConst.MemHostCoherent))
                        == (VkConst.MemHostVisible | VkConst.MemHostCoherent))
                        memType = (uint)i;
                }
            }
            if (memType == uint.MaxValue)
                throw new PlatformNotSupportedException($"Vulkan: no suitable memory type for {bytes}-byte buffer (hostVisible={hostVisible})");
            Vk.VkMemoryAllocateInfo mai = new()
            {
                SType = VkConst.StMemoryAllocateInfo,
                AllocationSize = req.Size, MemoryTypeIndex = memType,
            };
            VkResult allocation = Vk.vkAllocateMemory(Device, &mai, null, out IntPtr memory);
            if (allocation == VkResult.Success)
            {
                b.Memory = memory;
            }
            else
            {
                string attempts = $"{DescribeMemoryType(memType)}: {allocation}";
                if (hostVisible && allocation is (VkResult.ErrorOutOfDeviceMemory or VkResult.ErrorOutOfHostMemory))
                {
                    // A host-visible device-local heap can expose a smaller mapping window
                    // than total VRAM. Keep running the same GPU graph using compatible
                    // coherent memory, trying non-device-local types first.
                    uint preferredType = memType;
                    for (int local = 0; local < 2 && allocation is (VkResult.ErrorOutOfDeviceMemory or VkResult.ErrorOutOfHostMemory); local++)
                    {
                        for (int i = 0; i < (int)MemProps.MemoryTypeCount; i++)
                        {
                            if ((uint)i == preferredType || (req.MemoryTypeBits & (1u << i)) == 0) continue;
                            uint flags = MemProps.TypeAt(i).PropertyFlags;
                            const uint memDeviceCoherentAmd = 0x40;
                            // deviceCoherentMemory is not enabled on this device:
                            // VUID-vkAllocateMemory-deviceCoherentMemory-02790.
                            if ((flags & memDeviceCoherentAmd) != 0) continue;
                            if ((flags & (VkConst.MemHostVisible | VkConst.MemHostCoherent))
                                != (VkConst.MemHostVisible | VkConst.MemHostCoherent)) continue;
                            if (((flags & VkConst.MemDeviceLocal) != 0) != (local == 1)) continue;
                            mai.MemoryTypeIndex = (uint)i;
                            allocation = Vk.vkAllocateMemory(Device, &mai, null, out memory);
                            if (allocation == VkResult.Success)
                            {
                                memType = (uint)i;
                                b.Memory = memory;
                                break;
                            }
                            attempts += $"; {DescribeMemoryType((uint)i)}: {allocation}";
                            if (allocation is not (VkResult.ErrorOutOfDeviceMemory or VkResult.ErrorOutOfHostMemory)) break;
                        }
                    }
                }
                if (allocation != VkResult.Success)
                    throw new InvalidOperationException(
                        $"Vulkan vkAllocateMemory failed: {allocation}; bufferBytes={bytes}, allocationBytes={req.Size}, " +
                        $"hostVisible={hostVisible}, preferHost={preferHost}, memoryTypeBits=0x{req.MemoryTypeBits:x}; {attempts}");
            }
            VkResult binding = Vk.vkBindBufferMemory(Device, b.Buffer, b.Memory, 0);
            if (binding != VkResult.Success)
                throw new InvalidOperationException(
                    $"Vulkan vkBindBufferMemory failed: {binding}; bufferBytes={bytes}, allocationBytes={req.Size}, {DescribeMemoryType(memType)}");
            b.Flags = MemProps.TypeAt((int)memType).PropertyFlags;
            return b;
        }
        catch
        {
            // Only successful allocations are stored in b; also release the buffer
            // when memory selection, allocation, or binding fails.
            b.Free();
            throw;
        }
        string DescribeMemoryType(uint typeIndex)
        {
            Vk.VkMemoryType type = MemProps.TypeAt((int)typeIndex);
            Vk.VkMemoryHeap heap = MemProps.HeapAt((int)type.HeapIndex);
            return $"type={typeIndex}, flags=0x{type.PropertyFlags:x}, heap={type.HeapIndex}, heapBytes={heap.Size}";
        }
    }

    public IntPtr NewShaderModule(byte[] spirv)
    {
        if ((spirv.Length & 3) != 0) throw new ArgumentException("SPIR-V size must be a multiple of 4");
        fixed (byte* p = spirv)
        {
            Vk.VkShaderModuleCreateInfo ci = new()
            {
                SType = VkConst.StShaderModuleCreateInfo,
                CodeSize = (nuint)spirv.Length, PCode = (uint*)p,
            };
            Vk.Check(Vk.vkCreateShaderModule(Device, &ci, null, out IntPtr m), "vkCreateShaderModule");
            return m;
        }
    }

    /// <summary>One set layout with `bindings` storage buffers (0..bindings-1) + push constants.</summary>
    public VkPipeline NewPipeline(IntPtr shaderModule, int bindings, int pushConstBytes, uint requiredSubgroupSize = 0,
        bool pushLayout = false)
    {
        var dslb = stackalloc Vk.VkDescriptorSetLayoutBinding[bindings];
        for (int i = 0; i < bindings; i++)
            dslb[i] = new Vk.VkDescriptorSetLayoutBinding
            {
                Binding = (uint)i, DescriptorType = VkConst.DescStorageBuffer,
                DescriptorCount = 1, StageFlags = VkConst.StageComputeShader,
            };
        IntPtr setLayout;
        Vk.VkDescriptorSetLayoutCreateInfo dslci = new()
        {
            SType = VkConst.StDescriptorSetLayoutCreateInfo,
            BindingCount = (uint)bindings, PBindings = dslb,
            Flags = pushLayout ? 1u : 0u,   // VK_DESCRIPTOR_SET_LAYOUT_CREATE_PUSH_DESCRIPTOR_BIT_KHR
        };
        Vk.Check(Vk.vkCreateDescriptorSetLayout(Device, &dslci, null, out setLayout), "vkCreateDescriptorSetLayout");

        Vk.VkPushConstantRange pcr = new()
        {
            StageFlags = VkConst.StageComputeShader, Offset = 0, Size = (uint)pushConstBytes,
        };
        IntPtr layout;
        Vk.VkPipelineLayoutCreateInfo plci = new()
        {
            SType = VkConst.StPipelineLayoutCreateInfo,
            SetLayoutCount = 1, PSetLayouts = &setLayout,
            PushConstantRangeCount = 1, PPushConstantRanges = &pcr,
        };
        Vk.Check(Vk.vkCreatePipelineLayout(Device, &plci, null, out layout), "vkCreatePipelineLayout");

        byte* name = stackalloc byte[5] { (byte)'m', (byte)'a', (byte)'i', (byte)'n', 0 };
        Vk.VkPipelineShaderStageRequiredSubgroupSizeCreateInfo sgc = new()
        {
            SType = VkConst.StPipelineShaderStageRequiredSubgroupSizeCreateInfo,
            RequiredSubgroupSize = requiredSubgroupSize,
        };
        Vk.VkComputePipelineCreateInfo cpci = new()
        {
            SType = VkConst.StComputePipelineCreateInfo,
            Stage = new Vk.VkPipelineShaderStageCreateInfo
            {
                SType = VkConst.StPipelineShaderStageCreateInfo,
                Stage = VkConst.StageComputeShader, Module = shaderModule, PName = name,
                PNext = requiredSubgroupSize != 0 && SubgroupSizeControl ? &sgc : null,
            },
            Layout = layout,
        };
        IntPtr pipeline;
        Vk.Check(Vk.vkCreateComputePipelines(Device, IntPtr.Zero, 1, &cpci, null, &pipeline), "vkCreateComputePipelines");
        return new VkPipeline { Pipeline = pipeline, Layout = layout, SetLayout = setLayout, PushLayout = pushLayout };
    }

    public IntPtr NewCommandPool()
    {
        Vk.VkCommandPoolCreateInfo ci = new()
        {
            SType = VkConst.StCommandPoolCreateInfo,
            Flags = VkConst.CmdPoolResetCommandBuffer,
            QueueFamilyIndex = QueueFamily,
        };
        Vk.Check(Vk.vkCreateCommandPool(Device, &ci, null, out IntPtr pool), "vkCreateCommandPool");
        return pool;
    }

    public IntPtr AllocateCommandBuffer(IntPtr pool)
    {
        Vk.VkCommandBufferAllocateInfo ai = new()
        {
            SType = VkConst.StCommandBufferAllocateInfo,
            CommandPool = pool, Level = VkConst.CmdBufferLevelPrimary, CommandBufferCount = 1,
        };
        IntPtr cmd;
        Vk.Check(Vk.vkAllocateCommandBuffers(Device, &ai, &cmd), "vkAllocateCommandBuffers");
        return cmd;
    }

    public void DestroyCommandPool(IntPtr pool)
    {
        if (pool != IntPtr.Zero) Vk.vkDestroyCommandPool(Device, pool, null);
    }

    /// <summary>Resettable descriptor pool for the no-push-descriptor fallback.</summary>
    public IntPtr NewDescriptorPool(uint maxSets)
    {
        Vk.VkDescriptorPoolSize psz = new() { Type = VkConst.DescStorageBuffer, DescriptorCount = maxSets * 16 };
        Vk.VkDescriptorPoolCreateInfo dpci = new()
        {
            SType = VkConst.StDescriptorPoolCreateInfo,
            Flags = 0, MaxSets = maxSets, PoolSizeCount = 1, PPoolSizes = &psz,
        };
        Vk.Check(Vk.vkCreateDescriptorPool(Device, &dpci, null, out IntPtr pool), "vkCreateDescriptorPool");
        return pool;
    }

    public IntPtr AllocateDescriptorSet(IntPtr pool, IntPtr setLayout)
    {
        IntPtr set;
        Vk.VkDescriptorSetAllocateInfo ai = new()
        {
            SType = VkConst.StDescriptorSetAllocateInfo,
            DescriptorPool = pool, DescriptorSetCount = 1, PSetLayouts = &setLayout,
        };
        Vk.Check(Vk.vkAllocateDescriptorSets(Device, &ai, &set), "vkAllocateDescriptorSets");
        return set;
    }

    public IntPtr NewDescriptorSet(IntPtr setLayout)
    {
        IntPtr set;
        Vk.VkDescriptorSetAllocateInfo ai = new()
        {
            SType = VkConst.StDescriptorSetAllocateInfo,
            DescriptorPool = _descPool, DescriptorSetCount = 1, PSetLayouts = &setLayout,
        };
        Vk.Check(Vk.vkAllocateDescriptorSets(Device, &ai, &set), "vkAllocateDescriptorSets");
        return set;
    }

    public void FreeDescriptorSet(IntPtr set)
    {
        if (set != IntPtr.Zero)
            Vk.Check(Vk.vkFreeDescriptorSets(Device, _descPool, 1, &set), "vkFreeDescriptorSets");
    }

    public void FreeCommandBuffer(IntPtr cmd)
    {
        if (cmd != IntPtr.Zero)
            Vk.vkFreeCommandBuffers(Device, _commandPool, 1, &cmd);
    }

    /// <summary>VK_KHR_push_descriptor: write bindings inline into the command buffer
    /// (DstSet in each write is ignored).</summary>
    public void CmdPushDescriptors(IntPtr cmd, IntPtr layout, Vk.VkWriteDescriptorSet* writes, uint count)
        => _pushDesc(cmd, VkConst.BindPointCompute, layout, 0, count, writes);

    /// <summary>Record the standard write->read barrier between two compute dispatches.</summary>
    public void CmdComputeBarrier(IntPtr cmd)
    {
        Vk.VkMemoryBarrier mb = new()
        {
            SType = VkConst.StMemoryBarrier,
            SrcAccessMask = VkConst.AccessShaderWrite, DstAccessMask = VkConst.AccessShaderRead,
        };
        Vk.vkCmdPipelineBarrier(cmd, VkConst.PipelineStageComputeShader, VkConst.PipelineStageComputeShader, 0,
            1, &mb, 0, null, 0, null);
    }

    /// <summary>write->read barrier scoped to one buffer.</summary>
    public void CmdBufferBarrier(IntPtr cmd, VkBuffer buf)
    {
        Vk.VkBufferMemoryBarrier bb = new()
        {
            SType = VkConst.StBufferMemoryBarrier,
            SrcAccessMask = VkConst.AccessShaderWrite, DstAccessMask = VkConst.AccessShaderRead,
            SrcQueueFamilyIndex = Vk.QueueFamilyIgnored, DstQueueFamilyIndex = Vk.QueueFamilyIgnored,
            Buffer = buf.Buffer, Offset = 0, Size = buf.Size,
        };
        Vk.vkCmdPipelineBarrier(cmd, VkConst.PipelineStageComputeShader, VkConst.PipelineStageComputeShader, 0,
            0, null, 1, &bb, 0, null);
    }

    /// <summary>write->read barrier over several buffers in a single call.</summary>
    public void CmdBufferBarrier(IntPtr cmd, params VkBuffer[] bufs)
    {
        if (bufs.Length == 1) { CmdBufferBarrier(cmd, bufs[0]); return; }
        Vk.VkBufferMemoryBarrier* bb = stackalloc Vk.VkBufferMemoryBarrier[bufs.Length];
        for (int i = 0; i < bufs.Length; i++)
            bb[i] = new Vk.VkBufferMemoryBarrier
            {
                SType = VkConst.StBufferMemoryBarrier,
                SrcAccessMask = VkConst.AccessShaderWrite, DstAccessMask = VkConst.AccessShaderRead,
                SrcQueueFamilyIndex = Vk.QueueFamilyIgnored, DstQueueFamilyIndex = Vk.QueueFamilyIgnored,
                Buffer = bufs[i].Buffer, Offset = 0, Size = bufs[i].Size,
            };
        Vk.vkCmdPipelineBarrier(cmd, VkConst.PipelineStageComputeShader, VkConst.PipelineStageComputeShader, 0,
            0, null, (uint)bufs.Length, bb, 0, null);
    }

    /// <summary>Upload raw bytes into a buffer (host memcpy when mappable, else staging + copy cmd).</summary>
    public void Upload(VkBuffer buf, void* src, ulong bytes)
    {
        if ((buf.Flags & VkConst.MemHostVisible) != 0)
        {
            void* p = buf.Map();
            Buffer.MemoryCopy(src, p, bytes, bytes);
            buf.Flush(0, bytes);
            buf.Unmap();
            return;
        }
        VkBuffer staging = NewStorageBuffer(bytes, hostVisible: true);
        void* sp = staging.Map();
        Buffer.MemoryCopy(src, sp, bytes, bytes);
        staging.Flush(0, bytes);
        staging.Unmap();
        lock (Sync)
        {
            IntPtr cmd = NewCommandBuffer();
            IntPtr fence = NewFence();
            var begin = new Vk.VkCommandBufferBeginInfo { SType = VkConst.StCommandBufferBeginInfo };
            Vk.Check(Vk.vkBeginCommandBuffer(cmd, &begin), "vkBeginCommandBuffer");
            Vk.VkBufferCopy r = new() { Size = bytes };
            Vk.vkCmdCopyBuffer(cmd, staging.Buffer, buf.Buffer, 1, &r);
            Vk.Check(Vk.vkEndCommandBuffer(cmd), "vkEndCommandBuffer");
            Submit(cmd, fence);
            WaitFence(fence);
            Vk.vkDestroyFence(Device, fence, null);
            FreeCommandBuffer(cmd);
        }
        staging.Free();
    }

    /// <summary>Zero-fill a (device-local) buffer with one transfer command.</summary>
    public void Zero(VkBuffer buf)
    {
        lock (Sync)
        {
            IntPtr cmd = NewCommandBuffer();
            IntPtr fence = NewFence();
            var begin = new Vk.VkCommandBufferBeginInfo { SType = VkConst.StCommandBufferBeginInfo };
            Vk.Check(Vk.vkBeginCommandBuffer(cmd, &begin), "vkBeginCommandBuffer");
            Vk.vkCmdFillBuffer(cmd, buf.Buffer, 0, Vk.WholeSize, 0);
            Vk.Check(Vk.vkEndCommandBuffer(cmd), "vkEndCommandBuffer");
            Submit(cmd, fence);
            WaitFence(fence);
            Vk.vkDestroyFence(Device, fence, null);
            FreeCommandBuffer(cmd);
        }
    }

    public void BindBuffer(IntPtr set, uint binding, VkBuffer buf, ulong offset = 0)
    {
        Vk.VkDescriptorBufferInfo bi = new() { Buffer = buf.Buffer, Offset = offset, Range = buf.Size - offset };
        Vk.VkWriteDescriptorSet w = new()
        {
            SType = VkConst.StWriteDescriptorSet, DstSet = set, DstBinding = binding,
            DescriptorCount = 1, DescriptorType = VkConst.DescStorageBuffer, PBufferInfo = &bi,
        };
        Vk.vkUpdateDescriptorSets(Device, 1, &w, 0, null);
    }

    public IntPtr NewCommandBuffer()
    {
        Vk.VkCommandBufferAllocateInfo ai = new()
        {
            SType = VkConst.StCommandBufferAllocateInfo,
            CommandPool = _commandPool, Level = VkConst.CmdBufferLevelPrimary, CommandBufferCount = 1,
        };
        IntPtr cmd;
        Vk.Check(Vk.vkAllocateCommandBuffers(Device, &ai, &cmd), "vkAllocateCommandBuffers");
        return cmd;
    }

    public IntPtr NewFence(bool signaled = false)
    {
        Vk.VkFenceCreateInfo ci = new() { SType = VkConst.StFenceCreateInfo, Flags = signaled ? 1u : 0u };
        Vk.Check(Vk.vkCreateFence(Device, &ci, null, out IntPtr f), "vkCreateFence");
        return f;
    }

    public void Submit(IntPtr cmd, IntPtr fence)
    {
        Vk.VkSubmitInfo si = new()
        {
            SType = VkConst.StSubmitInfo,
            CommandBufferCount = 1, PCommandBuffers = &cmd,
        };
        VkResult r;
        lock (QueueLock) r = Vk.vkQueueSubmit(Queue, 1, &si, fence);
        Vk.Check(r, "vkQueueSubmit");
    }

    public void DestroyFence(IntPtr fence)
    {
        if (fence != IntPtr.Zero) Vk.vkDestroyFence(Device, fence, null);
    }

    public void WaitFence(IntPtr fence)
    {
        Vk.Check(Vk.vkWaitForFences(Device, 1, &fence, 1, ulong.MaxValue), "vkWaitForFences");
        // auto-reset: a fence must be unsignaled before reuse in vkQueueSubmit
        Vk.Check(Vk.vkResetFences(Device, 1, &fence), "vkResetFences");
    }

    public void Dispose()
    {
        if (Device != IntPtr.Zero) { Vk.vkDeviceWaitIdle(Device); Vk.vkDestroyDevice(Device, null); Device = IntPtr.Zero; }
        if (Instance != IntPtr.Zero) { Vk.vkDestroyInstance(Instance, null); Instance = IntPtr.Zero; }
    }
}

internal sealed class VkPipeline
{
    public IntPtr Pipeline, Layout, SetLayout;
    public string Name = "";
    public int Bindings;
    public bool PushLayout;
}

internal unsafe sealed class VkBuffer
{
    public IntPtr Dev, Buffer, Memory;
    public ulong Size;
    public uint Flags;

    public bool HostCoherent => (Flags & VkConst.MemHostCoherent) != 0;

    public void* Map()
    {
        void* p;
        Vk.Check(Vk.vkMapMemory(Dev, Memory, 0, Size, 0, &p), "vkMapMemory");
        return p;
    }
    public void Unmap() => Vk.vkUnmapMemory(Dev, Memory);

    public void Flush(ulong offset, ulong size)
    {
        if (HostCoherent) return;
        Vk.VkMappedMemoryRange r = new() { SType = VkConst.StMappedMemoryRange, Memory = Memory, Offset = offset, Size = size };
        Vk.vkFlushMappedMemoryRanges(Dev, 1, &r);
    }
    public void Invalidate(ulong offset, ulong size)
    {
        if (HostCoherent) return;
        Vk.VkMappedMemoryRange r = new() { SType = VkConst.StMappedMemoryRange, Memory = Memory, Offset = offset, Size = size };
        Vk.vkInvalidateMappedMemoryRanges(Dev, 1, &r);
    }

    public void Free()
    {
        if (Buffer != IntPtr.Zero) { Vk.vkDestroyBuffer(Dev, Buffer, null); Buffer = IntPtr.Zero; }
        if (Memory != IntPtr.Zero) { Vk.vkFreeMemory(Dev, Memory, null); Memory = IntPtr.Zero; }
    }
}
