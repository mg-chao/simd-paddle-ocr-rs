using System.Text;
using Sdcb.SimdPaddleOCR.OnnxSharp;
using static Sdcb.SimdPaddleOCR.UnitTests.KernelCorrectnessTests;

namespace Sdcb.SimdPaddleOCR.UnitTests;

public class InferenceSessionTraceTests
{
    [Fact]
    public void RunWithTrace_CapturesValuesBeforeLaterInPlaceStepsOverwriteThem()
    {
        using Model model = ArithmeticModel();
        CompiledModel compiled = new(model, [1, 4], 1);
        try
        {
            using InferenceSession session = compiled.CreateRequest();
            List<(int Index, string Name, string Op, int[] Shape, bool Nhwc, float[] Values)> captures = [];
            float[] output = session.RunWithTrace([1, 2, 3, 4], (index, name, op, shape, nhwc, values) =>
                captures.Add((index, name, op, shape.ToArray(), nhwc, values.ToArray()))).ToArray();

            Assert.Equal(3, captures.Count);
            Assert.Equal(new float[] { 2, 3, 4, 5 }, captures[0].Values);
            Assert.Equal(new float[] { 4, 6, 8, 10 }, captures[1].Values);
            Assert.Equal(new float[] { 1, 3, 5, 7 }, captures[2].Values);
            Assert.Equal(captures[2].Values, output);
            for (int i = 0; i < captures.Count; i++)
            {
                Assert.Equal(i, captures[i].Index);
                Assert.Equal(new int[] { 1, 4 }, captures[i].Shape);
                Assert.False(captures[i].Nhwc);
            }
            Assert.Equal("plus-one", captures[0].Name);
            Assert.Equal("Add", captures[0].Op);

            // Mul and Sub reuse the dying preceding activation's workspace.
            // Collecting node views only after graph execution would lose the
            // distinct values asserted above.
            Assert.Equal(compiled.GetNode(0).Outputs[0], compiled.GetNode(1).Inputs[0]);
        }
        finally { compiled.Dispose(); }
    }

    [Fact]
    public void RunWithTrace_ReportsFusedSinkIndexAndPhysicalLayout()
    {
        using Model model = LoadGraph([1, 2, 1, 2], [1, 2, 1, 2],
            Node("identity-conv", "Conv", ["x", "w"], "conv", IntList("kernel_shape", 1, 1)),
            Node("rectified", "Relu", ["conv"], "y"),
            Tensor("w", [2, 2, 1, 1], [1, 0, 0, 1]));
        CompiledModel compiled = new(model, [1, 2, 1, 2], 1);
        try
        {
            using InferenceSession session = compiled.CreateRequest();
            float[] input = [-1, 2, 3, -4];
            float[] expected = session.Run(input);
            List<int> expectedIndexes = [];
            for (int i = 0; i < model.Nodes.Length; i++)
            {
                i += compiled.FusedSkip(i);
                expectedIndexes.Add(i);
            }
            List<int> observedIndexes = [];
            bool sawRelu = false;
            float[] actual = session.RunWithTrace(input, (index, name, op, shape, nhwc, values) =>
            {
                observedIndexes.Add(index);
                NodeRecord sink = model.Nodes[index];
                Assert.Equal(sink.Name, name);
                Assert.Equal(sink.OpType, op);
                Assert.Equal(compiled.IsNhwcTensor(sink.Outputs[0]), nhwc);
                if (name != "rectified") return;
                sawRelu = true;
                Assert.Equal("Relu", op);
                Assert.Equal(new int[] { 1, 2, 1, 2 }, shape.ToArray());
                Assert.Equal(nhwc ? new float[] { 0, 3, 2, 0 } : new float[] { 0, 2, 3, 0 }, values.ToArray());
            }).ToArray();

            Assert.True(sawRelu);
            Assert.Equal(expectedIndexes, observedIndexes);
            Assert.Equal(new float[] { 0, 2, 3, 0 }, actual);
            AssertClose(expected, actual);
            if (Environment.GetEnvironmentVariable("SIMD_OCR_NOFUSE") != "1")
                Assert.Contains(Enumerable.Range(0, model.Nodes.Length), i => compiled.FusedSkip(i) > 0);
        }
        finally { compiled.Dispose(); }
    }

    [Fact]
    public void RunWithTrace_PromotesCtcPartialWorkspaceToFullGraph()
    {
        using Model model = LoadGraph([0, 3], [0, 2],
            Node("prepare", "Add", ["x", "one"], "prepared"),
            Node("projection", "MatMul", ["prepared", "w"], "projected"),
            Node("bias", "Add", ["projected", "bias"], "logits"),
            Node("probabilities", "Softmax", ["logits"], "y"),
            Tensor("one", [1], [1]), Tensor("w", [3, 2], [1, 0, 0, 1, 0.5f, -0.5f]),
            Tensor("bias", [2], [0.2f, -0.2f]));
        CompiledModel compiled = new(model, [2, 3], 1);
        try
        {
            using InferenceSession session = compiled.CreateRequest();
            session.PlanForCtcProjection = true;
            session.Reshape([3, 3]);
            float[] input = [1, 2, 3, 4, 5, 6, -1, -2, -3];
            Assert.True(session.TryRunUntilCtcProjection(input, out _));
            List<string> observed = [];
            float[] actual = session.RunWithTrace(input,
                (_, name, _, _, _, _) => observed.Add(name)).ToArray();

            using InferenceSession fullSession = compiled.CreateRequest();
            fullSession.Reshape([3, 3]);
            float[] expected = fullSession.Run(input);
            Assert.Equal(new string[] { "prepare", "projection", "bias", "probabilities" }, observed);
            AssertClose(expected, actual);
            Assert.Equal(6, actual.Length);
        }
        finally { compiled.Dispose(); }
    }

    [Fact]
    public void RunWithTrace_RejectsNullObserverInvalidInputAndDisposedSession()
    {
        using Model model = ArithmeticModel();
        CompiledModel compiled = new(model, [1, 4], 1);
        try
        {
            using InferenceSession session = compiled.CreateRequest();
            NodeValuesObserver observer = (_, _, _, _, _, _) => Assert.Fail("Observer must not be called.");
            Assert.Throws<ArgumentNullException>(() => { session.RunWithTrace([1, 2, 3, 4], null!); });
            Assert.Throws<ArgumentException>(() => { session.RunWithTrace([1, 2, 3], observer); });
            session.Dispose();
            Assert.Throws<ObjectDisposedException>(() => { session.RunWithTrace([1, 2, 3, 4], observer); });
        }
        finally { compiled.Dispose(); }
    }

    private static Model ArithmeticModel() => LoadGraph([1, 4], [1, 4],
        Node("plus-one", "Add", ["x", "one"], "plus"),
        Node("times-two", "Mul", ["plus", "two"], "times"),
        Node("minus-three", "Sub", ["times", "three"], "y"),
        Tensor("one", [1], [1]), Tensor("two", [1], [2]), Tensor("three", [1], [3]));

    // Tiny real ONNX graphs keep these tests independent of bundled model
    // weights while exercising the parser, layout/fusion planner, and executor.
    private static Model LoadGraph(int[] inputShape, int[] outputShape, params byte[][] records)
    {
        byte[] graph = Join([.. records, Bytes(11, ValueInfo("x", inputShape)), Bytes(12, ValueInfo("y", outputShape))]);
        return Model.Load(Join(Number(1, 8), Bytes(8, Number(2, 13)), Bytes(7, graph)));
    }

    private static byte[] Node(string name, string op, string[] inputs, string output, params byte[][] attributes) => Bytes(1,
        Join([.. inputs.Select(input => String(1, input)), String(2, output), String(3, name), String(4, op),
            .. attributes.Select(attribute => Bytes(5, attribute))]));

    private static byte[] IntList(string name, params int[] values) =>
        Join([String(1, name), Number(20, 7), .. values.Select(value => Number(8, value))]);

    private static byte[] Tensor(string name, int[] shape, float[] data) => Bytes(5,
        Join([.. shape.Select(dim => Number(1, dim)), Number(2, 1), String(8, name),
            Bytes(9, System.Runtime.InteropServices.MemoryMarshal.AsBytes(data.AsSpan()).ToArray())]));

    private static byte[] ValueInfo(string name, int[] shape) => Join(String(1, name),
        Bytes(2, Bytes(1, Join(Number(1, 1), Bytes(2, Join(shape.Select(dim => Bytes(1, Number(1, dim))).ToArray()))))));

    private static byte[] String(int field, string value) => Bytes(field, Encoding.UTF8.GetBytes(value));
    private static byte[] Number(int field, int value) => Join(Varint(field << 3), Varint(value));
    private static byte[] Bytes(int field, byte[] value) => Join(Varint((field << 3) | 2), Varint(value.Length), value);
    private static byte[] Join(params byte[][] fields) => fields.SelectMany(field => field).ToArray();
    private static byte[] Varint(int value)
    {
        List<byte> bytes = [];
        do
        {
            byte next = (byte)(value & 0x7f);
            value >>= 7;
            bytes.Add(value == 0 ? next : (byte)(next | 0x80));
        } while (value != 0);
        return bytes.ToArray();
    }
}
