using System.Buffers.Binary;
using System.Text;
using Sdcb.SimdPaddleOCR.OnnxSharp;

namespace Sdcb.SimdPaddleOCR.UnitTests;

public class ModelInspectionTests
{
    [Fact]
    public void RawInspectionDistinguishesUnknownRankScalarZeroAndSymbol()
    {
        byte[] graph = Join(Node("add", "Add", ["x", "one"], "y"), Tensor("one", [], [1]),
            Tensor("empty", [0], []), Bytes(11, ValueInfo("x", [String(2, "N")])),
            Bytes(12, ValueInfo("y", [])), Bytes(13, ValueInfo("unknown", null)),
            Bytes(13, ValueInfo("unspecified_dim", [Array.Empty<byte>()])));
        List<ModelInspectionSnapshot> snapshots = [];
        using MemoryStream source = new(ModelBytes(graph));
        using Model model = Model.Load(source, snapshots.Add);
        Assert.Equal(new[] { "raw", "normalized" }, snapshots.Select(s => s.Stage));
        ModelInspectionSnapshot raw = snapshots[0];
        Assert.False(Tensor(raw, "unknown").Shape.RankKnown);
        Assert.True(Tensor(raw, "y").Shape.RankKnown);
        Assert.Empty(Tensor(raw, "y").Shape.Dims);
        Assert.Equal(new ModelInspectionDimension("known", 0L), Assert.Single(Tensor(raw, "empty").Shape.Dims));
        Assert.True(Tensor(raw, "empty").Constant);
        Assert.Empty(Tensor(raw, "empty").Data.ToArray());
        Assert.Equal(new ModelInspectionDimension("symbol", "N"), Assert.Single(Tensor(raw, "x").Shape.Dims));
        Assert.Equal("unknown", Assert.Single(Tensor(raw, "unspecified_dim").Shape.Dims).Kind);
        Assert.Empty(Tensor(snapshots[1], "y").Shape.Dims);
        Assert.DoesNotContain(snapshots[1].Tensors, t => t.Name == "empty");
    }

    [Fact]
    public void OrdinaryParserDoesNotCaptureRichShape()
    {
        using MemoryStream source = new(ModelBytes(Join(Bytes(11, ValueInfo("x", [String(2, "N")])))));
        OnnxModelData parsed = OnnxProtoReader.Parse(source);
        Assert.Null(Assert.Single(parsed.Graph!.Inputs).InspectionShape);
        Assert.Equal(new[] { -1 }, parsed.Graph.Inputs[0].Shape);
    }

    [Fact]
    public void InspectionPreservesOptionalInputSlotsAndReportsEffectiveDefaults()
    {
        List<ModelInspectionSnapshot> snapshots = Capture(Join(
            Node("conv", "Conv", ["x", "w", ""], "y", IntList("kernel_shape", 1, 1)),
            Tensor("w", [1, 1, 1, 1], [2]),
            Bytes(11, KnownValue("x", [1, 1, 1, 1])), Bytes(12, KnownValue("y", [1, 1, 1, 1]))));
        Assert.Null(Assert.Single(snapshots[0].Nodes).Inputs[2]);
        ModelInspectionNode normalized = Assert.Single(snapshots[1].Nodes);
        Assert.Null(normalized.Inputs[2]);
        Assert.Equal(new long[] { 1, 1 }, normalized.Attributes["strides"].Values);
        Assert.Equal(1L, normalized.Attributes["group"].Value);
        Assert.Equal(new long[] { 0, 0, 0, 0 }, normalized.Attributes["pads"].Values);
    }

    [Fact]
    public void BatchNormalizationLineageAndWeightsMatchReferenceArithmetic()
    {
        List<ModelInspectionSnapshot> snapshots = Capture(Join(
            Node("conv", "Conv", ["x", "w"], "conv_out", IntList("kernel_shape", 1, 1)),
            Node("bn", "BatchNormalization", ["conv_out", "gamma", "beta", "mean", "variance"], "y", Float("epsilon", 0)),
            Tensor("w", [1, 1, 1, 1], [2]), Tensor("gamma", [1], [3]), Tensor("beta", [1], [2]),
            Tensor("mean", [1], [1]), Tensor("variance", [1], [4]),
            Bytes(11, KnownValue("x", [1, 1, 1, 1])), Bytes(12, KnownValue("y", [1, 1, 1, 1]))));
        ModelInspectionSnapshot normalized = snapshots[1];
        ModelInspectionNode node = Assert.Single(normalized.Nodes);
        Assert.Equal("node:0", node.Key);
        Assert.Equal(new[] { 0, 1 }, node.SourceIndices);
        Assert.Equal("generated:bn_weight:0:1", node.Inputs[1]);
        Assert.Equal("generated:bn_bias:0:1", node.Inputs[2]);
        Assert.Equal(3f, F32(Assert.Single(normalized.Tensors, t => t.Key == node.Inputs[1])));
        Assert.Equal(.5f, F32(Assert.Single(normalized.Tensors, t => t.Key == node.Inputs[2])));
    }

    [Fact]
    public void ParallelBranchLineageUsesTheOriginalAddIndex()
    {
        List<ModelInspectionSnapshot> snapshots = Capture(Join(
            Node("first", "Conv", ["x", "w1"], "first_out", IntList("kernel_shape", 1, 1)),
            Node("second", "Conv", ["x", "w2"], "second_out", IntList("kernel_shape", 1, 1)),
            Node("sum", "Add", ["first_out", "second_out"], "y"),
            Tensor("w1", [1, 1, 1, 1], [2]), Tensor("w2", [1, 1, 1, 1], [3]),
            Bytes(11, KnownValue("x", [1, 1, 1, 1])), Bytes(12, KnownValue("y", [1, 1, 1, 1]))));
        ModelInspectionNode node = Assert.Single(snapshots[1].Nodes);
        Assert.Equal("node:0", node.Key);
        Assert.Equal(new[] { 0, 1, 2 }, node.SourceIndices);
        Assert.Equal("generated:branch_weight:2", node.Inputs[1]);
        Assert.Equal(5f, F32(Assert.Single(snapshots[1].Tensors, t => t.Key == node.Inputs[1])));
    }

    [Fact]
    public void InspectionCallbacksDoNotChangeNormalizedModelWeights()
    {
        byte[] bytes = ModelBytes(Join(Node("conv", "Conv", ["x", "w"], "y", IntList("kernel_shape", 1, 1)),
            Tensor("w", [1, 1, 1, 1], [2]), Bytes(11, KnownValue("x", [1, 1, 1, 1])), Bytes(12, KnownValue("y", [1, 1, 1, 1]))));
        using Model ordinary = Model.Load(bytes);
        using MemoryStream source = new(bytes);
        using Model inspected = Model.Load(source, _ => { });
        Assert.Equal(ordinary.Info, inspected.Info);
        for (int i = 0; i < ordinary.Tensors.Length; i++)
            Assert.Equal(ordinary.GetTensorBytes(i).ToArray(), inspected.GetTensorBytes(i).ToArray());
    }

    [Fact]
    public void RemovedMetadataReshapeKeepsItsDeclaredRecipeAndSourceIndices()
    {
        byte[] integer = new byte[8];
        BinaryPrimitives.WriteInt64LittleEndian(integer, -1);
        List<ModelInspectionSnapshot> snapshots = Capture(Join(
            Node("shape", "Shape", ["x"], "shape_all"),
            Node("slice", "Slice", ["shape_all"], "shape_batch", IntList("starts", 0), IntList("ends", 1), IntList("axes", 0)),
            Node("concat", "Concat", ["shape_batch", "infer"], "shape_target", Join(String(1, "axis"), Number(20, 2), Number(3, 0))),
            Node("reshape", "Reshape", ["x", "shape_target"], "y"),
            Bytes(5, Join(Number(1, 1), Number(2, 7), String(8, "infer"), Bytes(9, integer))),
            Bytes(11, ValueInfo("x", [String(2, "N"), Number(1, 2)])),
            Bytes(12, ValueInfo("y", [String(2, "N"), Number(1, 2)]))));
        ModelInspectionRecipe recipe = Assert.Single(snapshots[1].Recipes);
        Assert.Equal("node:3", recipe.NodeKey);
        Assert.Equal("original:x", recipe.DataInput);
        Assert.Equal("original:shape_target", recipe.ShapeInput);
        Assert.Equal(new[] { 0, 1, 2 }, recipe.SourceIndices);
        Assert.Equal(new ModelInspectionDimension("symbol", "N"), recipe.Template.Dims[0]);
        Assert.Single(Assert.Single(snapshots[1].Nodes).Inputs);
        Assert.Equal(new[] { "Shape", "Slice", "Concat" }, snapshots[1].ShapeMetadata.Nodes.Select(n => n.OpType));
        ModelInspectionIntegerConstant constant = Assert.Single(snapshots[1].ShapeMetadata.Constants);
        Assert.Equal("original:infer", constant.Key);
        Assert.Equal("i64", constant.Dtype);
        Assert.Equal(new long[] { -1 }, constant.Values);
        Assert.Empty(snapshots[0].ShapeMetadata.Nodes);
    }

    private static float F32(ModelInspectionTensor tensor) => BinaryPrimitives.ReadSingleLittleEndian(tensor.Data.Span);
    private static ModelInspectionTensor Tensor(ModelInspectionSnapshot snapshot, string name) => Assert.Single(snapshot.Tensors, t => t.Name == name);
    private static List<ModelInspectionSnapshot> Capture(byte[] graph)
    {
        List<ModelInspectionSnapshot> snapshots = [];
        using MemoryStream source = new(ModelBytes(graph));
        using Model model = Model.Load(source, snapshots.Add);
        return snapshots;
    }
    private static byte[] ModelBytes(byte[] graph) => Join(Number(1, 8), Bytes(8, Number(2, 13)), Bytes(7, graph));
    private static byte[] Node(string name, string op, string[] inputs, string output, params byte[][] attributes) => Bytes(1,
        Join([.. inputs.Select(input => String(1, input)), String(2, output), String(3, name), String(4, op),
            .. attributes.Select(attribute => Bytes(5, attribute))]));
    private static byte[] IntList(string name, params int[] values) => Join([String(1, name), Number(20, 7), .. values.Select(value => Number(8, value))]);
    private static byte[] Float(string name, float value) => Join(String(1, name), Number(20, 1),
        Varint((2 << 3) | 5), BitConverter.GetBytes(value));
    private static byte[] Tensor(string name, int[] shape, float[] data) => Bytes(5,
        Join([.. shape.Select(dim => Number(1, dim)), Number(2, 1), String(8, name),
            Bytes(9, System.Runtime.InteropServices.MemoryMarshal.AsBytes(data.AsSpan()).ToArray())]));
    private static byte[] KnownValue(string name, int[] shape) => ValueInfo(name, shape.Select(dim => Number(1, dim)).ToArray());
    private static byte[] ValueInfo(string name, byte[][]? dims) => Join(String(1, name), Bytes(2, Bytes(1,
        dims is null ? Number(1, 1) : Join(Number(1, 1), Bytes(2, Join(dims.Select(dim => Bytes(1, dim)).ToArray()))))));
    private static byte[] String(int field, string value) => Bytes(field, Encoding.UTF8.GetBytes(value));
    private static byte[] Number(int field, int value) => Join(Varint(field << 3), Varint(value));
    private static byte[] Bytes(int field, byte[] value) => Join(Varint((field << 3) | 2), Varint(value.Length), value);
    private static byte[] Join(params byte[][] fields) => fields.SelectMany(field => field).ToArray();
    private static byte[] Varint(int value)
    {
        List<byte> bytes = [];
        do { byte next = (byte)(value & 127); value >>= 7; bytes.Add(value == 0 ? next : (byte)(next | 128)); } while (value != 0);
        return bytes.ToArray();
    }
}
